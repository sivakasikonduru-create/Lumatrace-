import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/core/RiskAndRecovery.ts', 'utf-8');

// Add controlSaturated: false to initial update return
content = content.replace(
  "failureCause: this.lastFailureCause",
  "failureCause: this.lastFailureCause,\n      controlSaturated: false"
);

writeFileSync('src/core/RiskAndRecovery.ts', content);
