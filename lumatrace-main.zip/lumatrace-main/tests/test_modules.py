"""Unit tests for LumaTrace Python core modules."""
import unittest
from config.config import SimulationConfig
from camera.camera import VirtualCamera, CameraState
from target.target import BeaconTarget, TargetState
from detection.detector import BeaconDetector, DetectionResult
from tracking.kalman import KalmanFilter2D
from tracking.tracker import LumaTraceTracker, TrackingState
from control.controller import BaselineReactiveController, LumaTracePredictiveController
from disturbance.disturbances import DisturbanceConfig, DisturbanceEngine
from analytics.metrics import PerformanceEvaluator, PerformanceMetrics
from reporting.reporter import PerformanceReporter
from simulation.simulator import FsocSimulation

class TestLumaTraceArchitecture(unittest.TestCase):
    
    def test_config_sih_parameters(self):
        cfg = SimulationConfig()
        self.assertEqual(cfg.screen_width, 2000)
        self.assertEqual(cfg.screen_height, 2000)
        self.assertEqual(cfg.camera_width, 640)
        self.assertEqual(cfg.camera_height, 480)
        self.assertEqual(cfg.camera_fov_h_deg, 4.0)
        self.assertEqual(cfg.camera_fov_v_deg, 3.0)
        self.assertEqual(cfg.max_pan_speed_deg_s, 5.0)
        self.assertEqual(cfg.max_tilt_speed_deg_s, 5.0)
        self.assertEqual(cfg.target_size_px, 10)

    def test_virtual_camera_projection_and_velocity_clamping(self):
        cam = VirtualCamera()
        self.assertEqual(cam.pan_deg, 0.0)
        self.assertEqual(cam.tilt_deg, 0.0)
        
        # Test rate clamping: requesting 20 deg/s must clamp to 5 deg/s
        cam.command_velocity(20.0, -15.0, dt=1.0)
        self.assertEqual(cam.pan_deg, 5.0)
        self.assertEqual(cam.tilt_deg, -5.0)
        
        # Center in screen space
        cx, cy = cam.viewport_center
        self.assertAlmostEqual(cx, 1000.0 + 5.0 * (640 / 4.0))

    def test_target_trajectories(self):
        cfg = SimulationConfig(target_motion_mode="straight_line")
        t_line = BeaconTarget(cfg)
        s1 = t_line.update(0.1)
        self.assertIsInstance(s1, TargetState)
        
        cfg.target_motion_mode = "circular"
        t_circ = BeaconTarget(cfg)
        s2 = t_circ.update(0.1)
        self.assertTrue(s2.is_active)
        
        cfg.target_motion_mode = "figure_8"
        t_fig8 = BeaconTarget(cfg)
        s3 = t_fig8.update(0.1)
        self.assertGreater(len(t_fig8.ground_truth_history), 0)

    def test_beacon_detector_centroiding(self):
        detector = BeaconDetector(camera_width=100, camera_height=100, threshold=100.0)
        # Create dark frame with 10x10 bright spot centered at (45, 45)
        frame = [[0.0 for _ in range(100)] for _ in range(100)]
        for y in range(40, 50):
            for x in range(40, 50):
                frame[y][x] = 200.0
                
        res: DetectionResult = detector.process_frame(frame, ground_truth_viewport=(45.0, 45.0))
        self.assertTrue(res.detected)
        self.assertAlmostEqual(res.centroid_x, 44.5, delta=1.0)
        self.assertAlmostEqual(res.centroid_y, 44.5, delta=1.0)
        self.assertIsNotNone(res.centroiding_error)
        self.assertLess(res.centroiding_error, 2.0)

    def test_kalman_and_tracking(self):
        tracker = LumaTraceTracker(640, 480)
        det = DetectionResult(
            detected=True, bbox=(315, 235, 10, 10), centroid_x=320.0, centroid_y=240.0,
            confidence=0.9, processing_time_ms=1.5, camera_center_x=320.0, camera_center_y=240.0,
            horizontal_error=0.0, vertical_error=0.0, euclidean_error=0.0
        )
        st = tracker.update(det, dt=0.033)
        self.assertIn(st.state_label, ["ACQUIRING", "CENTERED", "TRACKING"])
        self.assertEqual(st.risk_level, "SAFE")

    def test_disturbances_and_metrics(self):
        dist_cfg = DisturbanceConfig(jitter_enabled=True, jitter_amplitude_px=15.0)
        engine = DisturbanceEngine(dist_cfg)
        j_dx, j_dy, _, _ = engine.compute_motion_offsets(0.033)
        self.assertLessEqual(abs(j_dx), 20.0)
        self.assertLessEqual(abs(j_dy), 20.0)

    def test_end_to_end_simulation(self):
        sim = FsocSimulation()
        for _ in range(10):
            telemetry = sim.step(dt=0.033)
            self.assertIn("tracking_error", telemetry)
            self.assertIn("pan_deg", telemetry)
        
        metrics = sim.get_metrics()
        self.assertIsInstance(metrics, PerformanceMetrics)
        md = PerformanceReporter.generate_compliance_markdown(metrics)
        self.assertIn("Compliance Matrix", md)

if __name__ == "__main__":
    unittest.main()
