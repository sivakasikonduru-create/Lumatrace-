"""MP4 Benchmark Processing Engine for SIH Video Evaluation."""
import time
from typing import List, Dict, Any, Optional
from detection.detector import BeaconDetector, DetectionResult
from tracking.tracker import LumaTraceTracker
from analytics.metrics import PerformanceEvaluator, PerformanceMetrics

class MP4BenchmarkPipeline:
    """Processes frame-by-frame 30 FPS video feeds bypassing physical PTZ camera."""
    
    def __init__(self, camera_w: int = 640, camera_h: int = 480):
        self.camera_w = camera_w
        self.camera_h = camera_h
        self.detector = BeaconDetector(camera_w, camera_h)
        self.tracker = LumaTraceTracker(camera_w, camera_h)
        self.evaluator = PerformanceEvaluator()
        self.frame_logs: List[Dict[str, Any]] = []

    def process_frame(self, frame_index: int, timestamp: float, frame_pixels: List[List[float]],
                      ground_truth_centroid: Optional[tuple] = None) -> Dict[str, Any]:
        """Processes a single benchmark video frame."""
        t0 = time.perf_counter()
        
        # 1. Detect beacon from image
        det_result: DetectionResult = self.detector.process_frame(frame_pixels, ground_truth_centroid)
        
        # 2. Update tracking state
        dt = 1.0 / 30.0
        track_state = self.tracker.update(det_result, dt)
        
        proc_time_ms = (time.perf_counter() - t0) * 1000.0
        fps = 1000.0 / max(0.1, proc_time_ms)
        
        # 3. Log metrics
        self.evaluator.record_frame(
            timestamp=timestamp,
            detected=det_result.detected,
            tracking_error_px=det_result.euclidean_error,
            centroiding_error_px=det_result.centroiding_error,
            processing_time_ms=proc_time_ms,
            reacquisition_event_time=track_state.reacquisition_time_s
        )
        
        entry = {
            "frame": frame_index,
            "timestamp": round(timestamp, 3),
            "detected": det_result.detected,
            "centroid_x": round(det_result.centroid_x, 2) if det_result.detected else None,
            "centroid_y": round(det_result.centroid_y, 2) if det_result.detected else None,
            "confidence": round(det_result.confidence, 3),
            "tracking_error": round(det_result.euclidean_error, 2),
            "centroiding_error": round(det_result.centroiding_error, 2) if det_result.centroiding_error else None,
            "state": track_state.state_label,
            "risk": track_state.risk_level,
            "fps": round(fps, 1),
            "processing_time_ms": round(proc_time_ms, 2)
        }
        self.frame_logs.append(entry)
        return entry

    def finalize_benchmark(self) -> PerformanceMetrics:
        """Calculates final benchmark performance metrics."""
        return self.evaluator.compute_metrics()
