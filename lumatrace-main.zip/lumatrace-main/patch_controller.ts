import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/core/Controllers.ts', 'utf-8');

// Improve autonomous re-acquisition intelligent search logic (SCANNING)
const scanningReplacement = `
    } else if (state.stateLabel === 'LOST' || state.stateLabel === 'SCANNING' || state.stateLabel === 'REACQUIRING') {
      // Intelligent Re-acquisition Search:
      // Rather than a random blind scan, we generate a probability cone based on last known velocity.
      // We spiral outwards from the predicted coasting point.
      this.searchAngle += 3.2 * dt;
      // Base drift based on last known velocity
      const panFf = (state.velocityX / camera.pxPerDegH) * 0.5;
      const tiltFf = (state.velocityY / camera.pxPerDegV) * 0.5;
      
      const searchRadiusPan = Math.min(this.maxPanSpeed, this.maxPanSpeed * (state.uncertainty / 100));
      const searchRadiusTilt = Math.min(this.maxTiltSpeed, this.maxTiltSpeed * (state.uncertainty / 100));

      let panRate = panFf + searchRadiusPan * Math.sin(this.searchAngle);
      let tiltRate = tiltFf + searchRadiusTilt * Math.cos(this.searchAngle * 0.5);

      const saturated = Math.abs(panRate) >= this.maxPanSpeed || Math.abs(tiltRate) >= this.maxTiltSpeed;
      panRate = Math.max(-this.maxPanSpeed, Math.min(this.maxPanSpeed, panRate));
      tiltRate = Math.max(-this.maxTiltSpeed, Math.min(this.maxTiltSpeed, tiltRate));
      return { panRate, tiltRate, saturated };
    }
`;

content = content.replace(
  /\} else if \(state.stateLabel === 'LOST' \|\| state.stateLabel === 'SCANNING'\) \{[\s\S]*?return \{ panRate, tiltRate, saturated \};\n    \}/,
  scanningReplacement.trim()
);

writeFileSync('src/core/Controllers.ts', content);
