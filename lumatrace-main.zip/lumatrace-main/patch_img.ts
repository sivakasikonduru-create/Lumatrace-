import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/core/ImageProcessor.ts', 'utf-8');

// Insert dynamic obstacle rendering
const obstacleBlock = `
    // 3.5 Dynamic LOS Obstruction (Simulating moving clouds/structures)
    if (distConfig.losObstructionEnabled) {
      const obsTime = performance.now() / 1500; // Speed of obstacle
      const obsX = (obsTime * 300) % (w * 2) - w/2;
      const obsY = h / 2 + Math.sin(obsTime * 2) * 80;
      const obsWidth = 200;
      const obsHeight = 300;
      
      ctx.fillStyle = distConfig.losObstructionSeverity === 'full' ? 'rgba(10,10,12,0.98)' : 'rgba(80,85,90,0.7)';
      ctx.fillRect(obsX - obsWidth/2, obsY - obsHeight/2, obsWidth, obsHeight);
    }
`;

content = content.replace(
  "// 4. Rain Particles (if enabled)",
  obstacleBlock + "\n    // 4. Rain Particles (if enabled)"
);

writeFileSync('src/core/ImageProcessor.ts', content);
