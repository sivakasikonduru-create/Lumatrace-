import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/core/MetricsEvaluator.ts', 'utf-8');

content = content.replace(
  "public reacquisitionTimes: number[] = [];",
  "public reacquisitionTimes: number[] = [];\n  public saturationEvents: number = 0;"
);

content = content.replace(
  "this.reacquisitionTimes = [];",
  "this.reacquisitionTimes = [];\n    this.saturationEvents = 0;"
);

content = content.replace(
  "reacquisitionEventTime?: number",
  "reacquisitionEventTime?: number,\n    saturated?: boolean"
);

content = content.replace(
  "this.reacquisitionTimes.push(reacquisitionEventTime);\n    }",
  "this.reacquisitionTimes.push(reacquisitionEventTime);\n    }\n    if (saturated) {\n      this.saturationEvents++;\n    }"
);

content = content.replace(
  "averageCentroidingErrorPx: Number(avgCentroiding.toFixed(2)),",
  "averageCentroidingErrorPx: Number(avgCentroiding.toFixed(2)),\n      controlSaturationEvents: this.saturationEvents,"
);

content = content.replace(
  "averageCentroidingErrorPx: 0,",
  "averageCentroidingErrorPx: 0,\n      controlSaturationEvents: 0,"
);

writeFileSync('src/core/MetricsEvaluator.ts', content);
