import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/types/fsoc.ts', 'utf-8');

// Update DisturbanceConfig
content = content.replace(
  "beamWanderPx?: number;",
  "beamWanderPx?: number;\n  losObstructionEnabled?: boolean;\n  losObstructionSeverity?: 'partial' | 'full';"
);
content = content.replace(
  "beamWanderPx: 0.0,",
  "beamWanderPx: 0.0,\n  losObstructionEnabled: false,\n  losObstructionSeverity: 'partial',"
);

// Update TrackingState
content = content.replace(
  "reacquisitionTimeS: number;",
  "reacquisitionTimeS: number;\n  predictedFovLoss: 'LOW' | 'MEDIUM' | 'HIGH';\n  failureCause: string | null;"
);

writeFileSync('src/types/fsoc.ts', content);

let appContent = readFileSync('src/App.tsx', 'utf-8');
appContent = appContent.replace(
  "riskReason: 'Initializing optical tracking loop',",
  "riskReason: 'Initializing optical tracking loop',\n    predictedFovLoss: 'LOW',\n    failureCause: null,"
);
appContent = appContent.replace(
  "const trackState = trackingEngineRef.current.update(detResult, dt);",
  "const trackState = trackingEngineRef.current.update(detResult, dt, distConfig);"
);
writeFileSync('src/App.tsx', appContent);
