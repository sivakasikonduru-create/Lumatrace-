/**
 * Data models and types for LumaTrace FSOC Coarse Alignment Tracking System.
 * Strictly compliant with SIH Problem Statement 4.
 */

export interface SimulationConfig {
  // Screen space
  screenWidth: number; // min 2000
  screenHeight: number; // min 2000

  // Camera specifications
  cameraWidth: number; // default 640
  cameraHeight: number; // default 480
  cameraFovHDeg: number; // default 4.0
  cameraFovVDeg: number; // default 3.0
  cameraUpdateRateHz: number; // >= 30 Hz
  maxPanSpeedDegS: number; // default 5.0 deg/s
  maxTiltSpeedDegS: number; // default 5.0 deg/s
  initialCameraPos: [number, number]; // default [1000, 1000]

  // Target specifications
  targetCount: number; // 1 mandatory, optional multi
  targetSizePx: number; // 5-20 px configurable, default 10
  targetSpeedPxS: number; // default 80 px/s
  targetInitialPos: [number, number] | null; // null for random
  targetMotionMode: 'straight_line' | 'circular' | 'figure_8' | 'random' | 'spiral' | 'sinusoidal';

  // Controller specifications
  controllerUpdateRateHz: number; // >= 20 Hz
  controllerType: 'baseline' | 'predictive';

  // SIH Performance Targets
  targetAcquisitionTimeS: number; // <= 2.0 s
  targetTrackingErrorPx: number; // <= 10.0 px
  targetLossPercentageMax: number; // < 5.0 %
  targetReacquisitionTimeS: number; // <= 1.0 s
  targetProcessingFpsMin: number; // >= 20.0 FPS
  simulationMode: 'standard' | 'drone_to_drone';
  droneAInitialPos?: [number, number, number];
  droneBInitialPos?: [number, number, number];
}

export const DEFAULT_SIH_CONFIG: SimulationConfig = {
  screenWidth: 2000,
  screenHeight: 2000,
  cameraWidth: 640,
  cameraHeight: 480,
  cameraFovHDeg: 4.0,
  cameraFovVDeg: 3.0,
  cameraUpdateRateHz: 30.0,
  maxPanSpeedDegS: 5.0,
  maxTiltSpeedDegS: 5.0,
  initialCameraPos: [1000.0, 1000.0],
  targetCount: 1,
  targetSizePx: 10,
  targetSpeedPxS: 80.0,
  targetInitialPos: null,
  targetMotionMode: 'straight_line',
  controllerUpdateRateHz: 20.0,
  controllerType: 'predictive',
  targetAcquisitionTimeS: 2.0,
  targetTrackingErrorPx: 10.0,
  targetLossPercentageMax: 5.0,
  targetReacquisitionTimeS: 1.0,
  targetProcessingFpsMin: 20.0,
  simulationMode: 'standard',
};

export const DEFAULT_CONFIG = DEFAULT_SIH_CONFIG;

export interface TargetState {
  id: number;
  worldX: number;
  worldY: number;
  worldZ?: number;
  vx: number;
  vy: number;
  vz?: number;
  sizePx: number;
  motionMode: string;
  isActive: boolean;
  timestamp: number;
}

export interface CameraState {
  panDeg: number;
  tiltDeg: number;
  panVelocityDegS: number;
  tiltVelocityDegS: number;
  worldX?: number;
  worldY?: number;
  worldZ?: number;
  viewportCenterX: number; // in 2000x2000 world screen
  viewportCenterY: number;
  resolutionW: number;
  resolutionH: number;
  fovHDeg: number;
  fovVDeg: number;
  opticalCenterX: number;
  opticalCenterY: number;
}

export interface DetectionResult {
  detected: boolean;
  bbox: [number, number, number, number]; // [x, y, w, h]
  centroidX: number;
  centroidY: number;
  confidence: number;
  processingTimeMs: number;
  cameraCenterX: number;
  cameraCenterY: number;
  horizontalError: number; // centroidX - cameraCenterX
  verticalError: number;   // centroidY - cameraCenterY
  euclideanError: number;  // sqrt(dx^2 + dy^2)
  centroidingError: number | null; // strictly for post-eval vs ground truth
}

export type TrackingStateLabel =
  | 'SEARCHING'
  | 'ACQUIRING'
  | 'TRACKING'
  | 'CENTERED'
  | 'TARGET_LOST'
  | 'PREDICTIVE_SEARCH'
  | 'SCANNING'
  | 'RE_ACQUIRING'
  | 'RE_ACQUIRED'
  | 'LOST';

export type RiskLevel = 'SAFE' | 'WARNING' | 'HIGH_RISK' | 'LOST';

export interface TrackingState {
  stateLabel: TrackingStateLabel;
  currentX: number;
  currentY: number;
  predictedX: number;
  predictedY: number;
  velocityX: number;
  velocityY: number;
  uncertainty: number;
  confidence: number;
  consecutiveHits: number;
  consecutiveMisses: number;
  reacquisitionTimeS: number;
  predictedFovLoss: 'LOW' | 'MEDIUM' | 'HIGH';
  failureCause: string | null;
  controlSaturated: boolean;
  riskLevel: RiskLevel;
  riskReason: string;
}

export interface DisturbanceConfig {
  noiseType: 'none' | 'gaussian' | 'salt_pepper' | 'poisson';
  noiseIntensity: number; // 0.0 to 1.0
  gaussianSigma: number;  // up to 20 px
  jitterEnabled: boolean;
  jitterAmplitudePx: number; // up to 20 px
  atmosphericCondition: 'clear' | 'haze' | 'fog' | 'rain' | 'low_light' | 'turbulence';
  contrastReduction: number;
  brightnessReduction: number;
  platformMotionEnabled: boolean;
  platformMotionType: 'linear' | 'circular' | 'random' | 'figure_8';
  platformAmplitudePx: number; // up to 20 px
  turbulenceIntensity?: number;
  beamWanderPx?: number;
  losObstructionEnabled?: boolean;
  losObstructionSeverity?: 'partial' | 'full';
}

export const DEFAULT_DISTURBANCE_CONFIG: DisturbanceConfig = {
  noiseType: 'none',
  noiseIntensity: 0.05,
  gaussianSigma: 10.0,
  jitterEnabled: false,
  jitterAmplitudePx: 6.0,
  atmosphericCondition: 'clear',
  contrastReduction: 0.0,
  brightnessReduction: 0.0,
  platformMotionEnabled: false,
  platformMotionType: 'linear',
  platformAmplitudePx: 8.0,
  turbulenceIntensity: 0.0,
  beamWanderPx: 0.0,
  losObstructionEnabled: false,
  losObstructionSeverity: 'partial',
};

export const DEFAULT_DISTURBANCE = DEFAULT_DISTURBANCE_CONFIG;

export interface SihComplianceMetric {
  target: string;
  measured: number;
  status: 'PASS' | 'NEEDS IMPROVEMENT';
}

export interface PerformanceMetrics {
  simulationDurationS: number;
  totalFrames: number;
  processingFps: number;
  minFps: number;
  avgFps: number;
  avgProcessingTimeMs: number;
  acquisitionTimeS: number;
  reacquisitionTimeS: number;
  averageTrackingErrorPx: number;
  maxTrackingErrorPx: number;
  rmsePx: number;
  targetLossPercentage: number;
  lockRetentionRate: number;
  averageCentroidingErrorPx: number;
  controlSaturationEvents: number;
  sihCompliance: {
    acquisitionTime: SihComplianceMetric;
    trackingError: SihComplianceMetric;
    targetLoss: SihComplianceMetric;
    reacquisitionTime: SihComplianceMetric;
    processingSpeed: SihComplianceMetric;
  };
}

export interface FrameTelemetry {
  frame: number;
  timestamp: number;
  detected: boolean;
  trackingError: number;
  centroidingError: number | null;
  confidence: number;
  panDeg: number;
  tiltDeg: number;
  panRate: number;
  tiltRate: number;
  targetWorldX: number;
  targetWorldY: number;
  state: TrackingStateLabel;
  risk: RiskLevel;
  riskReason: string;
  fps: number;
}
