import { DetectionResult, DisturbanceConfig } from '../types/fsoc';

export class ImageProcessor {
  private width: number;
  private height: number;
  private centerX: number;
  private centerY: number;
  private disturbanceTime: number = 0;

  constructor(width: number = 640, height: number = 480) {
    this.width = width;
    this.height = height;
    this.centerX = width / 2.0;
    this.centerY = height / 2.0;
  }

  /**
   * Computes camera jitter and platform motion offsets (both clamped to <= 20 px/frame).
   */
  public computeMotionDisturbances(dt: number, config: DisturbanceConfig): {
    jitterX: number;
    jitterY: number;
    platformX: number;
    platformY: number;
  } {
    this.disturbanceTime += dt;
    const t = this.disturbanceTime;

    let jitterX = 0;
    let jitterY = 0;
    if (config.atmosphericCondition === 'turbulence') {
      const turb = config.turbulenceIntensity || 0.5;
      jitterX += (Math.random() - 0.5) * 10 * turb;
      jitterY += (Math.random() - 0.5) * 10 * turb;
    }
    if (config.jitterEnabled) {
      const amp = Math.min(20.0, config.jitterAmplitudePx);
      jitterX = (Math.random() - 0.5) * 2.0 * amp;
      jitterY = (Math.random() - 0.5) * 2.0 * amp;
    }

    let platformX = 0;
    let platformY = 0;
    if (config.platformMotionEnabled) {
      const amp = Math.min(20.0, config.platformAmplitudePx);
      switch (config.platformMotionType) {
        case 'circular':
          platformX = amp * Math.cos(t * 2.2);
          platformY = amp * Math.sin(t * 2.2);
          break;
        case 'figure_8':
          platformX = amp * Math.sin(t * 1.9);
          platformY = amp * 0.5 * Math.sin(2 * t * 1.9);
          break;
        case 'random':
          platformX = (Math.random() - 0.5) * 2.0 * amp;
          platformY = (Math.random() - 0.5) * 2.0 * amp;
          break;
        case 'linear':
        default:
          platformX = amp * Math.sin(t * 1.5);
          platformY = amp * 0.4 * Math.cos(t * 1.5);
          break;
      }
    }

    return { jitterX, jitterY, platformX, platformY };
  }

  /**
   * Renders the optical scene into an HTML5 Canvas context:
   * Background noise, dark sky / space, beacon square spot (5-20px), atmospheric effects, jitter.
   */
  public renderOpticalFrame(
    ctx: CanvasRenderingContext2D,
    beaconViewportPos: { u: number; v: number; inside: boolean; size: number } | null,
    secondaryBeacon: { u: number; v: number; inside: boolean; size: number } | null,
    distConfig: DisturbanceConfig,
    jitterOffset: { x: number; y: number }
  ) {
    const w = this.width;
    const h = this.height;

    // 1. Dark sensor background
    let bgBrightness = 12; // baseline thermal sensor dark level
    let bgAlpha = 1.0;

    if (distConfig.atmosphericCondition === 'haze') {
      bgBrightness = 38;
    } else if (distConfig.atmosphericCondition === 'turbulence') {
      bgBrightness = 15;
    } else if (distConfig.atmosphericCondition === 'fog') {
      bgBrightness = 70;
    } else if (distConfig.atmosphericCondition === 'rain') {
      bgBrightness = 32;
    } else if (distConfig.atmosphericCondition === 'low_light') {
      bgBrightness = 4;
    }

    ctx.fillStyle = `rgb(${bgBrightness}, ${bgBrightness + 2}, ${bgBrightness + 5})`;
    ctx.fillRect(0, 0, w, h);

    // 2. Optical Beacon Spot (square, 5-20 px)
    if (beaconViewportPos && beaconViewportPos.inside) {
      const bx = beaconViewportPos.u + jitterOffset.x;
      const by = beaconViewportPos.v + jitterOffset.y;
      const s = Math.max(5, Math.min(20, beaconViewportPos.size));

      let coreBrightness = 255;
      if (distConfig.atmosphericCondition === 'fog') coreBrightness = 170;
      if (distConfig.atmosphericCondition === 'haze') coreBrightness = 210;
      if (distConfig.atmosphericCondition === 'low_light') coreBrightness = 140;
      if (distConfig.atmosphericCondition === 'turbulence') coreBrightness = 200 + (Math.random() - 0.5) * 50;

      // Outer optical blooming halo (photodiode/CMOS saturation)
      const haloGradient = ctx.createRadialGradient(bx, by, s * 0.3, bx, by, s * 1.8);
      haloGradient.addColorStop(0, `rgba(${coreBrightness}, ${coreBrightness}, ${coreBrightness}, 0.85)`);
      haloGradient.addColorStop(0.5, `rgba(200, 230, 255, 0.3)`);
      haloGradient.addColorStop(1, 'rgba(100, 180, 255, 0)');
      ctx.fillStyle = haloGradient;
      ctx.beginPath();
      ctx.arc(bx, by, s * 1.8, 0, 2 * Math.PI);
      ctx.fill();

      // Sharp core square beacon
      ctx.fillStyle = `rgb(${coreBrightness}, ${coreBrightness}, ${coreBrightness})`;
      ctx.fillRect(bx - s / 2, by - s / 2, s, s);
    }

    // 2b. Secondary beacon (if multi-target mode active)
    if (secondaryBeacon && secondaryBeacon.inside) {
      const sx = secondaryBeacon.u + jitterOffset.x;
      const sy = secondaryBeacon.v + jitterOffset.y;
      const s = Math.max(5, Math.min(20, secondaryBeacon.size));
      ctx.fillStyle = 'rgb(240, 200, 140)';
      ctx.fillRect(sx - s / 2, sy - s / 2, s, s);
    }

    // 3. Rain streaks if atmospheric condition is rain
    if (distConfig.atmosphericCondition === 'rain') {
      ctx.strokeStyle = 'rgba(180, 210, 255, 0.25)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < 45; i++) {
        const rx = (Math.random() * w);
        const ry = (Math.random() * h);
        ctx.moveTo(rx, ry);
        ctx.lineTo(rx - 4, ry + 12);
      }
      ctx.stroke();
    }
  }

  /**
   * Genuine Computer Vision Beacon Detector:
   * Inspects canvas image data pixels.
   * Calculates centroid using spatial intensity moments M00, M10, M01.
   * Strictly DOES NOT use ground truth coordinates for detection!
   */
  public detectBeaconFromImageData(
    imageData: ImageData,
    groundTruthViewport: [number, number] | null = null,
    threshold: number = 100
  ): DetectionResult {
    const startTime = performance.now();
    const data = imageData.data;
    const w = imageData.width;
    const h = imageData.height;

    let m00 = 0.0;
    let m10 = 0.0;
    let m01 = 0.0;

    let minX = w;
    let maxX = 0;
    let minY = h;
    let maxY = 0;

    let countBright = 0;
    let peakIntensity = 0;

    // Fast pixel sweep (sampling step = 1 for full subpixel precision, or step = 2 for extreme high-rate)
    for (let y = 0; y < h; y += 1) {
      const rowOffset = y * w * 4;
      for (let x = 0; x < w; x += 1) {
        const idx = rowOffset + x * 4;
        // Grayscale intensity (R*0.299 + G*0.587 + B*0.114)
        const intensity = data[idx] * 0.299 + data[idx + 1] * 0.587 + data[idx + 2] * 0.114;

        if (intensity > threshold) {
          const weight = intensity - threshold;
          m00 += weight;
          m10 += x * weight;
          m01 += y * weight;
          countBright++;

          if (intensity > peakIntensity) peakIntensity = intensity;
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }

    const procTimeMs = performance.now() - startTime;

    // Optical beacon size 5-20 px yields bright pixel count ~ 15 to 600
    if (m00 > 0 && countBright >= 8 && countBright <= 900) {
      const cx = m10 / m00;
      const cy = m01 / m00;
      const bw = Math.max(1, maxX - minX + 1);
      const bh = Math.max(1, maxY - minY + 1);

      // Contrast & compactness confidence
      const contrast = Math.min(1.0, (peakIntensity - threshold) / 120.0);
      const bboxArea = bw * bh;
      const compactness = Math.min(1.0, countBright / Math.max(1.0, bboxArea));
      const confidence = Math.max(0.15, Math.min(1.0, 0.6 * contrast + 0.4 * compactness));

      const dx = cx - this.centerX;
      const dy = cy - this.centerY;
      const euclidean = Math.sqrt(dx * dx + dy * dy);

      // Centroiding error ONLY for evaluation if ground truth is supplied
      let centroidingErr: number | null = null;
      if (groundTruthViewport) {
        const [gtX, gtY] = groundTruthViewport;
        centroidingErr = Math.sqrt((cx - gtX) ** 2 + (cy - gtY) ** 2);
      }

      return {
        detected: true,
        bbox: [minX, minY, bw, bh],
        centroidX: cx,
        centroidY: cy,
        confidence,
        processingTimeMs: procTimeMs,
        cameraCenterX: this.centerX,
        cameraCenterY: this.centerY,
        horizontalError: dx,
        verticalError: dy,
        euclideanError: euclidean,
        centroidingError: centroidingErr,
      };
    }

    return {
      detected: false,
      bbox: [0, 0, 0, 0],
      centroidX: 0,
      centroidY: 0,
      confidence: 0,
      processingTimeMs: procTimeMs,
      cameraCenterX: this.centerX,
      cameraCenterY: this.centerY,
      horizontalError: 0,
      verticalError: 0,
      euclideanError: 0,
      centroidingError: null,
    };
  }

  /**
   * Injects pixel-level noise directly onto the ImageData buffer before detector processing.
   */
  public applyNoiseToImageData(imageData: ImageData, distConfig: DisturbanceConfig) {
    if (distConfig.noiseType === 'none' && distConfig.contrastReduction === 0 && distConfig.brightnessReduction === 0) {
      return;
    }

    const data = imageData.data;
    const len = data.length;
    const sigma = Math.min(20.0, distConfig.gaussianSigma);
    const intensity = distConfig.noiseIntensity;
    const contrastScale = 1.0 - distConfig.contrastReduction;
    const brightnessOffset = -distConfig.brightnessReduction * 100.0;

    for (let i = 0; i < len; i += 4) {
      let r = data[i] * contrastScale + brightnessOffset;
      let g = data[i + 1] * contrastScale + brightnessOffset;
      let b = data[i + 2] * contrastScale + brightnessOffset;

      if (distConfig.noiseType === 'gaussian') {
        // Box-Muller Gaussian random
        const u1 = Math.max(1e-6, Math.random());
        const u2 = Math.random();
        const noise = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2) * sigma;
        r += noise;
        g += noise;
        b += noise;
      } else if (distConfig.noiseType === 'salt_pepper') {
        const rand = Math.random();
        if (rand < intensity * 0.5) {
          r = 0; g = 0; b = 0;
        } else if (rand < intensity) {
          r = 255; g = 255; b = 255;
        }
      } else if (distConfig.noiseType === 'poisson') {
        const mean = (r + g + b) / 3.0;
        const shotNoise = (Math.random() - 0.5) * 2.0 * Math.sqrt(Math.max(1.0, mean)) * (intensity * 4.0);
        r += shotNoise;
        g += shotNoise;
        b += shotNoise;
      }

      data[i] = Math.max(0, Math.min(255, r));
      data[i + 1] = Math.max(0, Math.min(255, g));
      data[i + 2] = Math.max(0, Math.min(255, b));
    }
  }
}
