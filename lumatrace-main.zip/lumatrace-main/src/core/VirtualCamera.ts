import { CameraState, SimulationConfig } from '../types/fsoc';

export class VirtualCamera {
  public panDeg: number = 0.0;
  public tiltDeg: number = 0.0;
  public panVelocity: number = 0.0;
  public tiltVelocity: number = 0.0;

  public jitterX: number = 0.0;
  public jitterY: number = 0.0;
  public platformX: number = 0.0;
  public platformY: number = 0.0;

  public resolutionW: number;
  public resolutionH: number;
  public fovHDeg: number;
  public fovVDeg: number;
  public maxPanSpeed: number;
  public maxTiltSpeed: number;
  public initialPos: [number, number];
  
  public simulationMode: 'standard' | 'drone_to_drone';
  public worldX: number = 0.0;
  public worldY: number = 0.0;
  public worldZ: number = 0.0;

  constructor(config: SimulationConfig) {
    this.resolutionW = config.cameraWidth;
    this.resolutionH = config.cameraHeight;
    this.fovHDeg = config.cameraFovHDeg;
    this.fovVDeg = config.cameraFovVDeg;
    this.maxPanSpeed = config.maxPanSpeedDegS;
    this.maxTiltSpeed = config.maxTiltSpeedDegS;
    this.initialPos = [...config.initialCameraPos];
    this.simulationMode = config.simulationMode || 'standard';
    
    if (this.simulationMode === 'drone_to_drone' && config.droneBInitialPos) {
      this.worldX = config.droneBInitialPos[0];
      this.worldY = config.droneBInitialPos[1];
      this.worldZ = config.droneBInitialPos[2];
    }
  }

  get pxPerDegH(): number {
    return this.resolutionW / this.fovHDeg;
  }

  get pxPerDegV(): number {
    return this.resolutionH / this.fovVDeg;
  }

  get viewportCenter(): [number, number] {
    if (this.simulationMode === 'drone_to_drone') {
       return [this.resolutionW / 2.0 + this.platformX, this.resolutionH / 2.0 + this.platformY];
    }
    const cx = this.initialPos[0] + this.panDeg * this.pxPerDegH + this.platformX;
    const cy = this.initialPos[1] + this.tiltDeg * this.pxPerDegV + this.platformY;
    return [cx, cy];
  }

  public applyDisturbances(jitterX: number, jitterY: number, platformX: number, platformY: number) {
    this.jitterX = jitterX;
    this.jitterY = jitterY;
    this.platformX = platformX;
    this.platformY = platformY;
  }

  /**
   * Projects coordinates into camera viewport coordinate (640x480).
   */
  public worldToViewport(
    worldX: number,
    worldY: number,
    sizePx: number = 10,
    worldZ: number = 0
  ): { u: number; v: number; inside: boolean; size: number } {
    let u = 0;
    let v = 0;
    let apparentSize = sizePx;

    if (this.simulationMode === 'drone_to_drone') {
      const dx = worldX - this.worldX;
      const dy = worldY - this.worldY; // Assuming Y is up
      const dz = worldZ - this.worldZ; // Assuming Z is forward

      const distance = Math.sqrt(dx * dx + dy * dy + dz * dz) || 0.001;
      
      // Calculate target's absolute yaw and pitch from camera
      const targetYaw = Math.atan2(dx, dz) * (180 / Math.PI);
      const targetPitch = Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180 / Math.PI);

      // Relative angular error
      let angleErrYaw = targetYaw - this.panDeg;
      // Normalize angle
      while (angleErrYaw > 180) angleErrYaw -= 360;
      while (angleErrYaw < -180) angleErrYaw += 360;

      let angleErrPitch = targetPitch + this.tiltDeg;
      while (angleErrPitch > 180) angleErrPitch -= 360;
      while (angleErrPitch < -180) angleErrPitch += 360;

      const [cx, cy] = this.viewportCenter;
      
      // +yaw -> object moves right in viewport? No, if target is to the right (+yaw), it should appear at x > center.
      u = cx + angleErrYaw * this.pxPerDegH;
      // +pitch -> object is higher -> appears at y < center
      v = cy - angleErrPitch * this.pxPerDegV;

      // Adjust size based on distance
      apparentSize = Math.max(1, (sizePx * 100) / distance);
    } else {
      const [cx, cy] = this.viewportCenter;
      const dx = worldX - cx;
      const dy = worldY - cy;

      u = this.resolutionW / 2.0 + dx;
      v = this.resolutionH / 2.0 + dy;
    }

    const inside = u >= -apparentSize && u <= this.resolutionW + apparentSize && v >= -apparentSize && v <= this.resolutionH + apparentSize;
    return { u, v, inside, size: apparentSize };
  }

  public commandVelocity(panRateDegS: number, tiltRateDegS: number, dt: number) {
    const clampedPanRate = Math.max(-this.maxPanSpeed, Math.min(this.maxPanSpeed, panRateDegS));
    const clampedTiltRate = Math.max(-this.maxTiltSpeed, Math.min(this.maxTiltSpeed, tiltRateDegS));

    this.panVelocity = clampedPanRate;
    this.tiltVelocity = clampedTiltRate;

    this.panDeg += clampedPanRate * dt;
    this.tiltDeg += clampedTiltRate * dt;
  }

  public update(dt: number, panRateDegS: number, tiltRateDegS: number) {
    this.commandVelocity(panRateDegS, tiltRateDegS, dt);
  }

  public nudge(dPanDeg: number, dTiltDeg: number) {
    this.panDeg += dPanDeg;
    this.tiltDeg += dTiltDeg;
  }

  public manualNudge(dPanDeg: number, dTiltDeg: number) {
    this.nudge(dPanDeg, dTiltDeg);
  }

  public reset() {
    this.panDeg = 0.0;
    this.tiltDeg = 0.0;
    this.panVelocity = 0.0;
    this.tiltVelocity = 0.0;
    this.jitterX = 0.0;
    this.jitterY = 0.0;
    this.platformX = 0.0;
    this.platformY = 0.0;
  }

  public getState(): CameraState {
    const [cx, cy] = this.viewportCenter;
    return {
      panDeg: this.panDeg,
      tiltDeg: this.tiltDeg,
      panVelocityDegS: this.panVelocity,
      tiltVelocityDegS: this.tiltVelocity,
      viewportCenterX: cx,
      viewportCenterY: cy,
      resolutionW: this.resolutionW,
      resolutionH: this.resolutionH,
      fovHDeg: this.fovHDeg,
      fovVDeg: this.fovVDeg,
      opticalCenterX: this.resolutionW / 2.0,
      opticalCenterY: this.resolutionH / 2.0,
      worldX: this.worldX,
      worldY: this.worldY,
      worldZ: this.worldZ,
    };
  }
}
