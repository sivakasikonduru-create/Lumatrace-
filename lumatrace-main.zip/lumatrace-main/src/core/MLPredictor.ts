export class LightweightMLPredictor {
  private history: Float32Array[] = [];
  private maxHistory: number = 10;
  
  private w1: Float32Array;
  private b1: Float32Array;
  private w2: Float32Array;
  private b2: Float32Array;
  
  private learningRate = 0.005;

  constructor() {
    this.w1 = new Float32Array(70 * 16).map(() => (Math.random() - 0.5) * 0.1);
    this.b1 = new Float32Array(16).map(() => 0.01);
    this.w2 = new Float32Array(16 * 2).map(() => (Math.random() - 0.5) * 0.1);
    this.b2 = new Float32Array(2).map(() => 0);
  }

  public pushObservation(x: number, y: number, vx: number, vy: number, pan: number, tilt: number, conf: number) {
    // Online training step: if we have history, we can check how good our previous prediction was
    if (this.history.length === this.maxHistory) {
      this.train(x, y, vx, vy);
    }
    
    this.history.push(new Float32Array([x, y, vx, vy, pan, tilt, conf]));
    if (this.history.length > this.maxHistory) {
      this.history.shift();
    }
  }
  
  private train(targetX: number, targetY: number, targetVx: number, targetVy: number) {
    // We try to predict the CURRENT position based on the PAST history (excluding the current observation)
    // Forward pass
    const input = new Float32Array(70);
    for (let i = 0; i < this.maxHistory; i++) {
      input.set(this.history[i], i * 7);
    }

    const hidden = new Float32Array(16);
    for (let i = 0; i < 16; i++) {
      let sum = this.b1[i];
      for (let j = 0; j < 70; j++) {
        sum += input[j] * this.w1[j * 16 + i];
      }
      hidden[i] = Math.max(0, sum); // ReLU
    }

    const output = new Float32Array(2);
    for (let i = 0; i < 2; i++) {
      let sum = this.b2[i];
      for (let j = 0; j < 16; j++) {
        sum += hidden[j] * this.w2[j * 2 + i];
      }
      output[i] = sum;
    }

    // Loss (we want output to match the non-linear residual: dx - expected_linear_dx)
    // For simplicity, we just train it to output the velocity or the residual.
    const last = this.history[this.maxHistory - 1];
    const residualX = targetX - (last[0] + last[2]);
    const residualY = targetY - (last[1] + last[3]);
    
    // MSE gradient
    const dOut0 = (output[0] - residualX);
    const dOut1 = (output[1] - residualY);
    
    // Backprop
    const dHidden = new Float32Array(16);
    for (let i = 0; i < 16; i++) {
      dHidden[i] = dOut0 * this.w2[i * 2 + 0] + dOut1 * this.w2[i * 2 + 1];
      if (hidden[i] <= 0) dHidden[i] = 0; // ReLU derivative
    }
    
    // Update W2, B2
    for (let i = 0; i < 16; i++) {
      this.w2[i * 2 + 0] -= this.learningRate * dOut0 * hidden[i];
      this.w2[i * 2 + 1] -= this.learningRate * dOut1 * hidden[i];
    }
    this.b2[0] -= this.learningRate * dOut0;
    this.b2[1] -= this.learningRate * dOut1;
    
    // Update W1, B1
    for (let i = 0; i < 16; i++) {
      for (let j = 0; j < 70; j++) {
        this.w1[j * 16 + i] -= this.learningRate * dHidden[i] * input[j];
      }
      this.b1[i] -= this.learningRate * dHidden[i];
    }
  }

  public predict(horizon: number = 3): { predX: number, predY: number, uncertainty: number } {
    if (this.history.length < this.maxHistory) {
      return { predX: 0, predY: 0, uncertainty: 100 };
    }

    const input = new Float32Array(70);
    for (let i = 0; i < this.maxHistory; i++) {
      input.set(this.history[i], i * 7);
    }

    const hidden = new Float32Array(16);
    for (let i = 0; i < 16; i++) {
      let sum = this.b1[i];
      for (let j = 0; j < 70; j++) {
        sum += input[j] * this.w1[j * 16 + i];
      }
      hidden[i] = Math.max(0, sum);
    }

    const output = new Float32Array(2);
    for (let i = 0; i < 2; i++) {
      let sum = this.b2[i];
      for (let j = 0; j < 16; j++) {
        sum += hidden[j] * this.w2[j * 2 + i];
      }
      output[i] = sum;
    }

    const last = this.history[this.history.length - 1];
    
    // Output is the predicted residual for 1 frame, we scale it for the horizon
    const predX = last[0] + (last[2] * horizon) + (output[0] * horizon);
    const predY = last[1] + (last[3] * horizon) + (output[1] * horizon);

    // Uncertainty based on output magnitude and confidence
    const uncertainty = Math.min(50, Math.sqrt(output[0]**2 + output[1]**2) * 2 + (1 - last[6]) * 20);

    return { predX, predY, uncertainty };
  }
}
