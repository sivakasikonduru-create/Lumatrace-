export class KalmanFilter2D {
  public x: [number, number, number, number] = [0, 0, 0, 0]; // [x, y, vx, vy]
  public P: number[][] = [
    [100, 0, 0, 0],
    [0, 100, 0, 0],
    [0, 0, 100, 0],
    [0, 0, 0, 100],
  ];
  public q: number = 18.0;
  public r: number = 2.5;
  public isInitialized: boolean = false;
  private dt: number = 0.033;

  constructor(dt: number = 0.033, q: number = 18.0, r: number = 2.5) {
    this.dt = dt;
    this.q = q;
    this.r = r;
  }

  public init(measX: number, measY: number) {
    this.x = [measX, measY, 0, 0];
    this.P = [
      [this.r, 0, 0, 0],
      [0, this.r, 0, 0],
      [0, 0, 50, 0],
      [0, 0, 0, 50],
    ];
    this.isInitialized = true;
  }

  public predict(dt?: number): [number, number, number, number] {
    if (!this.isInitialized) return [0, 0, 0, 0];
    const step = dt !== undefined ? dt : this.dt;

    const [px, py, vx, vy] = this.x;
    const xPred = px + vx * step;
    const yPred = py + vy * step;
    this.x = [xPred, yPred, vx, vy];

    const qPos = this.q * (step * step);
    const qVel = this.q * step;
    this.P[0][0] += qPos;
    this.P[1][1] += qPos;
    this.P[2][2] += qVel;
    this.P[3][3] += qVel;

    return [xPred, yPred, vx, vy];
  }

  public update(measX: number, measY: number) {
    if (!this.isInitialized) {
      this.init(measX, measY);
      return;
    }

    const resX = measX - this.x[0];
    const resY = measY - this.x[1];

    const sX = this.P[0][0] + this.r;
    const sY = this.P[1][1] + this.r;

    const k00 = this.P[0][0] / sX;
    const k11 = this.P[1][1] / sY;
    const k20 = this.P[2][0] / sX;
    const k31 = this.P[3][1] / sY;

    this.x[0] += k00 * resX;
    this.x[1] += k11 * resY;
    this.x[2] += k20 * resX;
    this.x[3] += k31 * resY;

    this.P[0][0] *= 1.0 - k00;
    this.P[1][1] *= 1.0 - k11;
    this.P[2][2] *= 0.95;
    this.P[3][3] *= 0.95;
  }

  public getLookaheadPrediction(lookaheadSeconds: number = 0.1): [number, number] {
    const px = this.x[0] + this.x[2] * lookaheadSeconds;
    const py = this.x[1] + this.x[3] * lookaheadSeconds;
    return [px, py];
  }

  get uncertainty(): number {
    return Math.sqrt(Math.max(0, this.P[0][0] + this.P[1][1]));
  }
}
