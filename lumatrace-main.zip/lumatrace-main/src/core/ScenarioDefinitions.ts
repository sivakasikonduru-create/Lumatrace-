import { DisturbanceConfig, SimulationConfig } from '../types/fsoc';

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  category: 'trajectory' | 'noise' | 'disturbance' | 'atmospheric' | 'stress';
  durationSeconds: number;
  configOverrides: Partial<SimulationConfig>;
  disturbanceOverrides: Partial<DisturbanceConfig>;
  induceLossAtSecond?: number; // for re-acquisition testing
}

export const SIH_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'sih-01',
    name: 'Straight-Line Clear',
    description: 'SIH baseline linear motion across field of view under optimal optical conditions.',
    category: 'trajectory',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'straight_line', targetSpeedPxS: 75 },
    disturbanceOverrides: { noiseType: 'none', atmosphericCondition: 'clear', jitterEnabled: false },
  },
  {
    id: 'sih-02',
    name: 'Circular Clear',
    description: 'Continuous radial orbital tracking testing steady-state tracking error.',
    category: 'trajectory',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'circular', targetSpeedPxS: 80 },
    disturbanceOverrides: { noiseType: 'none', atmosphericCondition: 'clear', jitterEnabled: false },
  },
  {
    id: 'sih-03',
    name: 'Figure-8 Clear',
    description: 'Complex dual-axis curvature dynamic motion verifying acceleration response.',
    category: 'trajectory',
    durationSeconds: 6,
    configOverrides: { targetMotionMode: 'figure_8', targetSpeedPxS: 90 },
    disturbanceOverrides: { noiseType: 'none', atmosphericCondition: 'clear', jitterEnabled: false },
  },
  {
    id: 'sih-04',
    name: 'Random Walk Clear',
    description: 'Non-deterministic Brownian trajectory testing adaptive velocity estimation.',
    category: 'trajectory',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'random', targetSpeedPxS: 85 },
    disturbanceOverrides: { noiseType: 'none', atmosphericCondition: 'clear', jitterEnabled: false },
  },
  {
    id: 'sih-05',
    name: 'Gaussian Sensor Noise',
    description: 'Additive zero-mean Gaussian noise on focal plane (sigma = 14 px).',
    category: 'noise',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'circular', targetSpeedPxS: 75 },
    disturbanceOverrides: { noiseType: 'gaussian', gaussianSigma: 14.0 },
  },
  {
    id: 'sih-06',
    name: 'Salt-and-Pepper Impulsive Noise',
    description: 'Random dead and hot sensor pixels simulating radiation/detector defects.',
    category: 'noise',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'figure_8', targetSpeedPxS: 80 },
    disturbanceOverrides: { noiseType: 'salt_pepper', noiseIntensity: 0.05 },
  },
  {
    id: 'sih-07',
    name: 'Poisson Shot Noise',
    description: 'Signal-dependent photon arrival shot noise in low SNR conditions.',
    category: 'noise',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'straight_line', targetSpeedPxS: 70 },
    disturbanceOverrides: { noiseType: 'poisson', noiseIntensity: 0.08 },
  },
  {
    id: 'sih-08',
    name: 'Camera Mechanical Jitter',
    description: 'High-frequency structural vibration up to ±18 pixels/frame.',
    category: 'disturbance',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'circular', targetSpeedPxS: 80 },
    disturbanceOverrides: { jitterEnabled: true, jitterAmplitudePx: 16.0 },
  },
  {
    id: 'sih-09',
    name: 'Linear Platform Motion',
    description: 'Vehicle/mobile terminal base drift up to ±15 pixels/frame.',
    category: 'disturbance',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'figure_8', targetSpeedPxS: 80 },
    disturbanceOverrides: { platformMotionEnabled: true, platformMotionType: 'linear', platformAmplitudePx: 14.0 },
  },
  {
    id: 'sih-10',
    name: 'Heavy Atmospheric Fog',
    description: 'Aerosol scattering with high contrast attenuation and optical blooming.',
    category: 'atmospheric',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'straight_line', targetSpeedPxS: 70 },
    disturbanceOverrides: { atmosphericCondition: 'fog', contrastReduction: 0.45 },
  },
  {
    id: 'sih-11',
    name: 'Atmospheric Haze',
    description: 'Mild boundary-layer particulate haze with contrast reduction.',
    category: 'atmospheric',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'circular', targetSpeedPxS: 75 },
    disturbanceOverrides: { atmosphericCondition: 'haze', contrastReduction: 0.25 },
  },
  {
    id: 'sih-12',
    name: 'Rain Particle Scattering',
    description: 'Precipitation streaks and dynamic optical absorption.',
    category: 'atmospheric',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'figure_8', targetSpeedPxS: 80 },
    disturbanceOverrides: { atmosphericCondition: 'rain' },
  },
  {
    id: 'sih-13',
    name: 'Low Light / High Attenuation',
    description: 'Sub-optimal ambient irradiance with detector dark-current dominance.',
    category: 'atmospheric',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'random', targetSpeedPxS: 75 },
    disturbanceOverrides: { atmosphericCondition: 'low_light', brightnessReduction: 0.5 },
  },
  {
    id: 'sih-14',
    name: 'High-Speed Target Slew',
    description: 'Target speed escalated to 160 px/s challenging rate limits.',
    category: 'stress',
    durationSeconds: 5,
    configOverrides: { targetMotionMode: 'circular', targetSpeedPxS: 160 },
    disturbanceOverrides: { noiseType: 'none' },
  },
  {
    id: 'sih-15',
    name: 'Target Loss & Autonomous Re-acquisition',
    description: 'Forced optical occlusion at 2.0s testing recovery in under 1.0s.',
    category: 'stress',
    durationSeconds: 6,
    configOverrides: { targetMotionMode: 'figure_8', targetSpeedPxS: 85 },
    disturbanceOverrides: { noiseType: 'gaussian', gaussianSigma: 8.0 },
    induceLossAtSecond: 2.0,
  },
  {
    id: 'sih-16',
    name: 'Combined Maximum Stress Test',
    description: 'Figure-8 + Gaussian noise + Camera jitter + Platform motion + Rain.',
    category: 'stress',
    durationSeconds: 6,
    configOverrides: { targetMotionMode: 'figure_8', targetSpeedPxS: 100 },
    disturbanceOverrides: {
      noiseType: 'gaussian',
      gaussianSigma: 12.0,
      jitterEnabled: true,
      jitterAmplitudePx: 12.0,
      platformMotionEnabled: true,
      platformMotionType: 'circular',
      platformAmplitudePx: 10.0,
      atmosphericCondition: 'rain',
    },
  },
, { id: 'd2d-01',
    name: 'D2D-01: Hover ↔ Hover / Clear',
    description: 'Both drones stationary in 3D space under optimal optical conditions.',
    category: 'trajectory',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'straight_line', targetSpeedPxS: 0, droneAInitialPos: [0, 50, 150], droneBInitialPos: [0, 50, 0] },
    disturbanceOverrides: { atmosphericCondition: 'clear' }
  },
  {
    id: 'd2d-02',
    name: 'D2D-02: One drone moving / Clear',
    description: 'Drone A moving while Drone B hovers.',
    category: 'trajectory',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'straight_line', targetSpeedPxS: 60, droneAInitialPos: [0, 50, 150], droneBInitialPos: [0, 50, 0] },
    disturbanceOverrides: { atmosphericCondition: 'clear' }
  },
  {
    id: 'd2d-03',
    name: 'D2D-03: Both drones moving / Clear',
    description: 'Drone A moving and Drone B moving (via platform motion).',
    category: 'trajectory',
    durationSeconds: 6,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'figure_8', targetSpeedPxS: 70, droneAInitialPos: [-20, 40, 120], droneBInitialPos: [0, 50, 0] },
    disturbanceOverrides: { atmosphericCondition: 'clear', platformMotionEnabled: true, platformMotionType: 'linear', platformAmplitudePx: 10 }
  },
  {
    id: 'd2d-04',
    name: 'D2D-04: Crossing trajectories / Clear',
    description: 'Drones moving in crossing paths.',
    category: 'trajectory',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'random', targetSpeedPxS: 80, droneAInitialPos: [50, 50, 100], droneBInitialPos: [0, 50, 0] },
    disturbanceOverrides: { atmosphericCondition: 'clear', platformMotionEnabled: true, platformMotionType: 'circular' }
  },
  {
    id: 'd2d-05',
    name: 'D2D-05: Closing motion / Haze',
    description: 'Drones approach each other through haze.',
    category: 'atmospheric',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'straight_line', targetSpeedPxS: 50, droneAInitialPos: [0, 50, 200], droneBInitialPos: [0, 50, 0] },
    disturbanceOverrides: { atmosphericCondition: 'haze', contrastReduction: 0.3 }
  },
  {
    id: 'd2d-06',
    name: 'D2D-06: Both moving / Fog',
    description: 'Dual drone motion in dense fog.',
    category: 'atmospheric',
    durationSeconds: 6,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'circular', targetSpeedPxS: 75, droneAInitialPos: [0, 60, 120], droneBInitialPos: [0, 50, 0] },
    disturbanceOverrides: { atmosphericCondition: 'fog', contrastReduction: 0.5, platformMotionEnabled: true, platformAmplitudePx: 12 }
  },
  {
    id: 'd2d-07',
    name: 'D2D-07: Crossing / Rain',
    description: 'Crossing paths during rain disturbance.',
    category: 'atmospheric',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'random', targetSpeedPxS: 80 },
    disturbanceOverrides: { atmosphericCondition: 'rain' }
  },
  {
    id: 'd2d-08',
    name: 'D2D-08: High relative velocity / Turbulence',
    description: 'High relative motion with atmospheric turbulence.',
    category: 'stress',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'figure_8', targetSpeedPxS: 120 },
    disturbanceOverrides: { atmosphericCondition: 'turbulence', turbulenceIntensity: 0.8, jitterEnabled: true }
  },
  {
    id: 'd2d-09',
    name: 'D2D-09: Platform jitter / Fog',
    description: 'Severe mechanical jitter combined with fog.',
    category: 'stress',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'straight_line', targetSpeedPxS: 60 },
    disturbanceOverrides: { atmosphericCondition: 'fog', jitterEnabled: true, jitterAmplitudePx: 18 }
  },
  {
    id: 'd2d-10',
    name: 'D2D-10: Sudden maneuver / Fog + Noise',
    description: 'Unexpected maneuvering in fog with detector noise.',
    category: 'stress',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'random', targetSpeedPxS: 90 },
    disturbanceOverrides: { atmosphericCondition: 'fog', noiseType: 'gaussian', gaussianSigma: 12 }
  },
  {
    id: 'd2d-11',
    name: 'D2D-11: FOV-edge tracking / Haze',
    description: 'Target stays near FOV boundary under hazy conditions.',
    category: 'stress',
    durationSeconds: 5,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'circular', targetSpeedPxS: 100, maxPanSpeedDegS: 2.0, maxTiltSpeedDegS: 2.0 },
    disturbanceOverrides: { atmosphericCondition: 'haze' }
  },
  {
    id: 'd2d-12',
    name: 'D2D-12: Target loss + recovery / Heavy disturbance',
    description: 'Target occlusion and recovery during severe disturbances.',
    category: 'stress',
    durationSeconds: 7,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'figure_8', targetSpeedPxS: 80 },
    disturbanceOverrides: { atmosphericCondition: 'rain', noiseType: 'poisson', jitterEnabled: true },
    induceLossAtSecond: 2.5
  },

, { id: 'd2d-13',
    name: 'D2D-13: Moving Obstacle / Partial Occlusion',
    description: 'Temporary partial LOS obstruction via moving physical obstacle.',
    category: 'stress',
    durationSeconds: 7,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'straight_line', targetSpeedPxS: 50 },
    disturbanceOverrides: { losObstructionEnabled: true, losObstructionSeverity: 'partial' }
  },
  {
    id: 'd2d-14',
    name: 'D2D-14: Complete Occlusion / Fog',
    description: 'Complete LOS block requiring autonomous Kalman predictive coasting.',
    category: 'stress',
    durationSeconds: 8,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'figure_8', targetSpeedPxS: 70 },
    disturbanceOverrides: { atmosphericCondition: 'fog', losObstructionEnabled: true, losObstructionSeverity: 'full' }
  },
  {
    id: 'd2d-15',
    name: 'D2D-15: Camera Rate Saturation',
    description: 'Target pushes camera past its angular rate limits.',
    category: 'stress',
    durationSeconds: 6,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'circular', targetSpeedPxS: 180, maxPanSpeedDegS: 1.5, maxTiltSpeedDegS: 1.5 },
    disturbanceOverrides: { atmosphericCondition: 'clear' }
  },
  {
    id: 'd2d-16',
    name: 'D2D-16: Combined Environmental Stress Test',
    description: 'Turbulence, partial occlusion, and extreme platform jitter.',
    category: 'stress',
    durationSeconds: 10,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'random', targetSpeedPxS: 95 },
    disturbanceOverrides: { atmosphericCondition: 'turbulence', jitterEnabled: true, jitterAmplitudePx: 16, losObstructionEnabled: true, losObstructionSeverity: 'partial' }
  }
];
