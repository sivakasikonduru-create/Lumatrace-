import { PerformanceMetrics, SihComplianceMetric } from '../types/fsoc';

export class MetricsEvaluator {
  public trackingErrors: number[] = [];
  public centroidingErrors: number[] = [];
  public frameTimes: number[] = [];
  public detectionFlags: boolean[] = [];
  public timestamps: number[] = [];
  public firstAcquisitionTime: number | null = null;
  public reacquisitionTimes: number[] = [];
  public saturationEvents: number = 0;

  public reset() {
    this.trackingErrors = [];
    this.centroidingErrors = [];
    this.frameTimes = [];
    this.detectionFlags = [];
    this.timestamps = [];
    this.firstAcquisitionTime = null;
    this.reacquisitionTimes = [];
    this.saturationEvents = 0;
  }

  public recordFrame(
    timestamp: number,
    detected: boolean,
    trackingErrorPx: number,
    centroidingErrorPx: number | null,
    processingTimeMs: number,
    reacquisitionEventTime?: number,
    saturated?: boolean
  ) {
    this.timestamps.push(timestamp);
    this.detectionFlags.push(detected);
    this.trackingErrors.push(trackingErrorPx);
    this.frameTimes.push(processingTimeMs);

    if (centroidingErrorPx !== null) {
      this.centroidingErrors.push(centroidingErrorPx);
    }

    if (detected && this.firstAcquisitionTime === null) {
      this.firstAcquisitionTime = timestamp;
    }

    if (reacquisitionEventTime && reacquisitionEventTime > 0) {
      this.reacquisitionTimes.push(reacquisitionEventTime);
    }
    if (saturated) {
      this.saturationEvents++;
    }
  }

  public computeMetrics(): PerformanceMetrics {
    const totalFrames = this.detectionFlags.length;
    if (totalFrames === 0) {
      return this.getEmptyMetrics();
    }

    const duration =
      this.timestamps.length > 1
        ? this.timestamps[this.timestamps.length - 1] - this.timestamps[0]
        : 0.033;

    const avgProcessingTimeMs =
      this.frameTimes.reduce((a, b) => a + b, 0) / totalFrames;

    const fpsValues = this.frameTimes.map((t) => 1000.0 / Math.max(0.1, t));
    const avgFps = fpsValues.reduce((a, b) => a + b, 0) / fpsValues.length;
    const minFps = Math.min(...fpsValues);
    const processingFps = totalFrames / Math.max(0.001, duration);

    const avgErr =
      this.trackingErrors.reduce((a, b) => a + b, 0) / totalFrames;
    const maxErr = Math.max(...this.trackingErrors);
    const sqErr =
      this.trackingErrors.reduce((a, b) => a + b * b, 0) / totalFrames;
    const rmse = Math.sqrt(sqErr);

    const detectedCount = this.detectionFlags.filter((d) => d).length;
    const lockRetention = (detectedCount / totalFrames) * 100.0;
    const targetLossPct = 100.0 - lockRetention;

    const avgCentroiding =
      this.centroidingErrors.length > 0
        ? this.centroidingErrors.reduce((a, b) => a + b, 0) /
          this.centroidingErrors.length
        : 0.0;

    const acqTime =
      this.firstAcquisitionTime !== null ? this.firstAcquisitionTime : 999.0;
    const reacqTime =
      this.reacquisitionTimes.length > 0
        ? this.reacquisitionTimes.reduce((a, b) => a + b, 0) /
          this.reacquisitionTimes.length
        : 0.0;

    const sihCompliance = {
      acquisitionTime: {
        target: '<= 2.0 s',
        measured: Number(acqTime.toFixed(3)),
        status: acqTime <= 2.0 ? 'PASS' : 'NEEDS IMPROVEMENT',
      } as SihComplianceMetric,
      trackingError: {
        target: '<= 10.0 px',
        measured: Number(avgErr.toFixed(2)),
        status: avgErr <= 10.0 ? 'PASS' : 'NEEDS IMPROVEMENT',
      } as SihComplianceMetric,
      targetLoss: {
        target: '< 5.0 %',
        measured: Number(targetLossPct.toFixed(2)),
        status: targetLossPct < 5.0 ? 'PASS' : 'NEEDS IMPROVEMENT',
      } as SihComplianceMetric,
      reacquisitionTime: {
        target: '<= 1.0 s',
        measured: Number(reacqTime.toFixed(3)),
        status:
          reacqTime <= 1.0 || this.reacquisitionTimes.length === 0
            ? 'PASS'
            : 'NEEDS IMPROVEMENT',
      } as SihComplianceMetric,
      processingSpeed: {
        target: '>= 20.0 FPS',
        measured: Number(avgFps.toFixed(1)),
        status: avgFps >= 20.0 ? 'PASS' : 'NEEDS IMPROVEMENT',
      } as SihComplianceMetric,
    };

    return {
      simulationDurationS: Number(duration.toFixed(2)),
      totalFrames,
      processingFps: Number(processingFps.toFixed(1)),
      minFps: Number(minFps.toFixed(1)),
      avgFps: Number(avgFps.toFixed(1)),
      avgProcessingTimeMs: Number(avgProcessingTimeMs.toFixed(2)),
      acquisitionTimeS: Number(acqTime.toFixed(3)),
      reacquisitionTimeS: Number(reacqTime.toFixed(3)),
      averageTrackingErrorPx: Number(avgErr.toFixed(2)),
      maxTrackingErrorPx: Number(maxErr.toFixed(2)),
      rmsePx: Number(rmse.toFixed(2)),
      targetLossPercentage: Number(targetLossPct.toFixed(2)),
      lockRetentionRate: Number(lockRetention.toFixed(2)),
      averageCentroidingErrorPx: Number(avgCentroiding.toFixed(2)),
      controlSaturationEvents: this.saturationEvents,
      sihCompliance,
    };
  }

  private getEmptyMetrics(): PerformanceMetrics {
    return {
      simulationDurationS: 0,
      totalFrames: 0,
      processingFps: 0,
      minFps: 0,
      avgFps: 0,
      avgProcessingTimeMs: 0,
      acquisitionTimeS: 0,
      reacquisitionTimeS: 0,
      averageTrackingErrorPx: 0,
      maxTrackingErrorPx: 0,
      rmsePx: 0,
      targetLossPercentage: 0,
      lockRetentionRate: 0,
      averageCentroidingErrorPx: 0,
      controlSaturationEvents: 0,
      sihCompliance: {
        acquisitionTime: { target: '<= 2.0 s', measured: 0, status: 'PASS' },
        trackingError: { target: '<= 10.0 px', measured: 0, status: 'PASS' },
        targetLoss: { target: '< 5.0 %', measured: 0, status: 'PASS' },
        reacquisitionTime: { target: '<= 1.0 s', measured: 0, status: 'PASS' },
        processingSpeed: { target: '>= 20.0 FPS', measured: 0, status: 'PASS' },
      },
    };
  }
}
