import { SimulationConfig, TargetState } from '../types/fsoc';

export class TargetSimulator {
  public id: number;
  public size: number;
  public speed: number;
  public motionMode: string;
  public originX: number;
  public originY: number;
  public originZ: number = 0;
  public x: number;
  public y: number;
  public z: number = 0;
  public vx: number = 0;
  public vy: number = 0;
  public vz: number = 0;
  public time: number = 0;
  public isActive: boolean = true;
  private randomHeading: number;
  private randomElevation: number;
  public groundTruthHistory: TargetState[] = [];
  public simulationMode: 'standard' | 'drone_to_drone';

  constructor(config: SimulationConfig, id: number = 0, initialOffset: [number, number] = [0, 0]) {
    this.id = id;
    this.size = config.targetSizePx;
    this.speed = config.targetSpeedPxS;
    this.motionMode = config.targetMotionMode;
    this.simulationMode = config.simulationMode || 'standard';

    if (this.simulationMode === 'drone_to_drone') {
      if (config.droneAInitialPos) {
        this.originX = config.droneAInitialPos[0] + initialOffset[0];
        this.originY = config.droneAInitialPos[1] + initialOffset[1];
        this.originZ = config.droneAInitialPos[2];
      } else {
        this.originX = 0 + initialOffset[0];
        this.originY = 0 + initialOffset[1];
        this.originZ = 100;
      }
    } else {
      if (config.targetInitialPos) {
        this.originX = config.targetInitialPos[0] + initialOffset[0];
        this.originY = config.targetInitialPos[1] + initialOffset[1];
      } else {
        // Start in proximity of camera center (1000, 1000)
        this.originX = config.screenWidth / 2.0 + (Math.random() - 0.5) * 260.0 + initialOffset[0];
        this.originY = config.screenHeight / 2.0 + (Math.random() - 0.5) * 200.0 + initialOffset[1];
      }
    }

    this.x = this.originX;
    this.y = this.originY;
    this.z = this.originZ;
    this.randomHeading = Math.random() * 2 * Math.PI;
    this.randomElevation = (Math.random() - 0.5) * 0.5; // slight up/down
  }

  public reset(newOrigin?: [number, number, number]) {
    this.time = 0;
    if (newOrigin) {
      this.originX = newOrigin[0];
      this.originY = newOrigin[1];
      if (newOrigin[2] !== undefined) this.originZ = newOrigin[2];
    }
    this.x = this.originX;
    this.y = this.originY;
    this.z = this.originZ;
    this.groundTruthHistory = [];
    this.isActive = true;
  }

  public update(dt: number, screenW: number = 2000, screenH: number = 2000): TargetState {
    if (!this.isActive) {
      return {
        id: this.id,
        worldX: this.x,
        worldY: this.y,
        worldZ: this.z,
        vx: 0,
        vy: 0,
        vz: 0,
        sizePx: this.size,
        motionMode: this.motionMode,
        isActive: false,
        timestamp: this.time,
      };
    }

    this.time += dt;
    const t = this.time;

    // Adjust scale based on mode
    const is3D = this.simulationMode === 'drone_to_drone';
    const radiusMultiplier = is3D ? 0.3 : 1.0; 

    switch (this.motionMode) {
      case 'straight_line': {
        const vx = this.speed * 0.85;
        const vy = this.speed * 0.45;
        this.x = this.originX + vx * Math.sin(t * 0.6) * 4.0 * radiusMultiplier;
        this.y = this.originY + vy * Math.sin(t * 0.6) * 4.0 * radiusMultiplier;
        this.vx = vx * 0.6 * Math.cos(t * 0.6) * 4.0 * radiusMultiplier;
        this.vy = vy * 0.6 * Math.cos(t * 0.6) * 4.0 * radiusMultiplier;
        if (is3D) {
           this.z = this.originZ + this.speed * 0.2 * t; // move slightly away
           this.vz = this.speed * 0.2;
        }
        break;
      }
      case 'circular': {
        const radius = 180.0 * radiusMultiplier;
        const omega = this.speed / radius;
        this.x = this.originX + radius * Math.cos(omega * t);
        this.y = this.originY + radius * Math.sin(omega * t);
        this.vx = -radius * omega * Math.sin(omega * t);
        this.vy = radius * omega * Math.cos(omega * t);
        if (is3D) {
           this.z = this.originZ;
           this.vz = 0;
        }
        break;
      }
      case 'figure_8': {
        const scale = 220.0 * radiusMultiplier;
        const omega = (this.speed / scale) * 1.25;
        this.x = this.originX + scale * Math.sin(omega * t);
        this.y = this.originY + scale * 0.5 * Math.sin(2 * omega * t);
        this.vx = scale * omega * Math.cos(omega * t);
        this.vy = scale * omega * Math.cos(2 * omega * t);
        break;
      }
      case 'spiral': {
        const rMax = 240.0 * radiusMultiplier;
        const omega = 1.2;
        const r = (t * 18.0 * radiusMultiplier) % rMax;
        this.x = this.originX + r * Math.cos(omega * t);
        this.y = this.originY + r * Math.sin(omega * t);
        this.vx = 18.0 * radiusMultiplier * Math.cos(omega * t) - r * omega * Math.sin(omega * t);
        this.vy = 18.0 * radiusMultiplier * Math.sin(omega * t) + r * omega * Math.cos(omega * t);
        break;
      }
      case 'sinusoidal': {
        const wavelength = 240.0 * radiusMultiplier;
        const amplitude = 120.0 * radiusMultiplier;
        const cycleX = (this.speed * t * 0.8) % (800 * radiusMultiplier) - (400 * radiusMultiplier);
        this.x = this.originX + cycleX;
        this.y = this.originY + amplitude * Math.sin((2 * Math.PI * cycleX) / wavelength);
        this.vx = this.speed * 0.8;
        this.vy = amplitude * ((2 * Math.PI * this.vx) / wavelength) * Math.cos((2 * Math.PI * cycleX) / wavelength);
        break;
      }
      case 'random':
      default: {
        this.randomHeading += (Math.random() - 0.5) * 0.35;
        if (is3D) {
           this.randomElevation += (Math.random() - 0.5) * 0.2;
           this.vx = this.speed * Math.cos(this.randomHeading) * Math.cos(this.randomElevation);
           this.vy = this.speed * Math.sin(this.randomElevation);
           this.vz = this.speed * Math.sin(this.randomHeading) * Math.cos(this.randomElevation);
        } else {
           this.vx = this.speed * Math.cos(this.randomHeading);
           this.vy = this.speed * Math.sin(this.randomHeading);
        }
        
        this.x += this.vx * dt;
        this.y += this.vy * dt;
        this.z += this.vz * dt;

        if (!is3D) {
          // Boundaries bounce inside 2000x2000
          const pad = 120;
          if (this.x < pad) {
            this.x = pad;
            this.randomHeading = Math.PI - this.randomHeading;
          } else if (this.x > screenW - pad) {
            this.x = screenW - pad;
            this.randomHeading = Math.PI - this.randomHeading;
          }
          if (this.y < pad) {
            this.y = pad;
            this.randomHeading = -this.randomHeading;
          } else if (this.y > screenH - pad) {
            this.y = screenH - pad;
            this.randomHeading = -this.randomHeading;
          }
        }
        break;
      }
    }

    const state: TargetState = {
      id: this.id,
      worldX: this.x,
      worldY: this.y,
      worldZ: this.z,
      vx: this.vx,
      vy: this.vy,
      vz: this.vz,
      sizePx: this.size,
      motionMode: this.motionMode,
      isActive: this.isActive,
      timestamp: this.time,
    };

    this.groundTruthHistory.push(state);
    if (this.groundTruthHistory.length > 500) {
      this.groundTruthHistory.shift();
    }

    return state;
  }
}
