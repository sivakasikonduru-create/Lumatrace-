import { SimulationConfig, TrackingState } from '../types/fsoc';
import { VirtualCamera } from './VirtualCamera';

export interface TrackingController {
  computeControl(camera: VirtualCamera, state: TrackingState, dt: number): { panRate: number, tiltRate: number, saturated: boolean };
}

export class BaselineReactiveController implements TrackingController {
  private kpPan: number = 0.85;
  private kpTilt: number = 0.85;
  private maxPanSpeed: number;
  private maxTiltSpeed: number;

  constructor(config: SimulationConfig) {
    this.maxPanSpeed = config.maxPanSpeedDegS;
    this.maxTiltSpeed = config.maxTiltSpeedDegS;
  }

  public computeControl(camera: VirtualCamera, state: TrackingState, dt: number): { panRate: number, tiltRate: number, saturated: boolean } {
    if (state.stateLabel === 'LOST') {
      return { panRate: 0, tiltRate: 0, saturated: false };
    }

    // Offset from camera optical center
    const dx = state.currentX - camera.resolutionW / 2.0;
    const dy = state.currentY - camera.resolutionH / 2.0;

    // Angular error in degrees
    const errPanDeg = dx / camera.pxPerDegH;
    const errTiltDeg = dy / camera.pxPerDegV;

    // Proportional rate control
    let panRate = this.kpPan * errPanDeg * 3.0;
    let tiltRate = this.kpTilt * errTiltDeg * 3.0;

    // Clamp to SIH maximums
    panRate = Math.max(-this.maxPanSpeed, Math.min(this.maxPanSpeed, panRate));
    tiltRate = Math.max(-this.maxTiltSpeed, Math.min(this.maxTiltSpeed, tiltRate));

    const saturated = Math.abs(panRate) >= this.maxPanSpeed || Math.abs(tiltRate) >= this.maxTiltSpeed;
    return { panRate, tiltRate, saturated };
  }
}

export class LumaTracePredictiveController implements TrackingController {
  private kpPan: number = 1.05;
  private kpTilt: number = 1.05;
  private kFf: number = 0.85; // Feedforward velocity gain
  private maxPanSpeed: number;
  private maxTiltSpeed: number;
  private searchAngle: number = 0;

  constructor(config: SimulationConfig) {
    this.maxPanSpeed = config.maxPanSpeedDegS;
    this.maxTiltSpeed = config.maxTiltSpeedDegS;
  }

  public computeControl(camera: VirtualCamera, state: TrackingState, dt: number): { panRate: number, tiltRate: number, saturated: boolean } {
    // Autonomous search states when lost
    if (state.stateLabel === 'TARGET_LOST' || state.stateLabel === 'PREDICTIVE_SEARCH') {
      // Continue along last known target velocity to catch up and prevent loss
      const panFf = (state.velocityX / camera.pxPerDegH) * 1.1;
      const tiltFf = (state.velocityY / camera.pxPerDegV) * 1.1;

      const panRate = Math.max(-this.maxPanSpeed, Math.min(this.maxPanSpeed, panFf));
      const tiltRate = Math.max(-this.maxTiltSpeed, Math.min(this.maxTiltSpeed, tiltFf));
      return { panRate, tiltRate, saturated: false };
    } else if (state.stateLabel === 'LOST' || state.stateLabel === 'SCANNING') {
      // Expanding search spiral
      this.searchAngle += 3.2 * dt;
      const panRate = this.maxPanSpeed * 0.7 * Math.sin(this.searchAngle);
      const tiltRate = this.maxTiltSpeed * 0.7 * Math.cos(this.searchAngle * 0.5);
      return { panRate, tiltRate, saturated: false };
    }

    // Predictive tracking using LOOKAHEAD position
    const dx = state.predictedX - camera.resolutionW / 2.0;
    const dy = state.predictedY - camera.resolutionH / 2.0;

    const errPanDeg = dx / camera.pxPerDegH;
    const errTiltDeg = dy / camera.pxPerDegV;

    const ffPanDegS = (state.velocityX / camera.pxPerDegH) * this.kFf;
    const ffTiltDegS = (state.velocityY / camera.pxPerDegV) * this.kFf;

    let panRate = this.kpPan * errPanDeg * 3.2 + ffPanDegS;
    let tiltRate = this.kpTilt * errTiltDeg * 3.2 + ffTiltDegS;

    panRate = Math.max(-this.maxPanSpeed, Math.min(this.maxPanSpeed, panRate));
    tiltRate = Math.max(-this.maxTiltSpeed, Math.min(this.maxTiltSpeed, tiltRate));

    const saturated = Math.abs(panRate) >= this.maxPanSpeed || Math.abs(tiltRate) >= this.maxTiltSpeed;
    return { panRate, tiltRate, saturated };
  }
}
