import { KalmanFilter2D } from './KalmanFilter';
import { LightweightMLPredictor } from './MLPredictor';
import { DetectionResult, RiskLevel, TrackingState, TrackingStateLabel, DisturbanceConfig } from '../types/fsoc';

export class TrackingEngine {
  private kalman: KalmanFilter2D;
  private mlPredictor: LightweightMLPredictor;
  
  private consecutiveHits = 0;
  private consecutiveMisses = 0;
  private timeLostMs = 0;
  private isRecovering = false;
  private lastFailureCause: string | null = null;
  
  private lastKnownX = 320;
  private lastKnownY = 240;

  constructor() {
    this.kalman = new KalmanFilter2D();
    this.mlPredictor = new LightweightMLPredictor();
  }

  public update(detection: DetectionResult, dt: number, distConfig?: DisturbanceConfig): TrackingState {
    let stateLabel: TrackingStateLabel = 'SEARCHING';
    const cameraW = 640;
    const cameraH = 480;

    if (detection.detected) {
      this.consecutiveHits++;
      this.consecutiveMisses = 0;
      this.timeLostMs = 0;
      this.isRecovering = false;
      this.lastFailureCause = null;
      
      this.kalman.predict(dt);
      this.kalman.update(detection.centroidX, detection.centroidY);
      
      
      const kX = this.kalman.x;
      const kState = {
        x: kX[0],
        y: kX[1],
        vx: kX[2],
        vy: kX[3],
        p: this.kalman.uncertainty
      };

      
      // Update ML
      this.mlPredictor.pushObservation(
        detection.centroidX, 
        detection.centroidY, 
        kState.vx, 
        kState.vy, 
        0, 0, 
        detection.confidence
      );

      stateLabel = this.consecutiveHits > 5 ? 'CENTERED' : 'TRACKING';
      this.lastKnownX = kState.x;
      this.lastKnownY = kState.y;

    } else {
      this.consecutiveMisses++;
      this.consecutiveHits = 0;
      this.timeLostMs += dt * 1000;
      
      // Intelligent Autonomous Re-Acquisition Coasting
      // In a real system, we expand the search uncertainty cone.
      this.kalman.predict(dt);

      if (this.consecutiveMisses === 1) {
        // Record failure cause on first miss
        if (distConfig?.losObstructionEnabled && distConfig.losObstructionSeverity === 'full') {
          this.lastFailureCause = "Complete LOS Obstruction";
        } else if (distConfig?.atmosphericCondition === 'fog' || distConfig?.atmosphericCondition === 'rain') {
          this.lastFailureCause = "Atmospheric Attenuation (SNR Loss)";
        } else {
          
      const kX = this.kalman.x;
      const kState = {
        x: kX[0],
        y: kX[1],
        vx: kX[2],
        vy: kX[3],
        p: this.kalman.uncertainty
      };

          if (kState.x < 0 || kState.x > cameraW || kState.y < 0 || kState.y > cameraH) {
             this.lastFailureCause = "FOV Exit (Angular Rate Exceeded)";
          } else {
             this.lastFailureCause = "Detection Pipeline Failure (Low Contrast)";
          }
        }
      }

      if (this.timeLostMs < 1000) {
        stateLabel = 'LOST';
      } else {
        stateLabel = 'REACQUIRING';
        this.isRecovering = true;
      }
    }

    
      const kX = this.kalman.x;
      const kState = {
        x: kX[0],
        y: kX[1],
        vx: kX[2],
        vy: kX[3],
        p: this.kalman.uncertainty
      };

    const mlPred = this.mlPredictor.predict(3); // 3 frames ahead

    // Uncertainty-aware fusion: if detection is confident, blend Kalman and ML.
    // If lost, rely purely on Kalman coasting geometry.
    const blendFactor = detection.detected ? Math.max(0, 1 - (mlPred.uncertainty / 100)) : 0;
    
    const fusedPredX = (kState.x + kState.vx * 3) * (1 - blendFactor) + mlPred.predX * blendFactor;
    const fusedPredY = (kState.y + kState.vy * 3) * (1 - blendFactor) + mlPred.predY * blendFactor;

    const { riskLevel, riskReason, predictedFovLoss } = this.assessRisk(
      detection.detected, 
      kState.x, 
      kState.y, 
      fusedPredX, 
      fusedPredY, 
      detection.confidence,
      cameraW,
      cameraH
    );

    return {
      stateLabel,
      currentX: kState.x,
      currentY: kState.y,
      predictedX: fusedPredX,
      predictedY: fusedPredY,
      velocityX: kState.vx,
      velocityY: kState.vy,
      uncertainty: kState.p + mlPred.uncertainty,
      confidence: detection.confidence,
      consecutiveHits: this.consecutiveHits,
      consecutiveMisses: this.consecutiveMisses,
      reacquisitionTimeS: this.isRecovering ? this.timeLostMs / 1000 : 0,
      riskLevel,
      riskReason,
      predictedFovLoss,
      failureCause: this.lastFailureCause,
      controlSaturated: false
    };
  }

  private assessRisk(
    detected: boolean, 
    x: number, 
    y: number, 
    predX: number, 
    predY: number, 
    conf: number,
    cameraW: number,
    cameraH: number
  ): { riskLevel: RiskLevel; riskReason: string; predictedFovLoss: 'LOW'|'MEDIUM'|'HIGH' } {
    if (!detected) {
      return { 
        riskLevel: 'LOST', 
        riskReason: 'Target lost. Engaging predictive coasting/recovery.',
        predictedFovLoss: 'HIGH'
      };
    }

    const marginX = Math.min(predX, cameraW - predX);
    const marginY = Math.min(predY, cameraH - predY);
    const margin = Math.min(marginX, marginY);

    let predictedFovLoss: 'LOW' | 'MEDIUM' | 'HIGH' = 'LOW';
    if (margin < 0) {
      predictedFovLoss = 'HIGH';
    } else if (margin < 50) {
      predictedFovLoss = 'MEDIUM';
    }

    if (margin < 20) {
      return { 
        riskLevel: 'HIGH RISK', 
        riskReason: 'Imminent FOV exit predicted. Saturating control rates.',
        predictedFovLoss
      };
    }

    if (conf < 0.4) {
      return { 
        riskLevel: 'WARNING', 
        riskReason: 'Atmospheric degradation reducing SNR. Relying heavily on temporal memory.',
        predictedFovLoss
      };
    }

    return { 
      riskLevel: 'SAFE', 
      riskReason: 'Nominal intelligent predictive tracking.',
      predictedFovLoss
    };
  }

  public reset() {
    this.kalman = new KalmanFilter2D();
    this.mlPredictor = new LightweightMLPredictor();
    this.consecutiveHits = 0;
    this.consecutiveMisses = 0;
    this.timeLostMs = 0;
    this.isRecovering = false;
    this.lastFailureCause = null;
  }
}
