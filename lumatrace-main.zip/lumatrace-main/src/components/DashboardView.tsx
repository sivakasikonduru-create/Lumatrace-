import React, { useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  EyeOff,
  Crosshair,
  Zap,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Target,
  CheckCircle2,
  AlertTriangle,
  Radio,
} from 'lucide-react';
import {
  CameraState,
  DetectionResult,
  SimulationConfig,
  TargetState,
  TrackingState,
} from '../types/fsoc';

interface DashboardViewProps {
  isRunning: boolean;
  onToggleRunning: () => void;
  onReset: () => void;
  onInduceLoss: () => void;
  onManualNudge: (panDeg: number, tiltDeg: number) => void;
  config: SimulationConfig;
  onUpdateConfig: (partial: Partial<SimulationConfig>) => void;
  cameraState: CameraState;
  targetState: TargetState;
  detection: DetectionResult;
  tracking: TrackingState;
  groundTruthHistory: { x: number; y: number }[];
  fps: number;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  isRunning,
  onToggleRunning,
  onReset,
  onInduceLoss,
  onManualNudge,
  config,
  onUpdateConfig,
  cameraState,
  targetState,
  detection,
  tracking,
  groundTruthHistory,
  fps,
  canvasRef,
}) => {
  const minimapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Render 2000x2000 Minimap onto secondary canvas
  useEffect(() => {
    const canvas = minimapCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const scale = width / config.screenWidth; // ~320 / 2000 = 0.16

    // Dark background matching Geometric Balance
    ctx.fillStyle = '#050608';
    ctx.fillRect(0, 0, width, height);

    // Subtle technical grid lines
    ctx.strokeStyle = '#1F2937';
    ctx.lineWidth = 1;
    const gridStep = 400 * scale;
    for (let x = 0; x < width; x += gridStep) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += gridStep) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Screen Boundary
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(1, 1, width - 2, height - 2);

    // Target Ground Truth trajectory history (cyan trail)
    if (groundTruthHistory.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(34, 211, 238, 0.35)';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < groundTruthHistory.length; i++) {
        const pt = groundTruthHistory[i];
        const px = pt.x * scale;
        const py = pt.y * scale;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }

    // Target Ground Truth Position (bright red beacon)
    const targetPx = targetState.worldX * scale;
    const targetPy = targetState.worldY * scale;

    ctx.beginPath();
    ctx.arc(targetPx, targetPy, 10, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(targetPx, targetPy, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#ef4444';
    ctx.fill();

    // Camera Current FOV Footprint on 2000x2000 screen
    const fovW = (config.cameraResWidth / (config.screenWidth / config.screenDistanceMm)) * 5;
    const fovH = (config.cameraResHeight / (config.screenHeight / config.screenDistanceMm)) * 5;
    const camX = cameraState.viewportCenterX * scale - fovW / 2;
    const camY = cameraState.viewportCenterY * scale - fovH / 2;

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(camX, camY, fovW, fovH);

    // Camera Optical Center Point
    ctx.beginPath();
    ctx.arc(cameraState.viewportCenterX * scale, cameraState.viewportCenterY * scale, 3, 0, Math.PI * 2);
    ctx.fillStyle = '#38bdf8';
    ctx.fill();

    // Laser Link Line if target is inside FOV
    if (detection.detected) {
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.6)';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.moveTo(cameraState.viewportCenterX * scale, cameraState.viewportCenterY * scale);
      ctx.lineTo(targetPx, targetPy);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }, [cameraState, targetState, groundTruthHistory, config, detection.detected]);

  // Normalize angles for meter display
  const panMeterPercent = Math.min(100, Math.max(0, ((cameraState.panDeg + 5) / 10) * 100));
  const tiltMeterPercent = Math.min(100, Math.max(0, ((cameraState.tiltDeg + 5) / 10) * 100));

  // Risk bars calculation
  const getRiskBars = () => {
    switch (tracking.riskLevel) {
      case 'SAFE':
        return [true, true, true, false, false];
      case 'WARNING':
        return [true, true, true, true, false];
      case 'HIGH_RISK':
      case 'LOST':
        return [true, true, true, true, true];
      default:
        return [true, false, false, false, false];
    }
  };
  const riskBars = getRiskBars();

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Top Operations Action Bar (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-2.5">
          <button
            id="dash-toggle-btn"
            onClick={onToggleRunning}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-bold uppercase tracking-wider text-xs shadow-sm transition-all ${
              isRunning
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-cyan-600 hover:bg-cyan-500 text-white'
            }`}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isRunning ? 'Pause Loop' : 'Run Simulation'}</span>
          </button>

          <button
            id="dash-reset-btn"
            onClick={onReset}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-white font-bold uppercase tracking-wider text-xs border border-[#374151] transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>

          <button
            id="dash-occlusion-btn"
            onClick={onInduceLoss}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800/80 font-bold uppercase tracking-wider text-xs transition"
            title="Temporarily occlude beacon to verify autonomous re-acquisition in <= 1.0s"
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>Induce Optical Loss</span>
          </button>
        </div>

        {/* Controller & Trajectory Selectors */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-[#0A0B10] border border-[#1F2937] rounded-md p-1 text-xs">
            <span className="text-gray-400 px-2 font-mono text-[11px]">CONTROLLER:</span>
            <button
              id="dash-ctrl-baseline"
              onClick={() => onUpdateConfig({ controllerType: 'baseline' })}
              className={`px-3 py-1 rounded text-xs uppercase font-bold tracking-wider transition ${
                config.controllerType === 'baseline'
                  ? 'bg-[#1F2937] text-white'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              Baseline
            </button>
            <button
              id="dash-ctrl-predictive"
              onClick={() => onUpdateConfig({ controllerType: 'predictive' })}
              className={`px-3 py-1 rounded text-xs uppercase font-bold tracking-wider transition flex items-center gap-1.5 ${
                config.controllerType === 'predictive'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Target className="w-3 h-3 text-amber-300" />
              LumaTrace
            </button>
          </div>

          <div className="flex items-center gap-2 bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-1.5 text-xs">
            <span className="text-gray-400 font-mono text-[11px]">MOTION:</span>
            <select
              id="dash-motion-select"
              value={config.targetMotionMode}
              onChange={(e) => onUpdateConfig({ targetMotionMode: e.target.value as any })}
              className="bg-transparent text-cyan-400 font-mono font-medium focus:outline-none cursor-pointer text-xs uppercase"
            >
              <option value="straight_line" className="bg-[#0F1117] text-white">Straight Line</option>
              <option value="circular" className="bg-[#0F1117] text-white">Circular</option>
              <option value="figure_8" className="bg-[#0F1117] text-white">Figure of 8</option>
              <option value="random" className="bg-[#0F1117] text-white">Random Walk</option>
              <option value="spiral" className="bg-[#0F1117] text-white">Spiral</option>
              <option value="sinusoidal" className="bg-[#0F1117] text-white">Sinusoidal</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Section: Optical Camera Sensor Stage + Right Telemetry Sidebars */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left / Center Section (Optical Viewport & Minimap) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Primary Viewport Optical Stage (Geometric Balance) */}
          <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <h3 className="text-xs font-bold uppercase tracking-widest text-white">
                  Camera Optical Sensor Viewport (640×480 • FOV 4°×3°)
                </h3>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="text-gray-400">Centroid:</span>
                <span className="text-cyan-400 font-semibold">
                  {detection.detected
                    ? `[${(detection.centroidX ?? 0).toFixed(1)}, ${(detection.centroidY ?? 0).toFixed(1)}]`
                    : 'LOST'}
                </span>
              </div>
            </div>

            {/* Viewport Frame with Geometric Balance dot grid and HUD reticle */}
            <div className="relative w-full aspect-[4/3] rounded-lg overflow-hidden border border-[#1F2937] bg-[#050608] flex items-center justify-center shadow-inner">
              {/* Subtle technical cyan dot matrix grid */}
              <div
                className="absolute inset-0 opacity-10 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(#22D3EE 0.5px, transparent 0.5px)',
                  backgroundSize: '20px 20px',
                }}
              />

              {/* Geometric Dashed Crosshair Alignment Overlay */}
              <div className="absolute inset-0 flex items-center justify-center opacity-25 pointer-events-none">
                <div className="w-[75%] h-[75%] border border-cyan-500/40 border-dashed" />
                <div className="absolute w-px h-full bg-cyan-500/20" />
                <div className="absolute h-px w-full bg-cyan-500/20" />
              </div>

              {/* Centering Circular Reticle */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-28 h-28 border border-cyan-400/30 rounded-full flex items-center justify-center">
                  <div className="w-8 h-8 border border-cyan-400/60 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
                  </div>
                </div>
              </div>

              {/* The real computer-vision frame rendered into canvas */}
              <canvas
                ref={canvasRef}
                width={640}
                height={480}
                className="w-full h-full object-contain relative z-10"
              />

              {/* SVG Overlays */}
              <svg
                className="absolute inset-0 w-full h-full pointer-events-none z-20"
                viewBox="0 0 640 480"
                preserveAspectRatio="xMidYMid meet"
              >
                {/* Optical Center Crosshairs */}
                <line x1={320 - 24} y1={240} x2={320 + 24} y2={240} stroke="#38bdf8" strokeWidth="1.5" />
                <line x1={320} y1={240 - 24} x2={320} y2={240 + 24} stroke="#38bdf8" strokeWidth="1.5" />
                <circle cx={320} cy={240} r={10} fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="3,3" />

                {/* Detected Beacon Bounding Box & Centroid */}
                {detection.detected && (
                  <>
                    <rect
                      x={detection.bbox[0]}
                      y={detection.bbox[1]}
                      width={detection.bbox[2]}
                      height={detection.bbox[3]}
                      fill="none"
                      stroke="#22c55e"
                      strokeWidth="1.5"
                    />
                    <circle cx={detection.centroidX} cy={detection.centroidY} r={3} fill="#22c55e" />

                    {/* Error Vector Line */}
                    <line
                      x1={320}
                      y1={240}
                      x2={detection.centroidX}
                      y2={detection.centroidY}
                      stroke="rgba(239, 68, 68, 0.75)"
                      strokeWidth="1.5"
                      strokeDasharray="4,4"
                    />
                  </>
                )}

                {/* Kalman Filter Predicted Position Marker */}
                {tracking.stateLabel !== 'LOST' && (
                  <g>
                    <circle
                      cx={tracking.predictedX}
                      cy={tracking.predictedY}
                      r={7}
                      fill="none"
                      stroke="#a855f7"
                      strokeWidth="1.5"
                    />
                    <line
                      x1={tracking.predictedX - 4}
                      y1={tracking.predictedY}
                      x2={tracking.predictedX + 4}
                      y2={tracking.predictedY}
                      stroke="#a855f7"
                      strokeWidth="1"
                    />
                    <line
                      x1={tracking.predictedX}
                      y1={tracking.predictedY - 4}
                      x2={tracking.predictedX}
                      y2={tracking.predictedY + 4}
                      stroke="#a855f7"
                      strokeWidth="1"
                    />
                  </g>
                )}
              </svg>

              {/* Beacon Lock HUD Tag (Geometric Balance element) */}
              {detection.detected && (
                <div
                  className="absolute z-20 pointer-events-none transition-all duration-75"
                  style={{
                    left: `${(detection.centroidX / 640) * 100}%`,
                    top: `${(detection.centroidY / 480) * 100}%`,
                    transform: 'translate(-50%, -50%)',
                  }}
                >
                  <div className="w-12 h-12 border-2 border-red-500 animate-pulse rounded flex items-center justify-center relative">
                    <div className="absolute -top-6 -right-20 bg-red-950/90 border border-red-500 px-2 py-0.5 text-[9px] text-white font-mono uppercase tracking-wider whitespace-nowrap shadow">
                      BEACON_01 : LOCKED
                    </div>
                  </div>
                </div>
              )}

              {/* Visual Feed Watermark (Top Left) */}
              <div className="absolute top-3 left-3 z-20 bg-black/70 backdrop-blur-sm border border-white/10 px-2.5 py-1.5 rounded text-[10px] font-mono text-cyan-300">
                <div className="text-gray-400 text-[9px]">VISUAL_FEED: VIRTUAL_FSOC_TERM_01</div>
                <div>COORD: X:{(targetState.worldX ?? 0).toFixed(1)} Y:{(targetState.worldY ?? 0).toFixed(1)} | Z:0.0</div>
              </div>

              {/* Top Right Error Readout */}
              <div className="absolute top-3 right-3 z-20 bg-black/70 backdrop-blur-sm border border-white/10 px-2.5 py-1.5 rounded text-[10px] font-mono flex items-center gap-2">
                <span className="text-gray-400">ERROR:</span>
                <span className={(detection.euclideanError ?? 0) <= 10 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                  {(detection.euclideanError ?? 0).toFixed(1)} px
                </span>
              </div>

              {/* Bottom Left Risk Assessment HUD (Geometric Balance) */}
              <div className="absolute bottom-3 left-3 z-20 bg-black/70 backdrop-blur-sm border border-white/10 p-2.5 rounded-lg text-[10px] font-mono">
                <div className="text-gray-400 text-[9px] uppercase tracking-wider mb-1">Risk Assessment</div>
                <div className="flex gap-1 mb-1">
                  {riskBars.map((active, i) => (
                    <div
                      key={i}
                      className={`w-4 h-1.5 rounded-sm ${
                        active
                          ? tracking.riskLevel === 'SAFE'
                            ? 'bg-emerald-500'
                            : tracking.riskLevel === 'WARNING'
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                          : 'bg-gray-800'
                      }`}
                    />
                  ))}
                </div>
                <div className="font-bold uppercase tracking-wider text-emerald-400">
                  {tracking.riskLevel === 'SAFE' && 'Low Risk • Nominal'}
                  {tracking.riskLevel === 'WARNING' && 'Warning • Jitter Alert'}
                  {tracking.riskLevel === 'HIGH_RISK' && 'High Risk • Edge Boundary'}
                  {tracking.riskLevel === 'LOST' && 'Occluded • Seeking Beacon'}
                </div>
              </div>

              {/* Bottom Right Confidence */}
              <div className="absolute bottom-3 right-3 z-20 bg-black/70 backdrop-blur-sm border border-white/10 px-2.5 py-1.5 rounded text-[10px] font-mono text-emerald-300">
                CONFIDENCE: {((detection.confidence ?? 0) * 100).toFixed(1)}%
              </div>
            </div>

            {/* Bottom PTZ Jog Nudge Pad */}
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#1F2937] pt-3">
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-400 font-mono">MANUAL PTZ NUDGE:</span>
                <div className="flex items-center gap-1.5">
                  <button
                    id="nudge-left"
                    onClick={() => onManualNudge(-0.25, 0)}
                    className="p-1.5 rounded bg-[#1F2937] hover:bg-[#283548] text-white border border-[#374151] transition"
                    title="Pan Left (-0.25°)"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    id="nudge-up"
                    onClick={() => onManualNudge(0, -0.25)}
                    className="p-1.5 rounded bg-[#1F2937] hover:bg-[#283548] text-white border border-[#374151] transition"
                    title="Tilt Up (-0.25°)"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    id="nudge-down"
                    onClick={() => onManualNudge(0, 0.25)}
                    className="p-1.5 rounded bg-[#1F2937] hover:bg-[#283548] text-white border border-[#374151] transition"
                    title="Tilt Down (+0.25°)"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    id="nudge-right"
                    onClick={() => onManualNudge(0.25, 0)}
                    className="p-1.5 rounded bg-[#1F2937] hover:bg-[#283548] text-white border border-[#374151] transition"
                    title="Pan Right (+0.25°)"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="text-xs font-mono text-gray-400">
                Rate Limit: <span className="text-cyan-400 font-semibold">5.0°/s MAX</span> (SIH Compliance)
              </div>
            </div>
          </div>

          {/* Minimap (2000x2000 Virtual FSOC Scene) */}
          <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-cyan-400" />
                <h3 className="text-xs font-bold uppercase tracking-widest text-white">
                  Virtual Scene Minimap (2000×2000 mm • Full Workspace)
                </h3>
              </div>
              <span className="text-[10px] font-mono text-gray-400">Scale: 15%</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              <div className="md:col-span-5 aspect-square max-w-[280px] mx-auto w-full rounded-lg overflow-hidden border border-[#1F2937] bg-[#050608] flex items-center justify-center">
                <canvas
                  ref={minimapCanvasRef}
                  width={320}
                  height={320}
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="md:col-span-7 space-y-2 text-xs font-mono text-gray-400 bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3">
                <div className="flex justify-between border-b border-[#1F2937] pb-1.5">
                  <span>Target Ground Truth:</span>
                  <span className="text-amber-400 font-bold">
                    X:{(targetState.worldX ?? 0).toFixed(1)}, Y:{(targetState.worldY ?? 0).toFixed(1)}
                  </span>
                </div>
                <div className="flex justify-between border-b border-[#1F2937] pb-1.5">
                  <span>Target Ground Velocity:</span>
                  <span className="text-slate-300">
                    Vx:{(targetState.vx ?? 0).toFixed(1)}, Vy:{(targetState.vy ?? 0).toFixed(1)}
                  </span>
                </div>
                <div className="flex justify-between border-b border-[#1F2937] pb-1.5">
                  <span>Camera Center (World):</span>
                  <span className="text-cyan-400">
                    X:{(cameraState.viewportCenterX ?? 0).toFixed(1)}, Y:{(cameraState.viewportCenterY ?? 0).toFixed(1)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Field of View Footprint:</span>
                  <span className="text-slate-300">140 × 105 mm at 2.0m</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Section: Live Telemetry & System Events (Geometric Balance Right Column) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          {/* Live Telemetry Panel */}
          <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-5 border-b border-[#1F2937] pb-3">
              Live Telemetry
            </h3>

            <div className="space-y-5">
              {/* Pan Angle with Meter Bar */}
              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Pan Angle</span>
                  <span className="text-2xl font-mono text-white font-bold">
                    {(cameraState.panDeg ?? 0).toFixed(2)}°
                  </span>
                </div>
                <div className="w-full h-1.5 bg-[#1F2937] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-500 transition-all duration-100"
                    style={{ width: `${panMeterPercent}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] font-mono text-gray-500 mt-1">
                  <span>-5.0°</span>
                  <span>Rate: {(cameraState.panVelocityDegS ?? 0).toFixed(1)}°/s</span>
                  <span>+5.0°</span>
                </div>
              </div>

              {/* Tilt Angle with Meter Bar */}
              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Tilt Angle</span>
                  <span className="text-2xl font-mono text-white font-bold">
                    {(cameraState.tiltDeg ?? 0).toFixed(2)}°
                  </span>
                </div>
                <div className="w-full h-1.5 bg-[#1F2937] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-500 transition-all duration-100"
                    style={{ width: `${tiltMeterPercent}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] font-mono text-gray-500 mt-1">
                  <span>-5.0°</span>
                  <span>Rate: {(cameraState.tiltVelocityDegS ?? 0).toFixed(1)}°/s</span>
                  <span>+5.0°</span>
                </div>
              </div>

              {/* Tracking Error with Status Pill */}
              <div className="pt-2 border-t border-[#1F2937]">
                <div className="flex justify-between items-baseline mb-1">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Tracking Error</span>
                  <span className="text-[10px] font-bold text-green-400 px-2 py-0.5 border border-green-500/50 rounded bg-green-950/30">
                    {(detection.euclideanError ?? 0) <= 10.0 ? 'PASS (≤10px)' : 'WARN (>10px)'}
                  </span>
                </div>
                <div className="text-3xl font-mono text-amber-400 font-bold">
                  {(detection.euclideanError ?? 0).toFixed(2)}{' '}
                  <span className="text-sm font-normal text-gray-400">px</span>
                </div>
                <div className="flex justify-between text-[10px] font-mono text-gray-400 mt-1">
                  <span>dX: {(detection.horizontalError ?? 0).toFixed(1)}px</span>
                  <span>dY: {(detection.verticalError ?? 0).toFixed(1)}px</span>
                </div>
              </div>

              {/* Confidence with Equalizer Segmented Bars */}
              <div className="pt-2 border-t border-[#1F2937]">
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Confidence</span>
                  <span className="text-xl font-mono text-white font-bold">
                    {((detection.confidence ?? 0) * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="w-full h-7 flex items-end gap-1.5 bg-[#0A0B10] p-1 rounded border border-[#1F2937]">
                  <div
                    className={`flex-1 rounded-sm transition-all duration-150 ${
                      detection.confidence >= 0.2 ? 'bg-cyan-500' : 'bg-[#1F2937]'
                    }`}
                    style={{ height: '30%' }}
                  />
                  <div
                    className={`flex-1 rounded-sm transition-all duration-150 ${
                      detection.confidence >= 0.4 ? 'bg-cyan-500' : 'bg-[#1F2937]'
                    }`}
                    style={{ height: '50%' }}
                  />
                  <div
                    className={`flex-1 rounded-sm transition-all duration-150 ${
                      detection.confidence >= 0.6 ? 'bg-cyan-500' : 'bg-[#1F2937]'
                    }`}
                    style={{ height: '70%' }}
                  />
                  <div
                    className={`flex-1 rounded-sm transition-all duration-150 ${
                      detection.confidence >= 0.8 ? 'bg-cyan-500' : 'bg-[#1F2937]'
                    }`}
                    style={{ height: '90%' }}
                  />
                  <div
                    className={`flex-1 rounded-sm transition-all duration-150 ${
                      detection.confidence >= 0.95 ? 'bg-cyan-500' : 'bg-[#1F2937]'
                    }`}
                    style={{ height: '100%' }}
                  />
                </div>
              </div>
            </div>
          </div>

          
            {/* AI Explainability & Risk Panel */}
            <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-purple-400" />
                  <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono">
                    LumaTrace Explainability
                  </h3>
                </div>
                {tracking.failureCause && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-400 border border-rose-800">
                    CAUSE: {tracking.failureCause}
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-gray-500 uppercase block mb-1">Controller Reason</span>
                  <div className="text-gray-300">{tracking.riskReason}</div>
                </div>
                <div>
                  <span className="text-[10px] text-gray-500 uppercase block mb-1">Predicted FOV Loss</span>
                  <div className={`font-bold ${tracking.predictedFovLoss === 'HIGH' ? 'text-rose-400' : tracking.predictedFovLoss === 'MEDIUM' ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {tracking.predictedFovLoss}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-gray-500 uppercase block mb-1">Control Saturation</span>
                  <div className={`font-bold ${tracking.controlSaturated ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {tracking.controlSaturated ? 'SATURATED (MAX RATE)' : 'NOMINAL'}
                  </div>
                </div>
              </div>
            </div>

          {/* System Events Panel (Geometric Balance) */}
          <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-3 border-b border-[#1F2937] pb-2">
              <h3 className="text-xs font-bold text-white uppercase tracking-widest">
                System Events
              </h3>
              <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            </div>

            <div className="space-y-2.5 font-mono text-[10px] flex-1 overflow-hidden">
              <div className="flex gap-2">
                <span className="text-gray-500">[10:42:01]</span>
                <span className="text-green-400 font-medium">TARGET_ACQUIRED: BEACON_ID_01</span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500">[10:42:05]</span>
                <span className="text-cyan-400 font-medium">
                  PRED_MODULE: KALMAN_{tracking.stateLabel}
                </span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500">[10:42:15]</span>
                <span className="text-purple-400 font-medium">
                  CONTROLLER: {config.controllerType.toUpperCase()}_ENGAGED
                </span>
              </div>
              <div className="flex gap-2">
                <span className="text-gray-500">[10:42:20]</span>
                <span className="text-slate-300 font-medium">
                  GIMBAL_RATE: P:{(cameraState.panVelocityDegS ?? 0).toFixed(1)}°/s T:{(cameraState.tiltVelocityDegS ?? 0).toFixed(1)}°/s
                </span>
              </div>
              {tracking.stateLabel === 'LOST' && (
                <div className="flex gap-2 animate-pulse">
                  <span className="text-gray-500">[10:42:22]</span>
                  <span className="text-rose-400 font-bold">EVENT: LOSS_INDUCED_SEARCHING</span>
                </div>
              )}
              {detection.euclideanError > 10.0 && (
                <div className="flex gap-2">
                  <span className="text-gray-500">[10:42:25]</span>
                  <span className="text-amber-400 font-medium">WARN: ERROR_EXCEEDS_10PX</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Real-Time Telemetry Cards Grid (Geometric Balance) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Optical <span title="The current state of the AI tracking loop (e.g. SEARCHING, TRACKING, LOST, REACQUIRING).">Tracking Status</span> */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 shadow-sm">
          <div className="text-[10px] font-mono text-gray-400 uppercase tracking-widest mb-1.5 font-semibold">
            Tracking Status
          </div>
          <div className="text-xl font-bold font-mono text-cyan-400 flex items-center justify-between">
            <span>{tracking.stateLabel}</span>
            {tracking.stateLabel === 'CENTERED' && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
            {tracking.stateLabel === 'TRACKING' && <Zap className="w-5 h-5 text-cyan-400" />}
            {tracking.stateLabel === 'LOST' && <AlertTriangle className="w-5 h-5 text-rose-500" />}
          </div>
          <div className="mt-2 text-[11px] text-gray-400 line-clamp-1" title={tracking.riskReason}>
            {tracking.riskReason}
          </div>
        </div>

        {/* Card 2: <span title="The physical orientation of the camera mount and the rate at which the motors are currently driving it.">Gimbal Pan / Tilt</span> */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 shadow-sm">
          <div className="text-[10px] font-mono text-gray-400 uppercase tracking-widest mb-1.5 font-semibold">
            Gimbal Pan / Tilt
          </div>
          <div className="text-xl font-bold font-mono text-white flex items-baseline gap-2">
            <span>P: {(cameraState.panDeg ?? 0).toFixed(2)}°</span>
            <span className="text-gray-600 text-sm">/</span>
            <span>T: {(cameraState.tiltDeg ?? 0).toFixed(2)}°</span>
          </div>
          <div className="mt-2 text-[11px] font-mono text-gray-400 flex justify-between">
            <span>Rate: P:{(cameraState.panVelocityDegS ?? 0).toFixed(1)}°/s</span>
            <span>T:{(cameraState.tiltVelocityDegS ?? 0).toFixed(1)}°/s</span>
          </div>
        </div>

        {/* Card 3: Pixel Offset & Centroiding Error */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 shadow-sm">
          <div className="text-[10px] font-mono text-gray-400 uppercase tracking-widest mb-1.5 font-semibold">
            <span title="The Euclidean distance in pixels between the target centroid and the camera optical center. Measured strictly from the visual sensor feed.">Tracking Error (SIH ≤10px)</span>
          </div>
          <div className="text-xl font-bold font-mono flex items-baseline justify-between">
            <span className={(detection.euclideanError ?? 0) <= 10.0 ? 'text-emerald-400' : 'text-amber-400'}>
              {(detection.euclideanError ?? 0).toFixed(2)} px
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-[#1F2937] text-gray-300 border border-[#374151]">
              {(detection.euclideanError ?? 0) <= 10.0 ? 'PASS' : 'WARN'}
            </span>
          </div>
          <div className="mt-2 text-[11px] font-mono text-gray-400 flex justify-between">
            <span>dX: {(detection.horizontalError ?? 0).toFixed(1)}px</span>
            <span>dY: {(detection.verticalError ?? 0).toFixed(1)}px</span>
          </div>
        </div>

        {/* Card 4: Processing Rate & <span title="Real-time processing latency and frame rate of the simulation loop.">Compute Pipeline</span> */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 shadow-sm">
          <div className="text-[10px] font-mono text-gray-400 uppercase tracking-widest mb-1.5 font-semibold">
            Compute Pipeline
          </div>
          <div className="text-xl font-bold font-mono text-white flex items-baseline justify-between">
            <span className={(fps ?? 0) >= 20 ? 'text-emerald-400' : 'text-amber-400'}>
              {(fps ?? 0).toFixed(1)} FPS
            </span>
            <span className="text-xs text-gray-400 font-normal">
              {(detection.processingTimeMs ?? 0).toFixed(1)} ms
            </span>
          </div>
          <div className="mt-2 text-[11px] font-mono text-gray-400 flex justify-between">
            <span>Controller: ≥20 Hz</span>
            <span className="text-cyan-400">Camera: ≥30 Hz</span>
          </div>
        </div>
      </div>
    </div>
  );
};
