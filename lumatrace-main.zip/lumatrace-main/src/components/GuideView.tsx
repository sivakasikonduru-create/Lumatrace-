import React, { useState, useMemo } from 'react';
import { 
  BookOpen, ChevronRight, ChevronLeft, Search, Play, Info, 
  Target, AlertTriangle, Cpu, Sliders, FlaskConical, FileText, 
  ArrowRight, Navigation, Film
} from 'lucide-react';
import { NavTab } from './Navbar';

export interface GuideViewProps {
  setActiveTab?: (tab: NavTab) => void;
}

type GuideMode = 'all' | 'beginner' | 'engineering';

interface GuideSection {
  id: string;
  title: string;
  icon: React.ReactNode;
  modes: GuideMode[];
  content: (onNavigate: (tab: NavTab) => void) => React.ReactNode;
}

export const GuideView: React.FC<GuideViewProps> = ({ setActiveTab }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMode, setActiveMode] = useState<GuideMode>('all');
  const [activeSectionId, setActiveSectionId] = useState<string>('overview');

  const handleNavigate = (tab: NavTab) => {
    if (setActiveTab) setActiveTab(tab);
  };

  const sections: GuideSection[] = [
    {
      id: 'overview',
      title: '1. Application Overview',
      icon: <Info className="w-4 h-4 text-cyan-400" />,
      modes: ['all', 'beginner', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4">
          <p><strong>LumaTrace</strong> is an AI-driven predictive virtual camera tracking system developed to demonstrate coarse alignment algorithms for mobile <strong>Free Space Optical Communication (FSOC)</strong> terminals.</p>
          <div className="bg-[#1F2937] p-4 rounded-md">
            <h4 className="font-bold text-emerald-400 mb-2">Core Concepts:</h4>
            <ul className="list-disc pl-5 space-y-2 text-gray-300 text-sm">
              <li><strong>FSOC (Free Space Optical Communication):</strong> Uses lasers to transmit data. Terminals must be precisely aligned.</li>
              <li><strong>Coarse Alignment:</strong> The initial wide-angle pointing step before ultra-precise fine-tracking takes over.</li>
              <li><strong>Virtual Camera:</strong> The simulated optical sensor on a pan/tilt gimbal.</li>
              <li><strong>The Beacon:</strong> The tracking light emitted by the target drone.</li>
            </ul>
          </div>
          <div className="bg-amber-950/30 border border-amber-800/50 p-4 rounded-md text-amber-200 text-sm">
            <strong>Simulation Note:</strong> This application is a software validation testbed for the tracking algorithms. It does not control real lasers or physical hardware.
          </div>
          <button onClick={() => onNav('architecture')} className="mt-4 flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded font-bold text-xs uppercase tracking-wider transition">
            Try It <ArrowRight className="w-4 h-4" /> View Architecture
          </button>
        </div>
      )
    },
    {
      id: 'beginner',
      title: '2. Beginner Walkthrough',
      icon: <Play className="w-4 h-4 text-emerald-400" />,
      modes: ['all', 'beginner'],
      content: (onNav) => (
        <div className="space-y-4 text-sm">
          <p>Follow these steps to run your first simulation:</p>
          <div className="space-y-3">
            <div className="flex items-start gap-3 bg-[#1F2937] p-3 rounded">
              <span className="w-6 h-6 rounded-full bg-cyan-600 flex items-center justify-center text-xs font-bold text-white shrink-0">1</span>
              <div>
                <p className="font-bold text-gray-200">Open the Dashboard</p>
                <p className="text-xs text-gray-400">Navigate to the main overview screen.</p>
                <button onClick={() => onNav('dashboard')} className="mt-2 text-xs bg-gray-700 hover:bg-gray-600 px-3 py-1.5 rounded text-white flex items-center gap-2"><Navigation className="w-3 h-3"/> Try It &rarr; Dashboard</button>
              </div>
            </div>
            <div className="flex items-start gap-3 bg-[#1F2937] p-3 rounded">
              <span className="w-6 h-6 rounded-full bg-cyan-600 flex items-center justify-center text-xs font-bold text-white shrink-0">2</span>
              <div>
                <p className="font-bold text-gray-200">Configure the Target</p>
                <p className="text-xs text-gray-400">Locate the MOTION dropdown (top action bar) and select FIGURE_8.</p>
              </div>
            </div>
            <div className="flex items-start gap-3 bg-[#1F2937] p-3 rounded">
              <span className="w-6 h-6 rounded-full bg-cyan-600 flex items-center justify-center text-xs font-bold text-white shrink-0">3</span>
              <div>
                <p className="font-bold text-gray-200">Start the Simulation</p>
                <p className="text-xs text-gray-400">Click the green RUN SIMULATION button and watch the Optical Sensor Viewport.</p>
              </div>
            </div>
            <div className="flex items-start gap-3 bg-[#1F2937] p-3 rounded">
              <span className="w-6 h-6 rounded-full bg-cyan-600 flex items-center justify-center text-xs font-bold text-white shrink-0">4</span>
              <div>
                <p className="font-bold text-gray-200">Introduce a Disturbance</p>
                <p className="text-xs text-gray-400">Click INDUCE OPTICAL LOSS (the red eye icon). Observe how the tracking state changes to REACQUIRING.</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'dashboard_sim',
      title: '3. Dashboard & Simulation',
      icon: <Target className="w-4 h-4 text-blue-400" />,
      modes: ['all', 'beginner', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4">
          <p>The <strong>Dashboard</strong> is the primary command center. The <strong>Live Simulation</strong> tab provides an expanded view.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#1F2937] p-4 rounded-md">
              <h4 className="font-bold text-cyan-400 mb-2">Optical Sensor Viewport</h4>
              <p className="text-xs text-gray-300">Displays the 640x480 pixel frame. The AI tracks the red beacon inside the green bounding box. If the beacon leaves the frame, FOV is lost.</p>
            </div>
            <div className="bg-[#1F2937] p-4 rounded-md">
              <h4 className="font-bold text-cyan-400 mb-2">Minimap (Top Right)</h4>
              <p className="text-xs text-gray-300">A 2D top-down view showing the camera's FOV frustum (blue box), the target's physical trajectory (cyan trail), and the active optical lock (dashed green line).</p>
            </div>
            <div className="bg-[#1F2937] p-4 rounded-md">
              <h4 className="font-bold text-cyan-400 mb-2">Telemetry Cards</h4>
              <p className="text-xs text-gray-300">Monitors Tracking Status, Gimbal Pan/Tilt angles, Sub-pixel Tracking Error, and FPS latency.</p>
            </div>
            <div className="bg-[#1F2937] p-4 rounded-md">
              <h4 className="font-bold text-cyan-400 mb-2">Explainability Panel</h4>
              <p className="text-xs text-gray-300">Reveals internal AI reasoning, Predicted FOV Loss risk, and Control Saturation events (when gimbal motors max out).</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => onNav('dashboard')} className="mt-2 text-xs bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-white flex items-center gap-1">Try It &rarr; Dashboard</button>
            <button onClick={() => onNav('simulation')} className="mt-2 text-xs bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-white flex items-center gap-1">Try It &rarr; Live Sim</button>
          </div>
        </div>
      )
    },
    {
      id: 'ai_engineering',
      title: '4. AI Tracking & Engineering',
      icon: <Cpu className="w-4 h-4 text-purple-400" />,
      modes: ['all', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4">
          <p>LumaTrace uses a hybrid predictive architecture to maintain optical alignment.</p>
          
          <div className="flex flex-col items-center my-6 bg-[#0A0B10] p-4 rounded-lg border border-[#1F2937]">
            <div className="text-xs font-mono text-cyan-400 border border-cyan-800 bg-cyan-950 px-2 py-1 rounded">Camera Frame (Pixels)</div>
            <div className="h-4 border-l border-gray-600"></div>
            <div className="text-xs font-mono text-emerald-400 border border-emerald-800 bg-emerald-950 px-2 py-1 rounded">Centroid Detection</div>
            <div className="h-4 border-l border-gray-600"></div>
            <div className="text-xs font-mono text-purple-400 border border-purple-800 bg-purple-950 px-2 py-1 rounded">Kalman Filter (Velocity/Smoothing)</div>
            <div className="h-4 border-l border-gray-600"></div>
            <div className="text-xs font-mono text-rose-400 border border-rose-800 bg-rose-950 px-2 py-1 rounded">ML Predictor (Future Horizons)</div>
            <div className="h-4 border-l border-gray-600"></div>
            <div className="text-xs font-mono text-amber-400 border border-amber-800 bg-amber-950 px-2 py-1 rounded">Predictive Controller (Pan/Tilt Rates)</div>
          </div>

          <div className="space-y-2 bg-[#1F2937] p-4 rounded text-sm">
            <h4 className="font-bold text-gray-200 border-b border-gray-700 pb-2 mb-2">Tracking States:</h4>
            <ul className="list-disc pl-5 text-gray-300 space-y-1">
              <li><strong>SEARCHING:</strong> Spiraling outward to find the target.</li>
              <li><strong>TRACKING:</strong> Following the centroid minimizing error.</li>
              <li><strong>LOST:</strong> Beacon vanished or left FOV.</li>
              <li><strong>REACQUIRING:</strong> Projecting an uncertainty cone along the coasting velocity to catch re-emergence.</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      id: 'disturbances',
      title: '5. Environmental Disturbances',
      icon: <Sliders className="w-4 h-4 text-rose-400" />,
      modes: ['all', 'beginner', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4">
          <p>You can degrade the signal physically using the Configuration panel.</p>
          <ul className="list-disc pl-5 space-y-2 text-sm text-gray-300 bg-[#1F2937] p-4 rounded">
            <li><strong>Atmosphere (Haze, Fog, Rain):</strong> Decreases contrast. The Kalman filter relies more heavily on velocity memory when detection confidence drops.</li>
            <li><strong>Platform Jitter:</strong> Simulates high-frequency mechanical vibration (drone turbulence).</li>
            <li><strong>Moving Obstacles:</strong> Generates a physical dark block passing through the optical sensor, causing absolute LOS failure.</li>
          </ul>
          <button onClick={() => onNav('config')} className="mt-2 text-xs bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-white flex items-center gap-1">Try It &rarr; Configuration</button>
        </div>
      )
    },
    {
      id: 'd2d',
      title: '6. Drone-to-Drone FSOC',
      icon: <FlaskConical className="w-4 h-4 text-gray-400" />,
      modes: ['all', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 bg-cyan-950/30 border border-cyan-800 p-4 rounded text-sm text-gray-300">
              <strong className="text-cyan-400">Drone A (Transmitter)</strong>
              <p className="mt-1">Projects the optical beacon.</p>
            </div>
            <div className="flex-1 bg-amber-950/30 border border-amber-800 p-4 rounded text-sm text-gray-300">
              <strong className="text-amber-400">Drone B (Receiver)</strong>
              <p className="mt-1">Operates the Virtual Camera gimbal.</p>
            </div>
          </div>
          <div className="bg-[#1F2937] p-4 rounded text-sm text-gray-300">
            <h4 className="font-bold text-white mb-2">Relative Geometry Simulation:</h4>
            <p>The system calculates the 3D relative coordinate vector <code>[dx, dy, dz] = DroneA - DroneB</code>. This vector is rotated by the Camera's Pan and Tilt matrices, then projected through a pinhole camera model onto a 2D 640x480 pixel plane governed by the camera's FOV (Field of View).</p>
          </div>
        </div>
      )
    },
    {
      id: 'scenarios_benchmark',
      title: '7. Scenarios & Benchmarking',
      icon: <Film className="w-4 h-4 text-emerald-400" />,
      modes: ['all', 'beginner', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4">
          <p>Validate the tracker against standard and extreme conditions.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#1F2937] p-4 rounded flex flex-col h-full">
              <h4 className="font-bold text-white">Scenario Lab</h4>
              <p className="text-xs text-gray-400 mt-1 flex-1">16 predefined tests ranging from stationary hovering to extreme D2D combat maneuvers in fog.</p>
              <button onClick={() => onNav('scenarios')} className="mt-3 text-xs bg-gray-600 hover:bg-gray-500 px-3 py-2 rounded text-white flex items-center justify-center gap-2">Try It &rarr; Scenarios</button>
            </div>
            <div className="bg-[#1F2937] p-4 rounded flex flex-col h-full">
              <h4 className="font-bold text-white">MP4 Benchmark</h4>
              <p className="text-xs text-gray-400 mt-1 flex-1">Upload external MP4 video files to evaluate the computer vision tracker strictly on external visual data.</p>
              <button onClick={() => onNav('benchmark')} className="mt-3 text-xs bg-gray-600 hover:bg-gray-500 px-3 py-2 rounded text-white flex items-center justify-center gap-2">Try It &rarr; Benchmark</button>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'analytics',
      title: '8. Analytics & Reports',
      icon: <FileText className="w-4 h-4 text-cyan-400" />,
      modes: ['all', 'beginner', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4">
          <p>After a simulation ends, check your SIH compliance.</p>
          <ul className="list-disc pl-5 space-y-2 text-sm text-gray-300 bg-[#1F2937] p-4 rounded">
            <li><strong>Analytics Tab:</strong> View interactive line charts of Tracking Error vs. Frame time. See how the AI suppresses physical noise.</li>
            <li><strong>Reports Tab:</strong> A strict audit against SIH benchmarks:
              <ul className="list-circle pl-5 mt-1 text-xs text-gray-400 space-y-1">
                <li>Acquisition &lt;= 2.0s</li>
                <li>Tracking Error &lt;= 10.0px</li>
                <li>Re-acquisition &lt;= 1.0s</li>
                <li>Processing Speed &gt;= 20 FPS</li>
              </ul>
            </li>
            <li><strong>A/B Test Tab:</strong> Auto-runs the Baseline Controller vs the LumaTrace Controller for direct numerical comparison.</li>
          </ul>
          <div className="flex gap-2">
            <button onClick={() => onNav('analytics')} className="mt-2 text-xs bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-white flex items-center gap-1">Try It &rarr; Analytics</button>
            <button onClick={() => onNav('reports')} className="mt-2 text-xs bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-white flex items-center gap-1">Try It &rarr; Reports</button>
            <button onClick={() => onNav('ab_test')} className="mt-2 text-xs bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-white flex items-center gap-1">Try It &rarr; A/B Test</button>
          </div>
        </div>
      )
    },
    {
      id: 'troubleshooting',
      title: '9. Troubleshooting',
      icon: <AlertTriangle className="w-4 h-4 text-amber-400" />,
      modes: ['all', 'beginner', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4 text-sm text-gray-300">
          <div className="bg-rose-950/20 border border-rose-900 p-3 rounded">
            <h4 className="font-bold text-rose-400">Beacon is not visible</h4>
            <ul className="list-disc pl-5 mt-1 text-xs text-gray-400">
              <li>Check FOV limits in Configuration.</li>
              <li>Check if target trajectory has moved out of the gimbal's max rotation bounds.</li>
              <li>Use the <strong>RESET</strong> button on the Dashboard.</li>
            </ul>
          </div>
          <div className="bg-amber-950/20 border border-amber-900 p-3 rounded">
            <h4 className="font-bold text-amber-400">Tracking is unstable / jerky</h4>
            <ul className="list-disc pl-5 mt-1 text-xs text-gray-400">
              <li>Target speed may be saturating the max camera pan/tilt speed. Check the Explainability panel for "Control Saturation".</li>
              <li>If jitter is enabled in Configuration, high-frequency noise will be visible.</li>
            </ul>
          </div>
          <div className="bg-amber-950/20 border border-amber-900 p-3 rounded">
            <h4 className="font-bold text-amber-400">Target is continuously LOST</h4>
            <ul className="list-disc pl-5 mt-1 text-xs text-gray-400">
              <li>Check if Moving Obstacles are enabled in Config.</li>
              <li>Check if Atmospheric Fog is too severe for the SNR confidence threshold.</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      id: 'reference',
      title: '10. Button Reference',
      icon: <BookOpen className="w-4 h-4 text-gray-400" />,
      modes: ['all', 'beginner', 'engineering'],
      content: (onNav) => (
        <div className="space-y-4 text-sm text-gray-300 overflow-x-auto">
          <table className="w-full text-left border-collapse bg-[#0A0B10] border border-[#1F2937] rounded text-xs min-w-[600px]">
            <thead>
              <tr className="border-b border-[#1F2937] text-gray-500">
                <th className="p-2 font-mono">Location</th>
                <th className="p-2 font-mono">Control</th>
                <th className="p-2 font-mono">Function</th>
                <th className="p-2 font-mono">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F2937]">
              <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-emerald-400">RUN SIMULATION</td><td className="p-2">Play/Pause</td><td className="p-2">Starts tracking loop</td></tr>
              <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-gray-300">RESET</td><td className="p-2">Resets coords</td><td className="p-2">Snaps all to [0,0,0]</td></tr>
              <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-rose-400">INDUCE OPTICAL LOSS</td><td className="p-2">Injects obstacle</td><td className="p-2">Forces LOST / REACQUIRING</td></tr>
              <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-white">CONTROLLER</td><td className="p-2">Toggle AI</td><td className="p-2">Switches Baseline/LumaTrace</td></tr>
              <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-white">MOTION</td><td className="p-2">Dropdown</td><td className="p-2">Changes target trajectory</td></tr>
              <tr><td className="p-2">Config</td><td className="p-2 font-bold text-white">ATMOSPHERE</td><td className="p-2">Dropdown</td><td className="p-2">Applies Fog/Rain/Haze</td></tr>
              <tr><td className="p-2">Config</td><td className="p-2 font-bold text-white">MOVING OBSTACLES</td><td className="p-2">Toggle</td><td className="p-2">Enables dynamic blockers</td></tr>
              <tr><td className="p-2">Scenarios</td><td className="p-2 font-bold text-emerald-400">RUN SCENARIO</td><td className="p-2">Play button</td><td className="p-2">Starts pre-configured test</td></tr>
              <tr><td className="p-2">Benchmark</td><td className="p-2 font-bold text-white">UPLOAD MP4</td><td className="p-2">File input</td><td className="p-2">Processes local video</td></tr>
            </tbody>
          </table>
        </div>
      )
    }
  ];

  // Filtering based on mode and search
  const filteredSections = useMemo(() => {
    return sections.filter(sec => {
      const modeMatch = sec.modes.includes(activeMode) || activeMode === 'all';
      const searchMatch = searchQuery.trim() === '' || 
        sec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sec.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sec.title.toLowerCase().includes(searchQuery.toLowerCase());
      return modeMatch && searchMatch;
    });
  }, [searchQuery, activeMode, sections]);

  const activeIndex = filteredSections.findIndex(s => s.id === activeSectionId);
  const currentSection = filteredSections[activeIndex] || filteredSections[0];

  const handleNext = () => {
    if (activeIndex < filteredSections.length - 1) {
      setActiveSectionId(filteredSections[activeIndex + 1].id);
      document.querySelector('.guide-scroll-area')?.scrollTo(0,0);
    }
  };

  const handlePrev = () => {
    if (activeIndex > 0) {
      setActiveSectionId(filteredSections[activeIndex - 1].id);
      document.querySelector('.guide-scroll-area')?.scrollTo(0,0);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#050608] text-gray-300">
      
      {/* Header */}
      <div className="px-4 py-4 border-b border-[#1F2937] bg-[#0A0B10] shrink-0 flex flex-wrap gap-4 items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-600/20 border border-emerald-500/50 flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white uppercase tracking-wider font-mono">Interactive User Guide</h1>
            <p className="text-xs text-gray-400 font-mono">Documentation & Troubleshooting</p>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="flex bg-[#1F2937] rounded-md p-1 border border-[#374151]">
          <button 
            onClick={() => { setActiveMode('all'); setActiveSectionId('overview'); }}
            className={`px-3 py-1.5 text-xs font-bold rounded uppercase ${activeMode === 'all' ? 'bg-cyan-600 text-white' : 'text-gray-400 hover:text-white'}`}
          >
            All Features
          </button>
          <button 
            onClick={() => { setActiveMode('beginner'); setActiveSectionId('beginner'); }}
            className={`px-3 py-1.5 text-xs font-bold rounded uppercase ${activeMode === 'beginner' ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'}`}
          >
            Beginner Walkthrough
          </button>
          <button 
            onClick={() => { setActiveMode('engineering'); setActiveSectionId('ai_engineering'); }}
            className={`px-3 py-1.5 text-xs font-bold rounded uppercase ${activeMode === 'engineering' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}
          >
            Engineering Detail
          </button>
        </div>
      </div>

      <div className="flex flex-1 min-h-0 overflow-hidden relative flex-col md:flex-row">
        
        {/* Sidebar TOC */}
        <div className="w-full md:w-72 bg-[#0F1117] border-b md:border-b-0 md:border-r border-[#1F2937] flex flex-col shrink-0">
          <div className="p-4 border-b border-[#1F2937]">
            <div className="relative">
              <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Search guide..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1F2937] border border-[#374151] rounded text-sm text-white px-9 py-2 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1 max-h-[30vh] md:max-h-full border-b md:border-none border-[#1F2937]">
            {filteredSections.length === 0 ? (
              <div className="text-sm text-gray-500 text-center py-6">No sections found.</div>
            ) : (
              filteredSections.map(sec => (
                <button
                  key={sec.id}
                  onClick={() => setActiveSectionId(sec.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-left transition-colors ${
                    sec.id === currentSection?.id 
                    ? 'bg-cyan-900/40 text-cyan-400 border border-cyan-800/50' 
                    : 'text-gray-400 hover:bg-[#1F2937] hover:text-gray-200'
                  }`}
                >
                  {sec.icon}
                  <span className="text-xs font-bold tracking-wide uppercase truncate">{sec.title}</span>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-h-0 bg-[#050608]">
          {currentSection ? (
            <>
              <div className="flex-1 overflow-y-auto p-6 md:p-10 guide-scroll-area">
                <div className="max-w-3xl mx-auto">
                  <div className="flex items-center gap-3 mb-6 pb-4 border-b border-[#1F2937]">
                    {currentSection.icon}
                    <h2 className="text-2xl font-bold text-white tracking-wide">{currentSection.title}</h2>
                  </div>
                  <div className="text-gray-300 leading-relaxed">
                    {currentSection.content(handleNavigate)}
                  </div>
                </div>
              </div>
              
              {/* Prev / Next Footer */}
              <div className="p-4 bg-[#0A0B10] border-t border-[#1F2937] flex justify-between items-center shrink-0">
                <button 
                  onClick={handlePrev}
                  disabled={activeIndex <= 0}
                  className="flex items-center gap-2 px-3 md:px-4 py-2 rounded bg-[#1F2937] text-gray-300 hover:bg-[#283548] disabled:opacity-50 disabled:cursor-not-allowed transition text-xs md:text-sm font-bold uppercase tracking-wider"
                >
                  <ChevronLeft className="w-4 h-4" /> Prev
                </button>
                <div className="text-xs font-mono text-gray-500 hidden sm:block">
                  {activeIndex + 1} / {filteredSections.length}
                </div>
                <button 
                  onClick={handleNext}
                  disabled={activeIndex >= filteredSections.length - 1}
                  className="flex items-center gap-2 px-3 md:px-4 py-2 rounded bg-cyan-600 text-white hover:bg-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed transition text-xs md:text-sm font-bold uppercase tracking-wider"
                >
                  Next <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-500">
              Select a section from the left or adjust your search.
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
