import React from 'react';
import { BarChart3 } from 'lucide-react';
import { PerformanceMetrics, TargetState } from '../types/fsoc';

interface AnalyticsViewProps {
  metrics: PerformanceMetrics;
  errorHistory: number[];
  fpsHistory: number[];
  groundTruthHistory: TargetState[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  metrics,
  errorHistory,
  fpsHistory,
  groundTruthHistory: _groundTruthHistory,
}) => {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Analytics Header (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <BarChart3 className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-widest">
              Performance Analytics & Telemetry (Phase 12)
            </h2>
            <p className="text-xs text-gray-400">
              Live mathematical telemetry logs, error dispersion curves, and SIH thresholds.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <span className="text-gray-400">Sim Duration:</span>
          <span className="text-cyan-400 font-bold">{metrics.simulationDurationS}s</span>
          <span className="text-gray-600">|</span>
          <span className="text-gray-400">Frames:</span>
          <span className="text-white font-bold">{metrics.totalFrames}</span>
        </div>
      </div>

      {/* Primary Telemetry Plots */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Plot 1: Tracking Error vs Time */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-3">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="font-bold text-white uppercase tracking-wider">Tracking Error Dispersion (px)</span>
            <span className="text-emerald-400 font-bold">Target: ≤ 10.0 px</span>
          </div>

          <div className="relative h-44 w-full bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3 flex flex-col justify-end">
            {/* 10 px threshold guide line */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-red-500/70 z-10"
              style={{ bottom: '40%' }}
            >
              <span className="absolute right-2 -top-4 text-[9px] font-mono font-bold text-red-400 uppercase">
                10px SIH Threshold
              </span>
            </div>

            {/* Error Bars */}
            <div className="h-full w-full flex items-end gap-[1px]">
              {errorHistory.slice(-80).map((err, i) => {
                const maxPlot = 25.0;
                const safeErr = err ?? 0;
                const hPct = Math.min(100, Math.max(3, (safeErr / maxPlot) * 100));
                return (
                  <div
                    key={i}
                    className="flex-1 transition-all rounded-t"
                    style={{
                      height: `${hPct}%`,
                      backgroundColor: safeErr <= 10.0 ? '#10b981' : '#f59e0b',
                    }}
                    title={`Error: ${safeErr.toFixed(1)} px`}
                  />
                );
              })}
            </div>
          </div>
          <div className="flex justify-between text-[11px] font-mono text-gray-400">
            <span>Mean: {metrics.averageTrackingErrorPx} px</span>
            <span>RMSE: {metrics.rmsePx} px</span>
            <span>Max: {metrics.maxTrackingErrorPx} px</span>
          </div>
        </div>

        {/* Plot 2: Compute Processing Speed (FPS) vs Time */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-3">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="font-bold text-white uppercase tracking-wider">Processing Speed (FPS)</span>
            <span className="text-cyan-400 font-bold">Target: ≥ 20.0 FPS</span>
          </div>

          <div className="relative h-44 w-full bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3 flex flex-col justify-end">
            {/* 20 FPS threshold guide line */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-cyan-500/70 z-10"
              style={{ bottom: '45%' }}
            >
              <span className="absolute right-2 -top-4 text-[9px] font-mono font-bold text-cyan-400 uppercase">
                20 FPS Target
              </span>
            </div>

            {/* FPS Bars */}
            <div className="h-full w-full flex items-end gap-[1px]">
              {fpsHistory.slice(-80).map((fps, i) => {
                const maxFps = 60.0;
                const safeFps = fps ?? 0;
                const hPct = Math.min(100, Math.max(5, (safeFps / maxFps) * 100));
                return (
                  <div
                    key={i}
                    className="flex-1 transition-all rounded-t bg-cyan-500/80"
                    style={{ height: `${hPct}%` }}
                    title={`Rate: ${safeFps.toFixed(1)} FPS`}
                  />
                );
              })}
            </div>
          </div>
          <div className="flex justify-between text-[11px] font-mono text-gray-400">
            <span>Min: {metrics.minFps} FPS</span>
            <span>Avg: {metrics.avgFps} FPS</span>
            <span>Pipeline Latency: {metrics.avgProcessingTimeMs} ms</span>
          </div>
        </div>
      </div>

      {/* Detailed Statistical Summary Table */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm">
        <h3 className="text-xs font-bold font-mono text-white uppercase tracking-widest mb-4">
          Statistical Error Breakdown & Centroid Accuracy
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div className="bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3.5">
            <div className="text-gray-400 text-[10px] uppercase font-semibold">Avg Centroiding Error</div>
            <div className="text-amber-400 font-bold text-lg mt-1">
              {metrics.averageCentroidingErrorPx} px
            </div>
            <div className="text-[10px] text-gray-500 mt-1">Evaluated vs Ground Truth</div>
          </div>

          <div className="bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3.5">
            <div className="text-gray-400 text-[10px] uppercase font-semibold">Lock Retention Rate</div>
            <div className="text-emerald-400 font-bold text-lg mt-1">
              {metrics.lockRetentionRate}%
            </div>
            <div className="text-[10px] text-gray-500 mt-1">Frames beacon tracked</div>
          </div>

          <div className="bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3.5">
            <div className="text-gray-400 text-[10px] uppercase font-semibold">Target Loss Rate</div>
            <div className="text-white font-bold text-lg mt-1">
              {metrics.targetLossPercentage}%
            </div>
            <div className="text-[10px] text-gray-500 mt-1">SIH Target: &lt; 5.0%</div>
          </div>

          <div className="bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3.5">
            <div className="text-gray-400 text-[10px] uppercase font-semibold">Re-acquisition Time</div>
            <div className="text-cyan-400 font-bold text-lg mt-1">
              {metrics.reacquisitionTimeS} s
            </div>
            <div className="text-[10px] text-gray-500 mt-1">SIH Target: ≤ 1.0s</div>
          </div>
        </div>
      </div>
    </div>
  );
};
