import React, { useState } from 'react';
import { GitCompare, Play, RotateCcw, Zap, CheckCircle2, TrendingUp, ShieldCheck } from 'lucide-react';
import { PerformanceMetrics, SimulationConfig, DisturbanceConfig, DEFAULT_CONFIG, DEFAULT_DISTURBANCE } from '../types/fsoc';
import { VirtualCamera } from '../core/VirtualCamera';
import { TargetSimulator } from '../core/TargetSimulator';
import { ImageProcessor } from '../core/ImageProcessor';
import { TrackingEngine } from '../core/RiskAndRecovery';
import { MetricsEvaluator } from '../core/MetricsEvaluator';
import { BaselineReactiveController, LumaTracePredictiveController } from '../core/Controllers';

export const AbComparisonView: React.FC = () => {
  const [motionMode, setMotionMode] = useState<string>('figure_8');
  const [speed, setSpeed] = useState<number>(85);
  const [hasNoise, setHasNoise] = useState<boolean>(true);
  const [hasJitter, setHasJitter] = useState<boolean>(true);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const [baselineMetrics, setBaselineMetrics] = useState<PerformanceMetrics | null>(null);
  const [predictiveMetrics, setPredictiveMetrics] = useState<PerformanceMetrics | null>(null);

  const runEvaluation = (controllerType: 'baseline' | 'predictive'): PerformanceMetrics => {
    const config: SimulationConfig = {
      ...DEFAULT_CONFIG,
      targetMotionMode: motionMode as any,
      targetSpeedPxS: speed,
      controllerType,
    };
    const distConfig: DisturbanceConfig = {
      ...DEFAULT_DISTURBANCE,
      noiseType: hasNoise ? 'gaussian' : 'none',
      gaussianSigma: hasNoise ? 12.0 : 0,
      jitterEnabled: hasJitter,
      jitterAmplitudePx: hasJitter ? 14.0 : 0,
      platformMotionEnabled: hasJitter,
      platformAmplitudePx: hasJitter ? 10.0 : 0,
    };

    const camera = new VirtualCamera(config);
    const target = new TargetSimulator(config, 0);
    const imageProcessor = new ImageProcessor(config.cameraWidth, config.cameraHeight);
    const trackingEngine = new TrackingEngine(config.cameraWidth, config.cameraHeight);
    const evaluator = new MetricsEvaluator();

    const controller =
      controllerType === 'baseline'
        ? new BaselineReactiveController(config)
        : new LumaTracePredictiveController(config);

    const offscreen = document.createElement('canvas');
    offscreen.width = config.cameraWidth;
    offscreen.height = config.cameraHeight;
    const ctx = offscreen.getContext('2d', { willReadFrequently: true })!;

    const dt = 1.0 / config.cameraUpdateRateHz;
    const totalSteps = 150; // 5 seconds at 30 FPS

    for (let step = 0; step < totalSteps; step++) {
      const simTime = step * dt;

      // Occlusion at step 60-75 (2.0s to 2.5s) to test re-acquisition
      if (step >= 60 && step <= 75) {
        target.isActive = false;
      } else {
        target.isActive = true;
      }

      const targetState = target.update(dt, config.screenWidth, config.screenHeight);
      const motions = imageProcessor.computeMotionDisturbances(dt, distConfig);
      camera.applyDisturbances(
        motions.jitterX,
        motions.jitterY,
        motions.platformX,
        motions.platformY
      );

      const proj = camera.worldToViewport(
        targetState.worldX,
        targetState.worldY,
        targetState.sizePx
      );

      imageProcessor.renderOpticalFrame(
        ctx,
        targetState.isActive ? proj : null,
        null,
        distConfig,
        { x: motions.jitterX, y: motions.jitterY }
      );

      const imgData = ctx.getImageData(0, 0, config.cameraWidth, config.cameraHeight);
      imageProcessor.applyNoiseToImageData(imgData, distConfig);

      // Detection without ground truth
      const detResult = imageProcessor.detectBeaconFromImageData(imgData, null, 95);
      const trackState = trackingEngine.update(detResult, dt);

      const [panRate, tiltRate] = controller.computeControl(camera, trackState, dt);
      camera.update(dt, panRate, tiltRate);

      evaluator.recordFrame(
        simTime,
        detResult.detected,
        detResult.euclideanError,
        null,
        detResult.processingTimeMs,
        trackState.reacquisitionTimeS
      );
    }

    return evaluator.computeMetrics();
  };

  const handleStartComparison = async () => {
    setIsSimulating(true);
    await new Promise((resolve) => setTimeout(resolve, 80));

    const b = runEvaluation('baseline');
    setBaselineMetrics(b);

    await new Promise((resolve) => setTimeout(resolve, 80));
    const p = runEvaluation('predictive');
    setPredictiveMetrics(p);

    setIsSimulating(false);
  };

  const calcImprovement = (baseVal: number, predVal: number, lowerIsBetter = true) => {
    if (!baseVal || isNaN(baseVal) || isNaN(predVal)) return '0.0%';
    const diff = lowerIsBetter ? baseVal - predVal : predVal - baseVal;
    const pct = (diff / baseVal) * 100.0;
    return pct >= 0 ? `+${pct.toFixed(1)}%` : `${pct.toFixed(1)}%`;
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Header card (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <GitCompare className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-widest">
                Baseline vs. LumaTrace Predictive A/B Comparison (Phase 11)
              </h2>
              <p className="text-xs text-gray-400">
                Rigorous side-by-side benchmark testing under identical trajectory, dynamic noise, and disturbance models.
              </p>
            </div>
          </div>

          <button
            onClick={handleStartComparison}
            disabled={isSimulating}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider shadow-sm transition ${
              isSimulating
                ? 'bg-[#1F2937] text-gray-500 cursor-not-allowed border border-[#374151]'
                : 'bg-cyan-600 hover:bg-cyan-500 text-white'
            }`}
          >
            {isSimulating ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            <span>{isSimulating ? 'Evaluating...' : 'Run Comparative Benchmark'}</span>
          </button>
        </div>

        {/* Parameter configuration row */}
        <div className="mt-4 pt-3 border-t border-[#1F2937] flex flex-wrap items-center gap-5 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-gray-400 uppercase font-semibold">Trajectory:</span>
            <select
              value={motionMode}
              onChange={(e) => setMotionMode(e.target.value)}
              className="bg-[#0A0B10] border border-[#1F2937] rounded-md px-2.5 py-1 text-cyan-400 font-mono uppercase focus:outline-none"
            >
              <option value="straight_line">Straight Line</option>
              <option value="circular">Circular</option>
              <option value="figure_8">Figure of 8</option>
              <option value="random">Random Walk</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-gray-400 uppercase font-semibold">Speed:</span>
            <span className="text-white font-bold">{speed} px/s</span>
            <input
              type="range"
              min={40}
              max={150}
              step={5}
              value={speed}
              onChange={(e) => setSpeed(parseInt(e.target.value))}
              className="w-24 accent-cyan-500 cursor-pointer"
            />
          </div>

          <label className="flex items-center gap-2 cursor-pointer text-gray-300">
            <input
              type="checkbox"
              checked={hasNoise}
              onChange={(e) => setHasNoise(e.target.checked)}
              className="accent-cyan-500 rounded"
            />
            <span>Gaussian Noise (σ=12)</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-gray-300">
            <input
              type="checkbox"
              checked={hasJitter}
              onChange={(e) => setHasJitter(e.target.checked)}
              className="accent-cyan-500 rounded"
            />
            <span>Camera Jitter & Platform Motion</span>
          </label>
        </div>
      </div>

      {/* Side-by-side Scorecard Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Baseline Reactive Controller */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#1F2937] pb-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-gray-300">
                Baseline Controller
              </h3>
              <p className="text-[11px] text-gray-500 font-mono">Simple Proportional Error Feedback</p>
            </div>
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#1F2937] text-gray-400 border border-[#374151]">
              REACTIVE
            </span>
          </div>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="flex justify-between p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Average Tracking Error:</span>
              <span className="text-white font-bold">
                {baselineMetrics ? `${baselineMetrics.averageTrackingErrorPx} px` : '--'}
              </span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Root Mean Square Error (RMSE):</span>
              <span className="text-white font-bold">
                {baselineMetrics ? `${baselineMetrics.rmsePx} px` : '--'}
              </span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Maximum Tracking Error:</span>
              <span className="text-white font-bold">
                {baselineMetrics ? `${baselineMetrics.maxTrackingErrorPx} px` : '--'}
              </span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Target Loss Percentage:</span>
              <span className="text-white font-bold">
                {baselineMetrics ? `${baselineMetrics.targetLossPercentage}%` : '--'}
              </span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Re-acquisition Duration:</span>
              <span className="text-white font-bold">
                {baselineMetrics ? `${baselineMetrics.reacquisitionTimeS}s` : '--'}
              </span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Compute Speed:</span>
              <span className="text-white font-bold">
                {baselineMetrics ? `${baselineMetrics.avgFps} FPS` : '--'}
              </span>
            </div>
          </div>
        </div>

        {/* LumaTrace Predictive Controller */}
        <div className="bg-[#0F1117] border border-cyan-500/40 rounded-lg p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#1F2937] pb-3">
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                  LumaTrace Predictive Controller
                </h3>
                <Zap className="w-3.5 h-3.5 text-amber-300" />
              </div>
              <p className="text-[11px] text-gray-400 font-mono">Kalman State Estimation + Feedforward Velocity</p>
            </div>
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-500/50">
              PREDICTIVE
            </span>
          </div>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="flex justify-between items-center p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Average Tracking Error:</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">
                  {predictiveMetrics ? `${predictiveMetrics.averageTrackingErrorPx} px` : '--'}
                </span>
                {baselineMetrics && predictiveMetrics && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                    {calcImprovement(baselineMetrics.averageTrackingErrorPx, predictiveMetrics.averageTrackingErrorPx)}
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Root Mean Square Error (RMSE):</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">
                  {predictiveMetrics ? `${predictiveMetrics.rmsePx} px` : '--'}
                </span>
                {baselineMetrics && predictiveMetrics && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                    {calcImprovement(baselineMetrics.rmsePx, predictiveMetrics.rmsePx)}
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Maximum Tracking Error:</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">
                  {predictiveMetrics ? `${predictiveMetrics.maxTrackingErrorPx} px` : '--'}
                </span>
                {baselineMetrics && predictiveMetrics && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                    {calcImprovement(baselineMetrics.maxTrackingErrorPx, predictiveMetrics.maxTrackingErrorPx)}
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Target Loss Percentage:</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">
                  {predictiveMetrics ? `${predictiveMetrics.targetLossPercentage}%` : '--'}
                </span>
                {baselineMetrics && predictiveMetrics && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                    {calcImprovement(baselineMetrics.targetLossPercentage, predictiveMetrics.targetLossPercentage)}
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Re-acquisition Duration:</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400 font-bold">
                  {predictiveMetrics ? `${predictiveMetrics.reacquisitionTimeS}s` : '--'}
                </span>
                {baselineMetrics && predictiveMetrics && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                    {calcImprovement(baselineMetrics.reacquisitionTimeS, predictiveMetrics.reacquisitionTimeS)}
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center p-2.5 rounded bg-[#0A0B10] border border-[#1F2937]">
              <span className="text-gray-400">Compute Speed:</span>
              <span className="text-white font-bold">
                {predictiveMetrics ? `${predictiveMetrics.avgFps} FPS` : '--'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
