import React from 'react';
import {
  Activity,
  HelpCircle,
  HelpCircle,
  Compass,
  Film,
  FlaskConical,
  GitCompare,
  BarChart3,
  PlaySquare,
  FileText,
  Sliders,
  Cpu,
  ShieldAlert,
  ShieldCheck,
} from 'lucide-react';
import { RiskLevel, TrackingStateLabel } from '../types/fsoc';

export type NavTab =
  | 'dashboard'
  | 'simulation'
  | 'benchmark'
  | 'scenarios'
  | 'ab_test'
  | 'analytics'
  | 'demo'
  | 'reports'
  | 'config'
  | 'architecture'
  | 'guide';

export interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  trackingState: TrackingStateLabel;
  riskLevel: RiskLevel;
  fps: number;
  panDeg: number;
  tiltDeg: number;
  latencyMs?: number;
  errorPx?: number;
}

export const navItems: { id: NavTab; label: string; shortLabel: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Overview Dashboard', shortLabel: 'Overview', icon: <Compass className="w-5 h-5" /> },
  { id: 'simulation', label: 'Live Optical Simulation', shortLabel: 'Live Sim', icon: <Activity className="w-5 h-5" /> },
  { id: 'benchmark', label: 'MP4 Benchmark Testbench', shortLabel: 'Benchmark', icon: <Film className="w-5 h-5" /> },
  { id: 'scenarios', label: '16-Scenario Lab', shortLabel: 'Scenarios', icon: <FlaskConical className="w-5 h-5" /> },
  { id: 'ab_test', label: 'A/B Comparative Benchmark', shortLabel: 'A/B Test', icon: <GitCompare className="w-5 h-5" /> },
  { id: 'analytics', label: 'Deep Telemetry Analytics', shortLabel: 'Analytics', icon: <BarChart3 className="w-5 h-5" /> },
  { id: 'demo', label: 'SIH Presentation Demo', shortLabel: 'SIH Demo', icon: <PlaySquare className="w-5 h-5 text-cyan-400" /> },
  { id: 'reports', label: 'Compliance Audit Reports', shortLabel: 'Reports', icon: <FileText className="w-5 h-5" /> },
  { id: 'config', label: 'Hardware Configuration', shortLabel: 'Config', icon: <Sliders className="w-5 h-5" /> },
  { id: 'architecture', label: '6-Stage Architecture', shortLabel: 'Arch', icon: <Cpu className="w-5 h-5" /> },
  { id: 'guide', label: 'User Guide & Walkthrough', shortLabel: 'Guide', icon: <HelpCircle className="w-5 h-5 text-emerald-400" /> },
];

/**
 * Geometric Balance Sidebar Rail (80px wide)
 */
export const Sidebar: React.FC<{ activeTab: NavTab; setActiveTab: (tab: NavTab) => void }> = ({
  activeTab,
  setActiveTab,
}) => {
  return (
    <aside className="w-[80px] hidden md:flex flex-col items-center py-6 border-r border-[#1F2937] bg-[#0F1117] shrink-0 select-none z-30">
      {/* Geometric Balance LT Gradient Logo */}
      <div className="mb-8">
        <button
          onClick={() => setActiveTab('dashboard')}
          className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white text-xl shadow-lg shadow-cyan-500/20 hover:scale-105 transition-transform"
          title="LumaTrace FSOC Tracking System"
        >
          LT
        </button>
      </div>

      {/* Navigation Icons Column */}
      <nav className="flex flex-col gap-3.5 w-full px-3">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`sidebar-tab-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`group relative p-2.5 rounded-md flex items-center justify-center transition-all ${
                isActive
                  ? 'bg-[#1F2937] text-cyan-400 border border-cyan-500/30 shadow-sm'
                  : 'text-gray-500 hover:text-gray-200 hover:bg-[#1F2937]/50'
              }`}
              title={item.label}
            >
              {item.icon}

              {/* Tooltip on hover */}
              <div className="absolute left-[78px] top-1/2 -translate-y-1/2 px-2.5 py-1 bg-[#0F1117] text-slate-100 text-xs font-medium rounded border border-[#1F2937] shadow-xl whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50">
                {item.label}
              </div>
            </button>
          );
        })}
      </nav>

      {/* Bottom version marker */}
      <div className="mt-auto text-[9px] font-mono text-gray-600 uppercase tracking-widest text-center">
        PS-04
      </div>
    </aside>
  );
};

/**
 * Geometric Balance Header (64px height)
 */
export const Header: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  trackingState,
  riskLevel,
  fps,
  panDeg,
  tiltDeg,
  latencyMs = 14.2,
  errorPx = 0,
}) => {
  const getStatusDisplay = () => {
    switch (riskLevel) {
      case 'SAFE':
        return (
          <div className="flex items-center gap-2 px-3 py-1 bg-green-900/30 border border-green-500/50 rounded-full">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-[10px] uppercase font-bold text-green-400 tracking-wider">
              Tracking Active
            </span>
          </div>
        );
      case 'WARNING':
        return (
          <div className="flex items-center gap-2 px-3 py-1 bg-amber-900/30 border border-amber-500/50 rounded-full">
            <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
              Low Confidence
            </span>
          </div>
        );
      case 'HIGH_RISK':
        return (
          <div className="flex items-center gap-2 px-3 py-1 bg-rose-900/30 border border-rose-500/50 rounded-full animate-pulse">
            <div className="w-2 h-2 bg-rose-400 rounded-full" />
            <span className="text-[10px] uppercase font-bold text-rose-400 tracking-wider">
              High Loss Risk
            </span>
          </div>
        );
      case 'LOST':
      default:
        return (
          <div className="flex items-center gap-2 px-3 py-1 bg-red-950/80 border border-red-500/60 rounded-full">
            <div className="w-2 h-2 bg-red-500 rounded-full" />
            <span className="text-[10px] uppercase font-bold text-red-400 tracking-wider">
              Beacon Occluded
            </span>
          </div>
        );
    }
  };

  return (
    <header className="border-b border-[#1F2937] bg-[#0F1117] select-none sticky top-0 z-40">
      {/* Top Main Geometric Balance Strip (64px) */}
      <div className="h-[64px] flex items-center justify-between px-4 sm:px-8">
        {/* Left: Brand & Status Pill */}
        <div className="flex items-center gap-4 sm:gap-6">
          {/* Mobile LT Icon */}
          <div className="md:hidden w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white text-base shadow-sm">
            LT
          </div>

          <div className="flex items-center">
            <h1 className="text-base sm:text-lg font-bold tracking-tight text-white uppercase flex items-center">
              LumaTrace <span className="text-cyan-500 font-light ml-2 text-sm sm:text-base">v1.0.4</span>
            </h1>
            <span className="hidden sm:inline-block ml-3 px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-[#1F2937] text-cyan-400 border border-[#374151]">
              SIH PS-04
            </span>
          </div>

          <div className="hidden sm:block">{getStatusDisplay()}</div>
        </div>

        {/* Right: Precision Telemetry Indicators */}
        <div className="flex items-center gap-4 sm:gap-8 md:gap-10">
          <div className="text-right">
            <p className="text-[10px] text-gray-500 uppercase font-semibold">Latency</p>
            <p className="text-xs sm:text-sm font-mono text-cyan-400">{(latencyMs ?? 0).toFixed(1)}ms</p>
          </div>

          <div className="text-right">
            <p className="text-[10px] text-gray-500 uppercase font-semibold">Frequency</p>
            <p className="text-xs sm:text-sm font-mono text-cyan-400">{(fps ?? 0).toFixed(1)} Hz</p>
          </div>

          <div className="text-right hidden sm:block">
            <p className="text-[10px] text-gray-500 uppercase font-semibold">Gimbal (P/T)</p>
            <p className="text-xs sm:text-sm font-mono text-cyan-400">
              {(panDeg ?? 0).toFixed(1)}° / {(tiltDeg ?? 0).toFixed(1)}°
            </p>
          </div>

          {/* Status badge for mobile */}
          <div className="sm:hidden">{getStatusDisplay()}</div>
        </div>
      </div>

      {/* Responsive Horizontal Navigation Scroll for Mobile / Quick Access */}
      <div className="px-3 py-1.5 border-t border-[#1F2937] flex items-center gap-1.5 overflow-x-auto scrollbar-none md:hidden bg-[#0A0B10]">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs whitespace-nowrap font-medium transition ${
                isActive
                  ? 'bg-[#1F2937] text-cyan-400 border border-cyan-500/40'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              {item.icon}
              <span>{item.shortLabel}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};

/**
 * Default Navbar export for backward-compatibility
 */
export const Navbar: React.FC<NavbarProps> = (props) => {
  return <Header {...props} />;
};
