import React from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Sliders,
  Wind,
} from 'lucide-react';
import { DisturbanceConfig, SimulationConfig, TargetState, CameraState, DetectionResult, TrackingState } from '../types/fsoc';

interface LiveSimulationViewProps {
  isRunning: boolean;
  onToggleRunning: () => void;
  onReset: () => void;
  config: SimulationConfig;
  onUpdateConfig: (partial: Partial<SimulationConfig>) => void;
  distConfig: DisturbanceConfig;
  onUpdateDistConfig: (partial: Partial<DisturbanceConfig>) => void;
  cameraState: CameraState;
  targetState: TargetState;
  detection: DetectionResult;
  tracking: TrackingState;
  fps: number;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  errorHistory: number[];
}

export const LiveSimulationView: React.FC<LiveSimulationViewProps> = ({
  isRunning,
  onToggleRunning,
  onReset,
  config,
  onUpdateConfig,
  distConfig,
  onUpdateDistConfig,
  cameraState: _cameraState,
  targetState: _targetState,
  detection,
  tracking: _tracking,
  fps,
  canvasRef,
  errorHistory,
}) => {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Simulation Command Strip (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-2.5">
          <button
            id="sim-run-toggle"
            onClick={onToggleRunning}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-bold uppercase tracking-wider text-xs shadow-sm transition ${
              isRunning
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-cyan-600 hover:bg-cyan-500 text-white'
            }`}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isRunning ? 'Pause Engine' : 'Start Simulation'}</span>
          </button>

          <button
            id="sim-reset-btn"
            onClick={onReset}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-white font-bold uppercase tracking-wider text-xs border border-[#374151] transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>

        <div className="flex items-center gap-6 text-xs font-mono">
          <div>
            <span className="text-gray-400">Target Motion: </span>
            <span className="text-cyan-400 font-bold uppercase">{config.targetMotionMode}</span>
          </div>
          <div>
            <span className="text-gray-400">Controller: </span>
            <span className="text-purple-400 font-bold uppercase">{config.controllerType}</span>
          </div>
          <div>
            <span className="text-gray-400">FPS: </span>
            <span className={(fps ?? 0) >= 20 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
              {(fps ?? 0).toFixed(1)}
            </span>
          </div>
        </div>
      </div>

      {/* Main Simulation Viewport and Real-Time Error Plot */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Canvas Feed (Geometric Balance) */}
        <div className="lg:col-span-8 bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white">
              Virtual Optical Camera Sensor Feed
            </h3>
            <span className="text-[11px] font-mono text-cyan-400">
              Res: {config.cameraWidth}×{config.cameraHeight} • FOV: {config.cameraFovHDeg}°×{config.cameraFovVDeg}°
            </span>
          </div>

          <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden border border-[#1F2937] bg-[#050608] flex items-center justify-center shadow-inner">
            {/* Geometric Dot Grid */}
            <div
              className="absolute inset-0 opacity-10 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(#22D3EE 0.5px, transparent 0.5px)',
                backgroundSize: '20px 20px',
              }}
            />

            {/* Subtle Crosshairs */}
            <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none">
              <div className="w-[75%] h-[75%] border border-cyan-500/40 border-dashed" />
              <div className="absolute w-px h-full bg-cyan-500/20" />
              <div className="absolute h-px w-full bg-cyan-500/20" />
            </div>

            <canvas ref={canvasRef} width={640} height={480} className="w-full h-full object-contain relative z-10" />
          </div>

          {/* Real-time Tracking Error Mini Graph (Geometric Balance) */}
          <div className="mt-4 bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3.5">
            <div className="flex items-center justify-between text-[11px] font-mono mb-2">
              <span className="text-gray-400 font-semibold uppercase tracking-wider">Real-Time Error History (px)</span>
              <span className="text-emerald-400 font-bold">
                Threshold: ≤10.0 px | Current: {(detection.euclideanError ?? 0).toFixed(2)} px
              </span>
            </div>

            <div className="h-16 w-full flex items-end gap-[2px] pt-1">
              {errorHistory.slice(-60).map((err, idx) => {
                const maxH = 56;
                const safeErr = err ?? 0;
                const h = Math.min(maxH, Math.max(2, (safeErr / 25.0) * maxH));
                const isPassing = safeErr <= 10.0;
                return (
                  <div
                    key={idx}
                    className="flex-1 rounded-t transition-all"
                    style={{
                      height: `${h}px`,
                      backgroundColor: isPassing ? '#10b981' : '#f59e0b',
                      opacity: 0.85,
                    }}
                    title={`Error: ${safeErr.toFixed(1)} px`}
                  />
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Comprehensive Parameter Deck (Geometric Balance) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Target & Trajectory Settings Card */}
          <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-white font-bold text-xs uppercase tracking-widest border-b border-[#1F2937] pb-3">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Target & Trajectory (Phase 2 & 3)</span>
            </div>

            {/* Motion Mode */}
            <div>
              <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
                Trajectory Profile
              </label>
              <select
                value={config.targetMotionMode}
                onChange={(e) => onUpdateConfig({ targetMotionMode: e.target.value as any })}
                className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-cyan-400 font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500 uppercase"
              >
                <option value="straight_line">Straight Line (Linear Sweep)</option>
                <option value="circular">Circular (Orbital Path)</option>
                <option value="figure_8">Figure of 8 (Bernoulli Lemniscate)</option>
                <option value="random">Random Walk (Brownian Drift)</option>
                <option value="spiral">Spiral (Expanding Radial)</option>
                <option value="sinusoidal">Sinusoidal (Waveform Path)</option>
              </select>
            </div>

            {/* Target Size Slider (5-20px configurable) */}
            <div>
              <div className="flex justify-between text-[11px] font-mono text-gray-400 mb-1">
                <span>BEACON SIZE:</span>
                <span className="text-white font-bold">{config.targetSizePx}×{config.targetSizePx} px</span>
              </div>
              <input
                type="range"
                min={5}
                max={20}
                step={1}
                value={config.targetSizePx}
                onChange={(e) => onUpdateConfig({ targetSizePx: parseInt(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-gray-500 font-mono mt-0.5">
                <span>5×5 (Min)</span>
                <span>10×10 (Default)</span>
                <span>20×20 (Max)</span>
              </div>
            </div>

            {/* Target Speed Slider */}
            <div>
              <div className="flex justify-between text-[11px] font-mono text-gray-400 mb-1">
                <span>TARGET VELOCITY:</span>
                <span className="text-white font-bold">{config.targetSpeedPxS} px/s</span>
              </div>
              <input
                type="range"
                min={20}
                max={220}
                step={5}
                value={config.targetSpeedPxS}
                onChange={(e) => onUpdateConfig({ targetSpeedPxS: parseInt(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Target Count Toggle */}
            <div className="pt-2 border-t border-[#1F2937] flex items-center justify-between">
              <span className="text-[11px] font-mono text-gray-400 font-semibold uppercase">Target Mode:</span>
              <button
                onClick={() => onUpdateConfig({ targetCount: config.targetCount === 1 ? 2 : 1 })}
                className={`px-3 py-1 rounded text-xs font-mono font-bold uppercase transition ${
                  config.targetCount === 1
                    ? 'bg-[#1F2937] text-gray-300 border border-[#374151]'
                    : 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                }`}
              >
                {config.targetCount === 1 ? 'Single (Mandatory)' : 'Multi-Target (Decoy)'}
              </button>
            </div>
          </div>

          {/* Disturbances & Environmental Noise Card */}
          <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-white font-bold text-xs uppercase tracking-widest border-b border-[#1F2937] pb-3">
              <Wind className="w-4 h-4 text-cyan-400" />
              <span>Disturbances & Noise (Phase 7)</span>
            </div>

            {/* Noise Type */}
            <div>
              <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
                Image Sensor Noise
              </label>
              <select
                value={distConfig.noiseType}
                onChange={(e) => onUpdateDistConfig({ noiseType: e.target.value as any })}
                className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                <option value="none">None (Clean Feed)</option>
                <option value="gaussian">Gaussian Noise (Additive σ)</option>
                <option value="salt_pepper">Salt-and-Pepper (Defective Pixels)</option>
                <option value="poisson">Poisson (Photon Shot Noise)</option>
              </select>
            </div>

            {/* Gaussian Noise Sigma */}
            {distConfig.noiseType === 'gaussian' && (
              <div>
                <div className="flex justify-between text-[11px] font-mono text-gray-400 mb-1">
                  <span>GAUSSIAN SIGMA (σ):</span>
                  <span className="text-amber-400 font-bold">{(distConfig.gaussianSigma ?? 0).toFixed(1)} px</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={20}
                  step={0.5}
                  value={distConfig.gaussianSigma}
                  onChange={(e) => onUpdateDistConfig({ gaussianSigma: parseFloat(e.target.value) })}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            )}

            {/* Atmospheric Condition */}
            <div>
              <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
                Atmospheric Condition
              </label>
              <select
                value={distConfig.atmosphericCondition}
                onChange={(e) => onUpdateDistConfig({ atmosphericCondition: e.target.value as any })}
                className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                <option value="clear">Clear Optical Channel</option>
                <option value="haze">Atmospheric Haze</option>
                <option value="fog">Heavy Fog Scattering</option>
                <option value="rain">Precipitation / Rain</option>
                <option value="low_light">Low Light / High Attenuation</option>
              </select>
            </div>

            {/* Camera Jitter */}
            <div className="flex items-center justify-between pt-2 border-t border-[#1F2937]">
              <span className="text-[11px] font-mono text-gray-400 uppercase font-semibold">Camera Jitter:</span>
              <button
                onClick={() => onUpdateDistConfig({ jitterEnabled: !distConfig.jitterEnabled })}
                className={`px-3 py-1 rounded text-xs font-mono font-bold uppercase transition ${
                  distConfig.jitterEnabled
                    ? 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                    : 'bg-[#1F2937] text-gray-400 border border-[#374151]'
                }`}
              >
                {distConfig.jitterEnabled ? `ON (±${distConfig.jitterAmplitudePx}px)` : 'OFF'}
              </button>
            </div>

            {/* Platform Motion */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] font-mono text-gray-400 uppercase font-semibold">Platform Motion:</span>
              <button
                onClick={() => onUpdateDistConfig({ platformMotionEnabled: !distConfig.platformMotionEnabled })}
                className={`px-3 py-1 rounded text-xs font-mono font-bold uppercase transition ${
                  distConfig.platformMotionEnabled
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-500/50'
                    : 'bg-[#1F2937] text-gray-400 border border-[#374151]'
                }`}
              >
                {distConfig.platformMotionEnabled ? `ON (±${distConfig.platformAmplitudePx}px)` : 'OFF'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
