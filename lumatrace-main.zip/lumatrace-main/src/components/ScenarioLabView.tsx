import React, { useState } from 'react';
import {
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  FlaskConical,
  Zap,
  Layers,
  Filter,
} from 'lucide-react';
import { SIH_SCENARIOS, ScenarioDefinition } from '../core/ScenarioDefinitions';
import { PerformanceMetrics } from '../types/fsoc';
import { VirtualCamera } from '../core/VirtualCamera';
import { TargetSimulator } from '../core/TargetSimulator';
import { ImageProcessor } from '../core/ImageProcessor';
import { TrackingEngine } from '../core/RiskAndRecovery';
import { MetricsEvaluator } from '../core/MetricsEvaluator';
import { LumaTracePredictiveController } from '../core/Controllers';
import { DEFAULT_CONFIG, DEFAULT_DISTURBANCE } from '../types/fsoc';

interface ScenarioResult {
  scenarioId: string;
  scenarioName: string;
  category: string;
  metrics: PerformanceMetrics;
  passedAll: boolean;
}

export const ScenarioLabView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isRunningBatch, setIsRunningBatch] = useState<boolean>(false);
  const [currentScenarioIndex, setCurrentScenarioIndex] = useState<number>(-1);
  const [progressPct, setProgressPct] = useState<number>(0);
  const [results, setResults] = useState<Record<string, ScenarioResult>>({});

  const filteredScenarios =
    selectedCategory === 'all'
      ? SIH_SCENARIOS
      : SIH_SCENARIOS.filter((s) => s.category === selectedCategory);

  // Executes a single scenario synchronously or step-by-step
  const runSingleScenarioSimulation = (scenario: ScenarioDefinition): ScenarioResult => {
    const config = { ...DEFAULT_CONFIG, ...scenario.configOverrides };
    const distConfig = { ...DEFAULT_DISTURBANCE, ...scenario.disturbanceOverrides };

    const camera = new VirtualCamera(config);
    const target = new TargetSimulator(config, 0);
    const imageProcessor = new ImageProcessor(config.cameraWidth, config.cameraHeight);
    const trackingEngine = new TrackingEngine(config.cameraWidth, config.cameraHeight);
    const evaluator = new MetricsEvaluator();
    const controller = new LumaTracePredictiveController(config);

    const offscreenCanvas = document.createElement('canvas');
    offscreenCanvas.width = config.cameraWidth;
    offscreenCanvas.height = config.cameraHeight;
    const ctx = offscreenCanvas.getContext('2d', { willReadFrequently: true })!;

    const dt = 1.0 / config.cameraUpdateRateHz;
    const totalSteps = Math.floor(scenario.durationSeconds / dt);

    for (let step = 0; step < totalSteps; step++) {
      const simTime = step * dt;

      // Check if artificial loss induced in this scenario
      if (
        scenario.induceLossAtSecond &&
        simTime >= scenario.induceLossAtSecond &&
        simTime <= scenario.induceLossAtSecond + 0.6
      ) {
        target.isActive = false;
      } else {
        target.isActive = true;
      }

      // Update target ground truth
      const targetState = target.update(dt, config.screenWidth, config.screenHeight);

      // Compute camera disturbances
      const motions = imageProcessor.computeMotionDisturbances(dt, distConfig);
      camera.applyDisturbances(
        motions.jitterX,
        motions.jitterY,
        motions.platformX,
        motions.platformY
      );

      // Camera projection
      const proj = camera.worldToViewport(
        targetState.worldX,
        targetState.worldY,
        targetState.sizePx
      );

      // Render optical frame
      imageProcessor.renderOpticalFrame(
        ctx,
        targetState.isActive ? proj : null,
        null,
        distConfig,
        { x: motions.jitterX, y: motions.jitterY }
      );

      const imgData = ctx.getImageData(0, 0, config.cameraWidth, config.cameraHeight);
      imageProcessor.applyNoiseToImageData(imgData, distConfig);

      // Ground truth is passed ONLY to compute centroiding error for performance metrics
      const gtViewport: [number, number] | null = proj.inside ? [proj.u, proj.v] : null;

      // Detect beacon WITHOUT using ground truth
      const detResult = imageProcessor.detectBeaconFromImageData(imgData, gtViewport, 95);

      // Update tracker
      const trackState = trackingEngine.update(detResult, dt);

      // Camera control
      const [panRate, tiltRate] = controller.computeControl(camera, trackState, dt);
      camera.update(dt, panRate, tiltRate);

      // Record metrics
      evaluator.recordFrame(
        simTime,
        detResult.detected,
        detResult.euclideanError,
        detResult.centroidingError,
        detResult.processingTimeMs,
        trackState.reacquisitionTimeS
      );
    }

    const metrics = evaluator.computeMetrics();
    const passedAll =
      metrics.sihCompliance.acquisitionTime.status === 'PASS' &&
      metrics.sihCompliance.trackingError.status === 'PASS' &&
      metrics.sihCompliance.targetLoss.status === 'PASS' &&
      metrics.sihCompliance.reacquisitionTime.status === 'PASS' &&
      metrics.sihCompliance.processingSpeed.status === 'PASS';

    return {
      scenarioId: scenario.id,
      scenarioName: scenario.name,
      category: scenario.category,
      metrics,
      passedAll,
    };
  };

  const handleRunBatch = async () => {
    setIsRunningBatch(true);
    setProgressPct(0);
    const newResults: Record<string, ScenarioResult> = {};

    for (let i = 0; i < SIH_SCENARIOS.length; i++) {
      setCurrentScenarioIndex(i);
      setProgressPct(Math.round(((i + 1) / SIH_SCENARIOS.length) * 100));

      // Small async tick to keep UI responsive
      await new Promise((resolve) => setTimeout(resolve, 60));

      const sc = SIH_SCENARIOS[i];
      const res = runSingleScenarioSimulation(sc);
      newResults[sc.id] = res;
      setResults({ ...newResults });
    }

    setIsRunningBatch(false);
    setCurrentScenarioIndex(-1);
  };

  const handleRunSingle = (sc: ScenarioDefinition) => {
    const res = runSingleScenarioSimulation(sc);
    setResults((prev) => ({ ...prev, [sc.id]: res }));
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Scenario Lab Header (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <FlaskConical className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-widest">
                SIH Problem Statement 4 Scenario Lab (Phase 13)
              </h2>
              <p className="text-xs text-gray-400">
                16 Pre-configured rigorous test conditions validating SIH coarse alignment metrics.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleRunBatch}
              disabled={isRunningBatch}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider shadow-sm transition ${
                isRunningBatch
                  ? 'bg-[#1F2937] text-gray-500 cursor-not-allowed border border-[#374151]'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>{isRunningBatch ? 'Simulating Batch...' : 'Batch Run All 16 Scenarios'}</span>
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        {isRunningBatch && (
          <div className="mt-4 space-y-1.5">
            <div className="flex justify-between text-xs font-mono text-cyan-400">
              <span>Running: {SIH_SCENARIOS[currentScenarioIndex]?.name}</span>
              <span>{progressPct}%</span>
            </div>
            <div className="w-full bg-[#0A0B10] rounded-full h-2 overflow-hidden border border-[#1F2937]">
              <div
                className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full transition-all duration-150"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-gray-400 font-mono text-[11px] font-semibold flex items-center gap-1 uppercase tracking-wider">
          <Filter className="w-3 h-3" /> Category:
        </span>
        {['all', 'trajectory', 'noise', 'disturbance', 'atmospheric', 'stress'].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 rounded-md text-xs font-mono font-bold uppercase transition ${
              selectedCategory === cat
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                : 'bg-[#0F1117] text-gray-400 border border-[#1F2937] hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Scenarios & Results Grid (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#0A0B10] text-gray-400 border-b border-[#1F2937] text-[11px]">
              <tr>
                <th className="p-3.5 font-semibold">Scenario</th>
                <th className="p-3.5 font-semibold">Category</th>
                <th className="p-3.5 font-semibold">Acq. Time (≤2.0s)</th>
                <th className="p-3.5 font-semibold">Avg Error (≤10px)</th>
                <th className="p-3.5 font-semibold">Target Loss (&lt;5%)</th>
                <th className="p-3.5 font-semibold">Re-acq. Time (≤1.0s)</th>
                <th className="p-3.5 font-semibold">FPS (≥20)</th>
                <th className="p-3.5 font-semibold">Status</th>
                <th className="p-3.5 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F2937] text-gray-300">
              {filteredScenarios.map((sc) => {
                const res = results[sc.id];
                return (
                  <tr key={sc.id} className="hover:bg-[#1F2937]/30 transition">
                    <td className="p-3.5">
                      <div className="font-bold text-white">{sc.name}</div>
                      <div className="text-[10px] text-gray-400 max-w-xs">{sc.description}</div>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-[#0A0B10] text-gray-400 border border-[#1F2937]">
                        {sc.category}
                      </span>
                    </td>
                    <td className="p-3.5">
                      {res ? (
                        <span className={res.metrics.sihCompliance.acquisitionTime.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                          {res.metrics.acquisitionTimeS}s
                        </span>
                      ) : (
                        <span className="text-gray-600">--</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {res ? (
                        <span className={res.metrics.sihCompliance.trackingError.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                          {res.metrics.averageTrackingErrorPx} px
                        </span>
                      ) : (
                        <span className="text-gray-600">--</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {res ? (
                        <span className={res.metrics.sihCompliance.targetLoss.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                          {res.metrics.targetLossPercentage}%
                        </span>
                      ) : (
                        <span className="text-gray-600">--</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {res ? (
                        <span className={res.metrics.sihCompliance.reacquisitionTime.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                          {res.metrics.reacquisitionTimeS}s
                        </span>
                      ) : (
                        <span className="text-gray-600">--</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {res ? (
                        <span className={res.metrics.sihCompliance.processingSpeed.status === 'PASS' ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                          {res.metrics.avgFps}
                        </span>
                      ) : (
                        <span className="text-gray-600">--</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {res ? (
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
                          res.passedAll
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}>
                          {res.passedAll ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                          {res.passedAll ? 'PASS' : 'WARN'}
                        </span>
                      ) : (
                        <span className="text-gray-600 text-[10px] font-bold">PENDING</span>
                      )}
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => handleRunSingle(sc)}
                        disabled={isRunningBatch}
                        className="px-3 py-1 rounded-md bg-[#1F2937] hover:bg-[#283548] text-white border border-[#374151] text-xs font-bold uppercase transition"
                      >
                        Run
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
