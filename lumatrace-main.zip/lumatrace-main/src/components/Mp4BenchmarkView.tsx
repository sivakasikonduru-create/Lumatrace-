import React, { useRef, useState, useEffect } from 'react';
import {
  Upload,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  FileCheck,
  Film,
  Download,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { ImageProcessor } from '../core/ImageProcessor';
import { TrackingEngine } from '../core/RiskAndRecovery';
import { MetricsEvaluator } from '../core/MetricsEvaluator';
import { DetectionResult, PerformanceMetrics, TrackingState } from '../types/fsoc';

export const Mp4BenchmarkView: React.FC = () => {
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [currentFrameIndex, setCurrentFrameIndex] = useState<number>(0);
  const [metrics, setMetrics] = useState<PerformanceMetrics | null>(null);
  const [frameLogs, setFrameLogs] = useState<any[]>([]);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const imageProcessorRef = useRef<ImageProcessor>(new ImageProcessor(640, 480));
  const trackerRef = useRef<TrackingEngine>(new TrackingEngine(640, 480));
  const evaluatorRef = useRef<MetricsEvaluator>(new MetricsEvaluator());

  // Handle local user MP4 upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setVideoSrc(url);
      resetBenchmark();
    }
  };

  // Synthesizes a 30 FPS SIH benchmark video on the fly if user doesn't have an MP4 file
  const generateSyntheticBenchmarkVideo = () => {
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = 640;
    tempCanvas.height = 480;
    const ctx = tempCanvas.getContext('2d');
    if (!ctx) return;

    // Check if MediaRecorder supports video
    const stream = tempCanvas.captureStream(30);
    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
    } catch {
      try {
        recorder = new MediaRecorder(stream);
      } catch (err) {
        alert('Browser MediaRecorder API unavailable for on-the-fly synthesis.');
        return;
      }
    }

    const chunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setVideoSrc(url);
      resetBenchmark();
    };

    recorder.start();

    // Render 180 frames (6 seconds of 30 FPS video with figure-8 beacon and noise)
    let frame = 0;
    const totalFrames = 180;
    const interval = setInterval(() => {
      frame++;
      const t = frame / 30.0;

      // Dark CMOS sensor background
      ctx.fillStyle = '#0a0e17';
      ctx.fillRect(0, 0, 640, 480);

      // Figure-8 trajectory inside 640x480
      const bx = 320 + 160 * Math.sin(t * 1.5);
      const by = 240 + 90 * Math.sin(2 * t * 1.5);

      // Temporary occlusion loss between 2.0s and 2.6s (frames 60 to 78) to test re-acquisition
      const isOccluded = frame >= 60 && frame <= 78;

      if (!isOccluded) {
        // Beacon bloom & spot (10x10 px)
        const radGrad = ctx.createRadialGradient(bx, by, 3, bx, by, 16);
        radGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
        radGrad.addColorStop(0.5, 'rgba(180, 220, 255, 0.4)');
        radGrad.addColorStop(1, 'rgba(50, 150, 255, 0)');
        ctx.fillStyle = radGrad;
        ctx.beginPath();
        ctx.arc(bx, by, 16, 0, 2 * Math.PI);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(bx - 5, by - 5, 10, 10);
      }

      // Add mild synthetic noise
      const imgData = ctx.getImageData(0, 0, 640, 480);
      const d = imgData.data;
      for (let i = 0; i < d.length; i += 16) {
        const n = (Math.random() - 0.5) * 16;
        d[i] = Math.max(0, Math.min(255, d[i] + n));
        d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n));
        d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n));
      }
      ctx.putImageData(imgData, 0, 0);

      if (frame >= totalFrames) {
        clearInterval(interval);
        recorder.stop();
      }
    }, 16);
  };

  const resetBenchmark = () => {
    setIsProcessing(false);
    setCurrentFrameIndex(0);
    setMetrics(null);
    setFrameLogs([]);
    trackerRef.current.reset();
    evaluatorRef.current.reset();
  };

  // Step/Frame Processing Loop at 30 FPS
  useEffect(() => {
    let animationFrameId: number;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const overlay = overlayCanvasRef.current;

    if (!isProcessing || !video || !canvas || !overlay) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const octx = overlay.getContext('2d');
    if (!ctx || !octx) return;

    let lastTime = performance.now();

    const processLoop = () => {
      if (video.paused || video.ended) {
        setIsProcessing(false);
        setMetrics(evaluatorRef.current.computeMetrics());
        return;
      }

      const now = performance.now();
      if (now - lastTime >= 32) {
        // approx 30 FPS frame rate interval
        lastTime = now;

        // 1. Draw video frame to hidden processing canvas
        ctx.drawImage(video, 0, 0, 640, 480);
        const imageData = ctx.getImageData(0, 0, 640, 480);

        // 2. Detect beacon using spatial moments (WITHOUT ground truth)
        const detResult: DetectionResult = imageProcessorRef.current.detectBeaconFromImageData(
          imageData,
          null, // No ground truth for detection
          90
        );

        // 3. Update Kalman tracker
        const trackState: TrackingState = trackerRef.current.update(detResult, 1.0 / 30.0);

        // 4. Record frame performance metrics
        evaluatorRef.current.recordFrame(
          video.currentTime,
          detResult.detected,
          detResult.euclideanError,
          null,
          detResult.processingTimeMs,
          trackState.reacquisitionTimeS
        );

        setCurrentFrameIndex((prev) => prev + 1);

        // 5. Draw visual HUD overlay on the display canvas
        octx.clearRect(0, 0, 640, 480);

        // Optical center crosshairs
        octx.strokeStyle = '#38bdf8';
        octx.lineWidth = 1.5;
        octx.beginPath();
        octx.moveTo(320 - 20, 240);
        octx.lineTo(320 + 20, 240);
        octx.moveTo(320, 240 - 20);
        octx.lineTo(320, 240 + 20);
        octx.stroke();

        if (detResult.detected) {
          // Bounding box & Centroid
          octx.strokeStyle = '#22c55e';
          octx.strokeRect(detResult.bbox[0], detResult.bbox[1], detResult.bbox[2], detResult.bbox[3]);
          octx.fillStyle = '#22c55e';
          octx.beginPath();
          octx.arc(detResult.centroidX, detResult.centroidY, 3, 0, 2 * Math.PI);
          octx.fill();

          // Tracking Error Vector
          octx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
          octx.setLineDash([4, 4]);
          octx.beginPath();
          octx.moveTo(320, 240);
          octx.lineTo(detResult.centroidX, detResult.centroidY);
          octx.stroke();
          octx.setLineDash([]);
        }

        // Add log entry (keep latest 50)
        setFrameLogs((prev) => [
          {
            frame: currentFrameIndex + 1,
            time: (video.currentTime ?? 0).toFixed(2),
            detected: detResult.detected,
            centroidX: detResult.detected ? (detResult.centroidX ?? 0).toFixed(1) : '-',
            centroidY: detResult.detected ? (detResult.centroidY ?? 0).toFixed(1) : '-',
            error: (detResult.euclideanError ?? 0).toFixed(1),
            confidence: (((detResult.confidence ?? 0) * 100)).toFixed(0) + '%',
            state: trackState.stateLabel,
            fps: (1000.0 / Math.max(0.1, detResult.processingTimeMs ?? 1)).toFixed(1),
          },
          ...prev.slice(0, 49),
        ]);
      }

      animationFrameId = requestAnimationFrame(processLoop);
    };

    animationFrameId = requestAnimationFrame(processLoop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isProcessing, currentFrameIndex]);

  const togglePlayback = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isProcessing) {
      video.pause();
      setIsProcessing(false);
      setMetrics(evaluatorRef.current.computeMetrics());
    } else {
      video.play();
      setIsProcessing(true);
    }
  };

  const exportBenchmarkCsv = () => {
    if (frameLogs.length === 0) return;
    const headers = ['frame', 'time', 'detected', 'centroidX', 'centroidY', 'error', 'confidence', 'state', 'fps'];
    const rows = frameLogs.map((log) => headers.map((h) => log[h]).join(','));
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'sih_mp4_benchmark_telemetry.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Benchmark Mode Header & File Setup (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <Film className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-widest">
                SIH MP4 Video Benchmark Evaluation Mode (Phase 10)
              </h2>
              <p className="text-xs text-gray-400">
                Direct frame-by-frame 30 FPS processing bypassing physical PTZ camera hardware.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <label className="cursor-pointer flex items-center gap-2 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-white font-bold uppercase tracking-wider text-xs transition border border-[#374151]">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload .MP4 Video</span>
              <input type="file" accept="video/mp4,video/webm" onChange={handleFileUpload} className="hidden" />
            </label>

            <button
              onClick={generateSyntheticBenchmarkVideo}
              className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-cyan-600 hover:bg-cyan-500 text-white font-bold uppercase tracking-wider text-xs transition shadow-sm"
              title="Synthesizes a 30 FPS test video with moving beacon spot & optical loss"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Generate SIH Benchmark Clip</span>
            </button>
          </div>
        </div>

        {/* Video Player & Overlay Display */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-4">
            <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden border border-[#1F2937] bg-[#050608] flex items-center justify-center shadow-inner">
              {videoSrc ? (
                <>
                  <video
                    ref={videoRef}
                    src={videoSrc}
                    playsInline
                    loop
                    className="w-full h-full object-contain"
                  />
                  {/* Hidden processing canvas */}
                  <canvas ref={canvasRef} width={640} height={480} className="hidden" />
                  {/* Visual tracking HUD overlay */}
                  <canvas
                    ref={overlayCanvasRef}
                    width={640}
                    height={480}
                    className="absolute inset-0 w-full h-full object-contain pointer-events-none"
                  />
                </>
              ) : (
                <div className="text-center p-8 space-y-3">
                  <Film className="w-12 h-12 text-gray-700 mx-auto" />
                  <p className="text-xs text-gray-400 font-mono">
                    No MP4 video loaded. Upload an SIH benchmark .mp4 or click "Generate SIH Benchmark Clip" above.
                  </p>
                </div>
              )}
            </div>

            {/* Video Playback & Scrub Controls */}
            {videoSrc && (
              <div className="bg-[#0A0B10] border border-[#1F2937] rounded-lg p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <button
                    onClick={togglePlayback}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider shadow transition ${
                      isProcessing ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-cyan-600 hover:bg-cyan-500 text-white'
                    }`}
                  >
                    {isProcessing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isProcessing ? 'Pause' : 'Process Benchmark (30 FPS)'}</span>
                  </button>

                  <button
                    onClick={resetBenchmark}
                    className="p-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-gray-300 border border-[#374151] transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono text-gray-400">
                  <span>Frame: #{currentFrameIndex}</span>
                  {frameLogs.length > 0 && (
                    <button
                      onClick={exportBenchmarkCsv}
                      className="flex items-center gap-1 px-3 py-1.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/50 hover:bg-emerald-900 font-bold uppercase text-[11px] transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export CSV</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right: SIH Benchmark Scorecard */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-[#0A0B10] border border-[#1F2937] rounded-lg p-4 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-widest text-white border-b border-[#1F2937] pb-2">
                SIH Problem Statement 4 Targets
              </h3>

              <div className="space-y-2.5 text-xs font-mono">
                <div className="flex justify-between items-center p-2.5 rounded bg-[#0F1117] border border-[#1F2937]">
                  <div>
                    <div className="text-gray-400 text-[10px] uppercase font-semibold">Acquisition Time</div>
                    <div className="text-white font-bold text-sm">
                      {metrics ? `${metrics.acquisitionTimeS}s` : '--'}
                    </div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                    metrics?.sihCompliance.acquisitionTime.status === 'PASS' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/50' : 'bg-[#1F2937] text-gray-400'
                  }`}>
                    {metrics ? metrics.sihCompliance.acquisitionTime.status : 'TARGET ≤ 2.0s'}
                  </span>
                </div>

                <div className="flex justify-between items-center p-2.5 rounded bg-[#0F1117] border border-[#1F2937]">
                  <div>
                    <div className="text-gray-400 text-[10px] uppercase font-semibold">Tracking Error</div>
                    <div className="text-white font-bold text-sm">
                      {metrics ? `${metrics.averageTrackingErrorPx} px` : '--'}
                    </div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                    metrics?.sihCompliance.trackingError.status === 'PASS' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/50' : 'bg-[#1F2937] text-gray-400'
                  }`}>
                    {metrics ? metrics.sihCompliance.trackingError.status : 'TARGET ≤ 10px'}
                  </span>
                </div>

                <div className="flex justify-between items-center p-2.5 rounded bg-[#0F1117] border border-[#1F2937]">
                  <div>
                    <div className="text-gray-400 text-[10px] uppercase font-semibold">Target Loss Rate</div>
                    <div className="text-white font-bold text-sm">
                      {metrics ? `${metrics.targetLossPercentage}%` : '--'}
                    </div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                    metrics?.sihCompliance.targetLoss.status === 'PASS' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/50' : 'bg-[#1F2937] text-gray-400'
                  }`}>
                    {metrics ? metrics.sihCompliance.targetLoss.status : 'TARGET < 5%'}
                  </span>
                </div>

                <div className="flex justify-between items-center p-2.5 rounded bg-[#0F1117] border border-[#1F2937]">
                  <div>
                    <div className="text-gray-400 text-[10px] uppercase font-semibold">Re-Acquisition Time</div>
                    <div className="text-white font-bold text-sm">
                      {metrics ? `${metrics.reacquisitionTimeS}s` : '--'}
                    </div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                    metrics?.sihCompliance.reacquisitionTime.status === 'PASS' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/50' : 'bg-[#1F2937] text-gray-400'
                  }`}>
                    {metrics ? metrics.sihCompliance.reacquisitionTime.status : 'TARGET ≤ 1.0s'}
                  </span>
                </div>

                <div className="flex justify-between items-center p-2.5 rounded bg-[#0F1117] border border-[#1F2937]">
                  <div>
                    <div className="text-gray-400 text-[10px] uppercase font-semibold">Compute Speed</div>
                    <div className="text-white font-bold text-sm">
                      {metrics ? `${metrics.avgFps} FPS` : '--'}
                    </div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                    metrics?.sihCompliance.processingSpeed.status === 'PASS' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/50' : 'bg-[#1F2937] text-gray-400'
                  }`}>
                    {metrics ? metrics.sihCompliance.processingSpeed.status : 'TARGET ≥ 20 FPS'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Frame-by-Frame Telemetry Log Table */}
        {frameLogs.length > 0 && (
          <div className="mt-6 bg-[#0A0B10] border border-[#1F2937] rounded-lg p-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white mb-3">
              Frame-by-Frame Real-Time Telemetry Log
            </h3>
            <div className="max-h-48 overflow-y-auto font-mono text-[11px] scrollbar-thin">
              <table className="w-full text-left">
                <thead className="text-gray-400 border-b border-[#1F2937] sticky top-0 bg-[#0A0B10]">
                  <tr>
                    <th className="pb-1.5 font-semibold">Frame</th>
                    <th className="pb-1.5 font-semibold">Time</th>
                    <th className="pb-1.5 font-semibold">Status</th>
                    <th className="pb-1.5 font-semibold">Centroid (X, Y)</th>
                    <th className="pb-1.5 font-semibold">Error (px)</th>
                    <th className="pb-1.5 font-semibold">Confidence</th>
                    <th className="pb-1.5 font-semibold">State</th>
                    <th className="pb-1.5 font-semibold">FPS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1F2937] text-gray-300">
                  {frameLogs.map((row, idx) => (
                    <tr key={idx} className="hover:bg-[#1F2937]/40">
                      <td className="py-1.5 text-gray-400">#{row.frame}</td>
                      <td className="py-1.5">{row.time}s</td>
                      <td className="py-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          row.detected ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                        }`}>
                          {row.detected ? 'DETECTED' : 'LOST'}
                        </span>
                      </td>
                      <td className="py-1.5 text-amber-300 font-medium">{row.centroidX !== '-' ? `(${row.centroidX}, ${row.centroidY})` : '-'}</td>
                      <td className="py-1.5 font-bold">{row.error}</td>
                      <td className="py-1.5 text-gray-400">{row.confidence}</td>
                      <td className="py-1.5 text-cyan-400 font-semibold">{row.state}</td>
                      <td className="py-1.5">{row.fps}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
