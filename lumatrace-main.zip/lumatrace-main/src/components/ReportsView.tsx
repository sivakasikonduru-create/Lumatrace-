import React from 'react';
import { FileText, Download, CheckCircle2, ShieldCheck, Printer, AlertTriangle } from 'lucide-react';
import { PerformanceMetrics } from '../types/fsoc';

interface ReportsViewProps {
  metrics: PerformanceMetrics;
  errorHistory: number[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ metrics, errorHistory }) => {
  const downloadJsonReport = () => {
    const reportData = {
      project: 'LumaTrace — AI-Based Virtual Camera Tracking System for Coarse Alignment of Mobile FSOC Terminals',
      problemStatement: 'SIH Problem Statement 4',
      timestamp: new Date().toISOString(),
      architecture: 'SENSE -> PREDICT -> ALIGN -> STABILIZE -> RECOVER -> VALIDATE',
      metrics,
    };
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sih_compliance_report_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadCsvTelemetry = () => {
    if (errorHistory.length === 0) return;
    const rows = ['Frame,TrackingErrorPx,TargetThresholdPx'];
    errorHistory.forEach((err, i) => {
      rows.push(`${i + 1},${(err ?? 0).toFixed(2)},10.0`);
    });
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sih_telemetry_errors_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Reports Header (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <FileText className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-widest">
              SIH Problem Statement 4 Compliance Audit & Reporting (Phase 14)
            </h2>
            <p className="text-xs text-gray-400">
              Formal audit verification scorecard evaluating all 5 core deliverables against SIH criteria.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={downloadJsonReport}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold uppercase tracking-wider shadow-sm transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Audit JSON</span>
          </button>

          <button
            onClick={downloadCsvTelemetry}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-white text-xs font-bold uppercase tracking-wider transition border border-[#374151]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV Telemetry</span>
          </button>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-gray-300 text-xs font-bold uppercase tracking-wider transition border border-[#374151]"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Compliance Audit Table */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg overflow-hidden shadow-sm">
        <div className="p-4 bg-[#0A0B10] border-b border-[#1F2937] flex items-center justify-between">
          <span className="text-xs font-bold font-mono text-white uppercase tracking-widest">
            Official SIH Performance Deliverables Verification Matrix
          </span>
          <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" /> AUDIT READY
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#0A0B10]/60 text-gray-400 border-b border-[#1F2937] text-[11px]">
              <tr>
                <th className="p-3.5 font-semibold">Requirement</th>
                <th className="p-3.5 font-semibold">SIH Criterion</th>
                <th className="p-3.5 font-semibold">Measured System Value</th>
                <th className="p-3.5 font-semibold">Unit</th>
                <th className="p-3.5 font-semibold">Status</th>
                <th className="p-3.5 font-semibold">Verification Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F2937] text-gray-300">
              {/* Deliverable 1: Acquisition Time */}
              <tr className="hover:bg-[#1F2937]/30 transition">
                <td className="p-3.5 font-bold text-white">Acquisition Time</td>
                <td className="p-3.5 text-cyan-400 font-bold">≤ 2.0 s</td>
                <td className="p-3.5 font-bold text-white text-sm">{metrics.acquisitionTimeS}</td>
                <td className="p-3.5 text-gray-400">seconds</td>
                <td className="p-3.5">
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
                    metrics.sihCompliance.acquisitionTime.status === 'PASS'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    {metrics.sihCompliance.acquisitionTime.status === 'PASS' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {metrics.sihCompliance.acquisitionTime.status}
                  </span>
                </td>
                <td className="p-3.5 text-[11px] text-gray-400">
                  Initial detection and centering into 4°×3° camera FOV.
                </td>
              </tr>

              {/* Deliverable 2: Tracking Error */}
              <tr className="hover:bg-[#1F2937]/30 transition">
                <td className="p-3.5 font-bold text-white">Coarse Tracking Error</td>
                <td className="p-3.5 text-cyan-400 font-bold">≤ 10.0 px</td>
                <td className="p-3.5 font-bold text-white text-sm">{metrics.averageTrackingErrorPx}</td>
                <td className="p-3.5 text-gray-400">pixels</td>
                <td className="p-3.5">
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
                    metrics.sihCompliance.trackingError.status === 'PASS'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    {metrics.sihCompliance.trackingError.status === 'PASS' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {metrics.sihCompliance.trackingError.status}
                  </span>
                </td>
                <td className="p-3.5 text-[11px] text-gray-400">
                  Average Euclidean offset from optical center (320, 240).
                </td>
              </tr>

              {/* Deliverable 3: Target Loss Rate */}
              <tr className="hover:bg-[#1F2937]/30 transition">
                <td className="p-3.5 font-bold text-white">Target Loss Percentage</td>
                <td className="p-3.5 text-cyan-400 font-bold">&lt; 5.0 %</td>
                <td className="p-3.5 font-bold text-white text-sm">{metrics.targetLossPercentage}</td>
                <td className="p-3.5 text-gray-400">%</td>
                <td className="p-3.5">
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
                    metrics.sihCompliance.targetLoss.status === 'PASS'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    {metrics.sihCompliance.targetLoss.status === 'PASS' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {metrics.sihCompliance.targetLoss.status}
                  </span>
                </td>
                <td className="p-3.5 text-[11px] text-gray-400">
                  Lock retention rate: {metrics.lockRetentionRate}%.
                </td>
              </tr>

              {/* Deliverable 4: Re-acquisition Time */}
              <tr className="hover:bg-[#1F2937]/30 transition">
                <td className="p-3.5 font-bold text-white">Re-acquisition Time</td>
                <td className="p-3.5 text-cyan-400 font-bold">≤ 1.0 s</td>
                <td className="p-3.5 font-bold text-white text-sm">{metrics.reacquisitionTimeS}</td>
                <td className="p-3.5 text-gray-400">seconds</td>
                <td className="p-3.5">
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
                    metrics.sihCompliance.reacquisitionTime.status === 'PASS'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    {metrics.sihCompliance.reacquisitionTime.status === 'PASS' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {metrics.sihCompliance.reacquisitionTime.status}
                  </span>
                </td>
                <td className="p-3.5 text-[11px] text-gray-400">
                  Time elapsed from loss until confirmed optical re-lock.
                </td>
              </tr>

              {/* Deliverable 5: Processing Speed */}
              <tr className="hover:bg-[#1F2937]/30 transition">
                <td className="p-3.5 font-bold text-white">Compute Processing Speed</td>
                <td className="p-3.5 text-cyan-400 font-bold">≥ 20.0 FPS</td>
                <td className="p-3.5 font-bold text-white text-sm">{metrics.avgFps}</td>
                <td className="p-3.5 text-gray-400">FPS</td>
                <td className="p-3.5">
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
                    metrics.sihCompliance.processingSpeed.status === 'PASS'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    {metrics.sihCompliance.processingSpeed.status === 'PASS' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {metrics.sihCompliance.processingSpeed.status}
                  </span>
                </td>
                <td className="p-3.5 text-[11px] text-gray-400">
                  Exceeds minimum 20 FPS requirement; camera update at ≥ 30 Hz.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
