import React from 'react';
import { Cpu, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const pipelineStages = [
    {
      stage: 'SENSE',
      title: 'Optical Acquisition & Detection',
      desc: 'Frame capture at ≥30 Hz, pixel moment analysis (M00, M10, M01), subpixel centroid calculation without ground-truth.',
      tag: 'OpenCV / Moments',
    },
    {
      stage: 'PREDICT',
      title: 'State Estimation & Lookahead',
      desc: '4-State Kalman Filter tracking target [x, y, vx, vy] with continuous lookahead trajectory projection.',
      tag: 'Kalman Filter 2D',
    },
    {
      stage: 'ALIGN',
      title: 'Predictive Gimbal Control',
      desc: 'Feedforward velocity compensation combined with proportional steering, clamped to 5.0°/s maximum rate.',
      tag: 'Predictive Controller',
    },
    {
      stage: 'STABILIZE',
      title: 'Disturbance & Jitter Rejection',
      desc: 'Rejection of camera jitter (±20 px), platform base motion (±20 px), and atmospheric scattering.',
      tag: 'Disturbance Engine',
    },
    {
      stage: 'RECOVER',
      title: 'Autonomous Re-acquisition',
      desc: 'State machine: TRACKING → TARGET_LOST → PREDICTIVE_SEARCH → RE_ACQUIRED within ≤ 1.0 second.',
      tag: 'Recovery Automaton',
    },
    {
      stage: 'VALIDATE',
      title: 'SIH Metrics Verification',
      desc: 'Real-time computation of Acquisition (≤2s), Tracking Error (≤10px), Target Loss (<5%), and Speed (≥20 FPS).',
      tag: 'Metrics Evaluator',
    },
  ];

  const sihRequirementMappings = [
    {
      req: 'Virtual Screen Canvas',
      spec: 'Minimum 2000 × 2000 pixels',
      module: '/src/core/VirtualCamera.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Virtual Camera Resolution',
      spec: '640 × 480 pixels (default)',
      module: '/src/core/VirtualCamera.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Camera Field of View',
      spec: '4.0° horizontal × 3.0° vertical',
      module: '/src/core/VirtualCamera.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Optical Beacon Spot',
      spec: 'Square 10×10 px default (5–20 px configurable)',
      module: '/src/core/ImageProcessor.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Target Trajectories',
      spec: 'Straight Line, Circular, Figure-8, Random Walk',
      module: '/src/core/TargetSimulator.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Ground Truth Separation',
      spec: 'GT stored solely for evaluation, never fed to detector',
      module: '/src/core/ImageProcessor.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Acquisition Time',
      spec: '≤ 2.0 seconds',
      module: '/src/core/MetricsEvaluator.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Coarse Tracking Error',
      spec: '≤ 10.0 pixels',
      module: '/src/core/Controllers.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Target Loss Rate',
      spec: '< 5.0 %',
      module: '/src/core/RiskAndRecovery.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Autonomous Re-acquisition',
      spec: '≤ 1.0 second',
      module: '/src/core/RiskAndRecovery.ts',
      status: 'VERIFIED',
    },
    {
      req: 'Processing Speed',
      spec: '≥ 20 FPS (Camera update ≥ 30 Hz)',
      module: '/src/core/ImageProcessor.ts',
      status: 'VERIFIED',
    },
    {
      req: 'MP4 Benchmark Video',
      spec: '30 FPS video evaluation pipeline bypassing PTZ hardware',
      module: '/src/components/Mp4BenchmarkView.tsx',
      status: 'VERIFIED',
    },
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Architecture Header (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <Cpu className="w-5 h-5 text-cyan-400" />
          <h2 className="text-sm font-bold text-white uppercase tracking-widest">
            System Architecture: SENSE → PREDICT → ALIGN → STABILIZE → RECOVER → VALIDATE
          </h2>
        </div>
        <p className="text-xs text-gray-400 max-w-4xl leading-relaxed">
          LumaTrace is strictly engineered to fulfill SIH Problem Statement 4. The system implements a robust virtual optical testbench, executing subpixel centroiding, predictive Kalman trajectory modeling, rate-limited gimbal steering, and autonomous recovery for coarse optical alignment of mobile FSOC terminals.
        </p>
      </div>

      {/* 6-Stage Pipeline Graphic Flow */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {pipelineStages.map((st, i) => (
          <div key={st.stage} className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-4 shadow-sm space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-400 border border-cyan-500/50">
                STAGE {i + 1}: {st.stage}
              </span>
              <span className="text-[10px] font-mono text-gray-500">{st.tag}</span>
            </div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">{st.title}</h3>
            <p className="text-[11px] text-gray-400 leading-normal">{st.desc}</p>
          </div>
        ))}
      </div>

      {/* SIH Problem Statement 4 Requirements Mapping Matrix */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg overflow-hidden shadow-sm">
        <div className="p-4 bg-[#0A0B10] border-b border-[#1F2937] flex items-center justify-between">
          <span className="text-xs font-bold font-mono text-white uppercase tracking-widest">
            SIH Problem Statement 4 Implementation Traceability Matrix
          </span>
          <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" /> 100% SPECIFICATION COVERAGE
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#0A0B10]/60 text-gray-400 border-b border-[#1F2937] text-[11px]">
              <tr>
                <th className="p-3.5 font-semibold">Requirement</th>
                <th className="p-3.5 font-semibold">SIH Criterion / Specification</th>
                <th className="p-3.5 font-semibold">Core Module / Component</th>
                <th className="p-3.5 font-semibold">Compliance Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F2937] text-gray-300">
              {sihRequirementMappings.map((row, idx) => (
                <tr key={idx} className="hover:bg-[#1F2937]/30 transition">
                  <td className="p-3.5 font-bold text-white">{row.req}</td>
                  <td className="p-3.5 text-cyan-400 font-bold">{row.spec}</td>
                  <td className="p-3.5 text-gray-400">{row.module}</td>
                  <td className="p-3.5">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" />
                      {row.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
