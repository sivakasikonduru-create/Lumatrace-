import React from 'react';
import { Sliders, RotateCcw } from 'lucide-react';
import { SimulationConfig } from '../types/fsoc';

interface ConfigViewProps {
  config: SimulationConfig;
  onUpdateConfig: (partial: Partial<SimulationConfig>) => void;
  onResetToDefault: () => void;
}

export const ConfigView: React.FC<ConfigViewProps> = ({
  config,
  onUpdateConfig,
  onResetToDefault,
}) => {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-5xl mx-auto text-[#E0E0E0]">
      {/* Configuration Header (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Sliders className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-widest">
              System Configuration & SIH Hardware Parameters
            </h2>
            <p className="text-xs text-gray-400">
              Direct tuning of all physical parameters mandated by SIH Problem Statement 4.
            </p>
          </div>
        </div>

        <button
          onClick={onResetToDefault}
          className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-white font-bold uppercase tracking-wider text-xs transition border border-[#374151]"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Restore SIH Defaults</span>
        </button>
      </div>

      {/* Parameter Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Section 3: Simulation Mode */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4 md:col-span-2">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-widest border-b border-[#1F2937] pb-3">
            Simulation Mode Selection
          </h3>
          <div className="flex gap-4">
            <button
              onClick={() => onUpdateConfig({ simulationMode: 'standard' })}
              className={`flex-1 py-2 px-4 rounded text-xs font-bold uppercase transition ${config.simulationMode === 'standard' ? 'bg-cyan-600 text-white' : 'bg-[#1F2937] text-gray-400 hover:bg-[#283548]'}`}
            >
              Standard 2D FSOC
            </button>
            <button
              onClick={() => onUpdateConfig({ simulationMode: 'drone_to_drone' })}
              className={`flex-1 py-2 px-4 rounded text-xs font-bold uppercase transition ${config.simulationMode === 'drone_to_drone' ? 'bg-cyan-600 text-white' : 'bg-[#1F2937] text-gray-400 hover:bg-[#283548]'}`}
            >
              Drone-to-Drone 3D FSOC
            </button>
          </div>
        </div>

        {/* Section 1: Screen & Camera Geometry */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-widest border-b border-[#1F2937] pb-3">
            Screen & Camera Geometry (SIH PS-04)
          </h3>

          <div>
            <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
              Virtual Screen Canvas (Min 2000×2000 px)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <input
                type="number"
                value={config.screenWidth}
                onChange={(e) => onUpdateConfig({ screenWidth: parseInt(e.target.value) || 2000 })}
                className="bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="Width (2000)"
              />
              <input
                type="number"
                value={config.screenHeight}
                onChange={(e) => onUpdateConfig({ screenHeight: parseInt(e.target.value) || 2000 })}
                className="bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="Height (2000)"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
              Camera Sensor Resolution (640×480 default)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <input
                type="number"
                value={config.cameraWidth}
                onChange={(e) => onUpdateConfig({ cameraWidth: parseInt(e.target.value) || 640 })}
                className="bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="640"
              />
              <input
                type="number"
                value={config.cameraHeight}
                onChange={(e) => onUpdateConfig({ cameraHeight: parseInt(e.target.value) || 480 })}
                className="bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                placeholder="480"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
              Camera Field Of View (FOV 4.0° × 3.0° default)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-gray-500 font-mono block mb-1">Horizontal (deg)</span>
                <input
                  type="number"
                  step="0.1"
                  value={config.cameraFovHDeg}
                  onChange={(e) => onUpdateConfig({ cameraFovHDeg: parseFloat(e.target.value) || 4.0 })}
                  className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>
              <div>
                <span className="text-[10px] text-gray-500 font-mono block mb-1">Vertical (deg)</span>
                <input
                  type="number"
                  step="0.1"
                  value={config.cameraFovVDeg}
                  onChange={(e) => onUpdateConfig({ cameraFovVDeg: parseFloat(e.target.value) || 3.0 })}
                  className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Motion Limits & Update Frequencies */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-widest border-b border-[#1F2937] pb-3">
            Timing & Actuation Limits (SIH PS-04)
          </h3>

          <div>
            <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
              Camera Update Rate (≥ 30 Hz)
            </label>
            <input
              type="number"
              value={config.cameraUpdateRateHz}
              onChange={(e) => onUpdateConfig({ cameraUpdateRateHz: parseInt(e.target.value) || 30 })}
              className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          <div>
            <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
              Controller Frequency (≥ 20 Hz)
            </label>
            <input
              type="number"
              value={config.controllerFrequencyHz}
              onChange={(e) => onUpdateConfig({ controllerFrequencyHz: parseInt(e.target.value) || 20 })}
              className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          <div>
            <label className="block text-[10px] font-mono text-gray-400 uppercase font-semibold mb-1.5">
              Max Angular Speed Limits (≤ 5.0 °/s Pan/Tilt)
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-gray-500 font-mono block mb-1">Pan Max (°/s)</span>
                <input
                  type="number"
                  step="0.5"
                  value={config.maxPanSpeedDegS}
                  onChange={(e) => onUpdateConfig({ maxPanSpeedDegS: parseFloat(e.target.value) || 5.0 })}
                  className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>
              <div>
                <span className="text-[10px] text-gray-500 font-mono block mb-1">Tilt Max (°/s)</span>
                <input
                  type="number"
                  step="0.5"
                  value={config.maxTiltSpeedDegS}
                  onChange={(e) => onUpdateConfig({ maxTiltSpeedDegS: parseFloat(e.target.value) || 5.0 })}
                  className="w-full bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

        {/* Section 4: Line of Sight / Obstructions */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4 md:col-span-2">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-widest border-b border-[#1F2937] pb-3">
            LOS / Physical Obstructions
          </h3>
          <div className="flex gap-4">
            <button
              onClick={() => onUpdateConfig({ losObstructionEnabled: !config.losObstructionEnabled })}
              className={`flex-1 py-2 px-4 rounded text-xs font-bold uppercase transition ${config.losObstructionEnabled ? 'bg-rose-600 text-white' : 'bg-[#1F2937] text-gray-400 hover:bg-[#283548]'}`}
            >
              Moving Obstacles {config.losObstructionEnabled ? 'ON' : 'OFF'}
            </button>
            <select
              value={config.losObstructionSeverity || 'partial'}
              onChange={(e) => onUpdateConfig({ losObstructionSeverity: e.target.value as 'partial' | 'full' })}
              disabled={!config.losObstructionEnabled}
              className="flex-1 bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500 disabled:opacity-50"
            >
              <option value="partial">Partial Occlusion</option>
              <option value="full">Complete Obstruction</option>
            </select>
          </div>
        </div>

    </div>
  );
};
