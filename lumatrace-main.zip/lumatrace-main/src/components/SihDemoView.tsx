import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Sparkles,
  Zap,
  RotateCcw,
  ShieldCheck,
  Target,
} from 'lucide-react';
import { SimulationConfig, DisturbanceConfig } from '../types/fsoc';

interface SihDemoViewProps {
  onApplyPreset: (config: Partial<SimulationConfig>, dist: Partial<DisturbanceConfig>, induceLoss?: boolean) => void;
  onReset: () => void;
  onToggleRunning: (running: boolean) => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  currentError: number;
  currentFps: number;
}

interface DemoStep {
  step: number;
  title: string;
  badge: string;
  description: string;
  sihRequirement: string;
  config: Partial<SimulationConfig>;
  dist: Partial<DisturbanceConfig>;
  induceLoss?: boolean;
}

const DEMO_STEPS: DemoStep[] = [
  {
    step: 1,
    title: 'Virtual Environment Initialization',
    badge: 'PHASE 2 • SCENE SETUP',
    description: 'Virtual 2000×2000 coordinate space rendered with stationary reference terminal, remote mobile terminal, and 640×480 camera FOV (4°×3°).',
    sihRequirement: 'Screen: ≥ 2000×2000 pixels, Camera FOV: 4°×3°, Resolution: 640×480',
    config: { targetMotionMode: 'straight_line', targetSpeedPxS: 50, controllerType: 'predictive' },
    dist: { noiseType: 'none', atmosphericCondition: 'clear', jitterEnabled: false, platformMotionEnabled: false },
  },
  {
    step: 2,
    title: 'Beacon Detection & Centroiding',
    badge: 'PHASE 4 • CV CENTROIDING',
    description: 'Optical beacon square spot (10×10 px) detected via spatial moments M00, M10, M01 without receiving ground truth coordinates.',
    sihRequirement: 'Processing speed: ≥ 20 FPS, Real-time centroid calculation',
    config: { targetMotionMode: 'straight_line', targetSpeedPxS: 65 },
    dist: { noiseType: 'none', atmosphericCondition: 'clear' },
  },
  {
    step: 3,
    title: 'Closed-Loop Coarse Alignment Lock',
    badge: 'PHASE 5 • ACQUISITION',
    description: 'Pan/tilt rates commanded to center beacon within optical axis; acquisition achieved within ≤ 2.0 seconds.',
    sihRequirement: 'Acquisition time: ≤ 2.0 s, Angular speed limit: ≤ 5.0 °/s',
    config: { targetMotionMode: 'circular', targetSpeedPxS: 75 },
    dist: { noiseType: 'none', atmosphericCondition: 'clear' },
  },
  {
    step: 4,
    title: 'Dynamic Figure-8 Trajectory Tracking',
    badge: 'PHASE 6 • TRACKING',
    description: 'Continuous dual-axis curved motion evaluated with LumaTrace predictive Kalman tracking keeping error strictly ≤ 10 px.',
    sihRequirement: 'Tracking error: ≤ 10.0 pixels, Target loss: < 5%',
    config: { targetMotionMode: 'figure_8', targetSpeedPxS: 90 },
    dist: { noiseType: 'none', atmosphericCondition: 'clear' },
  },
  {
    step: 5,
    title: 'Sensor Noise & Mechanical Jitter Injection',
    badge: 'PHASE 7 • DISTURBANCES',
    description: 'Additive Gaussian sensor noise (σ=12 px) and high-frequency camera vibration (±16 px/frame) injected into the pipeline.',
    sihRequirement: 'Disturbance rejection up to ±20 pixels/frame',
    config: { targetMotionMode: 'figure_8', targetSpeedPxS: 85 },
    dist: { noiseType: 'gaussian', gaussianSigma: 12.0, jitterEnabled: true, jitterAmplitudePx: 16.0 },
  },
  {
    step: 6,
    title: 'Atmospheric Fog & Contrast Degradation',
    badge: 'PHASE 7 • ATMOSPHERE',
    description: 'Optical blooming and severe contrast attenuation simulating real-world fog scattering conditions.',
    sihRequirement: 'Robust beacon extraction under adverse optical transmission',
    config: { targetMotionMode: 'figure_8', targetSpeedPxS: 80 },
    dist: { noiseType: 'gaussian', gaussianSigma: 8.0, atmosphericCondition: 'fog', contrastReduction: 0.4 },
  },
  {
    step: 7,
    title: 'Induced Optical Occlusion / Signal Loss',
    badge: 'PHASE 8 • TARGET LOSS',
    description: 'Beacon signal temporarily obstructed; tracking state machine transitions from TRACKING → TARGET_LOST → PREDICTIVE_SEARCH.',
    sihRequirement: 'Target loss detection and recovery mechanism trigger',
    config: { targetMotionMode: 'figure_8', targetSpeedPxS: 80 },
    dist: { noiseType: 'none' },
    induceLoss: true,
  },
  {
    step: 8,
    title: 'Autonomous Re-acquisition Within ≤ 1.0s',
    badge: 'PHASE 8 • RE-ACQUISITION',
    description: 'Beacon reappears; predictive search autonomously re-acquires the optical beacon in ≤ 1.0 second.',
    sihRequirement: 'Re-acquisition time: ≤ 1.0 s',
    config: { targetMotionMode: 'figure_8', targetSpeedPxS: 80 },
    dist: { noiseType: 'none', atmosphericCondition: 'clear' },
  },
  {
    step: 9,
    title: 'Final SIH Compliance Verification',
    badge: 'PHASE 14 • AUDIT PASSED',
    description: 'All 5 core SIH deliverables verified: Acq ≤2.0s, Error ≤10px, Loss <5%, Re-acq ≤1.0s, Speed ≥20 FPS.',
    sihRequirement: 'All SIH Problem Statement 4 technical criteria fulfilled',
    config: { targetMotionMode: 'circular', targetSpeedPxS: 75 },
    dist: { noiseType: 'none', atmosphericCondition: 'clear' },
  },
];

export const SihDemoView: React.FC<SihDemoViewProps> = ({
  onApplyPreset,
  onReset,
  onToggleRunning,
  canvasRef,
  currentError,
  currentFps,
}) => {
  const [currentStepIdx, setCurrentStepIdx] = useState<number>(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);

  const step = DEMO_STEPS[currentStepIdx];

  const applyCurrentStep = (idx: number) => {
    const s = DEMO_STEPS[idx];
    onApplyPreset(s.config, s.dist, s.induceLoss);
    onToggleRunning(true);
  };

  useEffect(() => {
    applyCurrentStep(currentStepIdx);
  }, [currentStepIdx]);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const timer = setInterval(() => {
      setCurrentStepIdx((prev) => {
        if (prev < DEMO_STEPS.length - 1) {
          return prev + 1;
        } else {
          setIsAutoPlaying(false);
          return prev;
        }
      });
    }, 6000); // 6 seconds per demo phase
    return () => clearInterval(timer);
  }, [isAutoPlaying]);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1600px] mx-auto text-[#E0E0E0]">
      {/* Demo Header (Geometric Balance) */}
      <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Sparkles className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-widest">
              SIH Problem Statement 4 Presentation Demo (Phase 15)
            </h2>
            <p className="text-xs text-gray-400">
              Interactive 9-step guided walkthrough verifying full SIH Problem Statement 4 compliance.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider shadow-sm transition ${
              isAutoPlaying ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-cyan-600 hover:bg-cyan-500 text-white'
            }`}
          >
            {isAutoPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isAutoPlaying ? 'Pause Auto-Play' : 'Auto-Play Walkthrough'}</span>
          </button>

          <button
            onClick={() => {
              setCurrentStepIdx(0);
              onReset();
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] text-gray-300 hover:text-white text-xs font-bold uppercase tracking-wider transition border border-[#374151]"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restart Demo</span>
          </button>
        </div>
      </div>

      {/* Step Stepper Progression Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-mono">
        {DEMO_STEPS.map((s, idx) => (
          <button
            key={s.step}
            onClick={() => {
              setIsAutoPlaying(false);
              setCurrentStepIdx(idx);
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-md whitespace-nowrap uppercase tracking-wider font-semibold transition ${
              currentStepIdx === idx
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 font-bold'
                : 'bg-[#0F1117] text-gray-400 hover:text-white border border-[#1F2937]'
            }`}
          >
            <span className="text-cyan-400 font-bold">{s.step}.</span>
            <span className="hidden sm:inline">{s.title.split(' ')[0]}</span>
          </button>
        ))}
      </div>

      {/* Main Demo Stage View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Step Details & Requirement Card */}
        <div className="lg:col-span-5 bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-400 border border-cyan-500/50">
                {step.badge}
              </span>
              <span className="text-xs font-mono text-gray-400">
                Step {step.step} of {DEMO_STEPS.length}
              </span>
            </div>

            <h3 className="text-base font-bold text-white uppercase tracking-wide">{step.title}</h3>
            <p className="text-xs text-gray-300 leading-relaxed">{step.description}</p>

            <div className="bg-[#0A0B10] border border-[#1F2937] rounded-md p-3.5 space-y-1.5">
              <div className="text-[10px] font-mono uppercase font-semibold text-gray-400 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-cyan-400" />
                <span>SIH Problem Statement 4 Directive:</span>
              </div>
              <div className="text-xs font-mono text-amber-300 font-bold">
                {step.sihRequirement}
              </div>
            </div>
          </div>

          {/* Stepper Navigation */}
          <div className="flex items-center justify-between pt-4 border-t border-[#1F2937]">
            <button
              onClick={() => {
                setIsAutoPlaying(false);
                setCurrentStepIdx((p) => Math.max(0, p - 1));
              }}
              disabled={currentStepIdx === 0}
              className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#1F2937] hover:bg-[#283548] disabled:opacity-30 text-gray-300 hover:text-white text-xs font-bold uppercase tracking-wider transition border border-[#374151]"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              onClick={() => {
                setIsAutoPlaying(false);
                setCurrentStepIdx((p) => Math.min(DEMO_STEPS.length - 1, p + 1));
              }}
              disabled={currentStepIdx === DEMO_STEPS.length - 1}
              className="flex items-center gap-1.5 px-4 py-2 rounded-md bg-cyan-600 hover:bg-cyan-500 disabled:opacity-30 text-white text-xs font-bold uppercase tracking-wider transition shadow-sm"
            >
              <span>Next Stage</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right: Live Camera Sensor Feed with Overlays */}
        <div className="lg:col-span-7 bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3 text-xs font-mono">
            <span className="text-white uppercase tracking-widest font-bold">
              Live Sensor Execution Viewport
            </span>
            <div className="flex items-center gap-3">
              <span className="text-gray-400">Error: </span>
              <span className={(currentError ?? 0) <= 10.0 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                {(currentError ?? 0).toFixed(1)} px
              </span>
              <span className="text-gray-600">|</span>
              <span className="text-gray-400">Rate: </span>
              <span className="text-cyan-400 font-bold">{(currentFps ?? 0).toFixed(1)} FPS</span>
            </div>
          </div>

          <div className="relative aspect-[4/3] w-full rounded-md overflow-hidden border border-[#1F2937] bg-[#0A0B10] flex items-center justify-center">
            <canvas ref={canvasRef} width={640} height={480} className="w-full h-full object-contain" />
          </div>
        </div>
      </div>
    </div>
  );
};
