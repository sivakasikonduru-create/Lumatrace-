import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Sidebar, Header, NavTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { LiveSimulationView } from './components/LiveSimulationView';
import { Mp4BenchmarkView } from './components/Mp4BenchmarkView';
import { ScenarioLabView } from './components/ScenarioLabView';
import { AbComparisonView } from './components/AbComparisonView';
import { AnalyticsView } from './components/AnalyticsView';
import { SihDemoView } from './components/SihDemoView';
import { ReportsView } from './components/ReportsView';
import { ConfigView } from './components/ConfigView';
import { ArchitectureView } from './components/ArchitectureView';
import { GuideView } from './components/GuideView';

import {
  CameraState,
  DEFAULT_CONFIG,
  DEFAULT_DISTURBANCE,
  DetectionResult,
  DisturbanceConfig,
  PerformanceMetrics,
  SimulationConfig,
  TargetState,
  TrackingState,
} from './types/fsoc';
import { VirtualCamera } from './core/VirtualCamera';
import { TargetSimulator } from './core/TargetSimulator';
import { ImageProcessor } from './core/ImageProcessor';
import { TrackingEngine } from './core/RiskAndRecovery';
import { MetricsEvaluator } from './core/MetricsEvaluator';
import { BaselineReactiveController, LumaTracePredictiveController } from './core/Controllers';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isRunning, setIsRunning] = useState<boolean>(true);

  // System Configurations
  const [config, setConfig] = useState<SimulationConfig>(DEFAULT_CONFIG);
  const [distConfig, setDistConfig] = useState<DisturbanceConfig>(DEFAULT_DISTURBANCE);

  // Canvas ref for optical viewport rendering
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Core Simulation Instances
  const cameraRef = useRef<VirtualCamera>(new VirtualCamera(DEFAULT_CONFIG));
  const targetRef = useRef<TargetSimulator>(new TargetSimulator(DEFAULT_CONFIG, 0));
  const secondaryTargetRef = useRef<TargetSimulator>(new TargetSimulator(DEFAULT_CONFIG, 1, [150, -120]));
  const imageProcessorRef = useRef<ImageProcessor>(new ImageProcessor(640, 480));
  const trackingEngineRef = useRef<TrackingEngine>(new TrackingEngine(640, 480));
  const metricsEvaluatorRef = useRef<MetricsEvaluator>(new MetricsEvaluator());

  // Controllers
  const baselineCtrlRef = useRef<BaselineReactiveController>(new BaselineReactiveController(DEFAULT_CONFIG));
  const predictiveCtrlRef = useRef<LumaTracePredictiveController>(new LumaTracePredictiveController(DEFAULT_CONFIG));

  // Telemetry States for React UI
  const [cameraState, setCameraState] = useState<CameraState>(() => cameraRef.current.getState());
  const [targetState, setTargetState] = useState<TargetState>(() => targetRef.current.update(0));
  const [detection, setDetection] = useState<DetectionResult>({
    detected: false,
    bbox: [0, 0, 0, 0],
    centroidX: 0,
    centroidY: 0,
    confidence: 0,
    processingTimeMs: 0,
    cameraCenterX: 320,
    cameraCenterY: 240,
    horizontalError: 0,
    verticalError: 0,
    euclideanError: 0,
    centroidingError: null,
  });
  const [tracking, setTracking] = useState<TrackingState>({
    stateLabel: 'SEARCHING',
    currentX: 320,
    currentY: 240,
    predictedX: 320,
    predictedY: 240,
    velocityX: 0,
    velocityY: 0,
    uncertainty: 0,
    confidence: 0,
    consecutiveHits: 0,
    consecutiveMisses: 0,
    reacquisitionTimeS: 0,
    riskLevel: 'SAFE',
    riskReason: 'Initializing optical tracking loop',
    predictedFovLoss: 'LOW',
    failureCause: null,
    controlSaturated: false,
  });

  const [metrics, setMetrics] = useState<PerformanceMetrics>(() => metricsEvaluatorRef.current.computeMetrics());
  const [groundTruthHistory, setGroundTruthHistory] = useState<TargetState[]>([]);
  const [errorHistory, setErrorHistory] = useState<number[]>([]);
  const [fpsHistory, setFpsHistory] = useState<number[]>([]);
  const [liveFps, setLiveFps] = useState<number>(30.0);

  // Handle configuration updates
  const handleUpdateConfig = useCallback((partial: Partial<SimulationConfig>) => {
    setConfig((prev) => {
      const next = { ...prev, ...partial };
      // Sync instances
      cameraRef.current = new VirtualCamera(next);
      targetRef.current.speed = next.targetSpeedPxS;
      targetRef.current.size = next.targetSizePx;
      targetRef.current.motionMode = next.targetMotionMode;
      baselineCtrlRef.current = new BaselineReactiveController(next);
      predictiveCtrlRef.current = new LumaTracePredictiveController(next);
      return next;
    });
  }, []);

  const handleUpdateDistConfig = useCallback((partial: Partial<DisturbanceConfig>) => {
    setDistConfig((prev) => ({ ...prev, ...partial }));
  }, []);

  const handleReset = useCallback(() => {
    cameraRef.current.reset();
    targetRef.current.reset();
    secondaryTargetRef.current.reset();
    trackingEngineRef.current.reset();
    metricsEvaluatorRef.current.reset();
    setGroundTruthHistory([]);
    setErrorHistory([]);
    setFpsHistory([]);
    setMetrics(metricsEvaluatorRef.current.computeMetrics());
  }, []);

  // Induce temporary optical loss to verify autonomous re-acquisition (Phase 8)
  const handleInduceLoss = useCallback(() => {
    targetRef.current.isActive = false;
    setTimeout(() => {
      targetRef.current.isActive = true;
    }, 600); // occluded for 600ms
  }, []);

  // Manual PTZ jog nudge
  const handleManualNudge = useCallback((dPan: number, dTilt: number) => {
    cameraRef.current.nudge(dPan, dTilt);
    setCameraState(cameraRef.current.getState());
  }, []);

  // Preset applicator for SIH Demo Walkthrough
  const handleApplyPreset = useCallback(
    (cfg: Partial<SimulationConfig>, dist: Partial<DisturbanceConfig>, induceLoss?: boolean) => {
      handleUpdateConfig(cfg);
      handleUpdateDistConfig(dist);
      if (induceLoss) {
        handleInduceLoss();
      }
    },
    [handleUpdateConfig, handleUpdateDistConfig, handleInduceLoss]
  );

  // Master Simulation & Optical Processing Loop
  useEffect(() => {
    let animId: number;
    let lastFrameTime = performance.now();
    let frameCounter = 0;
    let lastFpsUpdate = performance.now();

    const simulationLoop = (now: number) => {
      if (isRunning) {
        const deltaMs = now - lastFrameTime;
        // Run at target camera update rate interval (e.g. ~33ms for 30Hz)
        const targetInterval = 1000.0 / config.cameraUpdateRateHz;

        if (deltaMs >= targetInterval * 0.9) {
          const dt = Math.min(0.06, deltaMs / 1000.0);
          lastFrameTime = now;
          frameCounter++;

          // 1. Update Target Motion (Ground Truth)
          const curTargetState = targetRef.current.update(dt, config.screenWidth, config.screenHeight);
          let secTargetState: TargetState | null = null;
          if (config.targetCount > 1) {
            secTargetState = secondaryTargetRef.current.update(dt, config.screenWidth, config.screenHeight);
          }

          // 2. Compute Disturbance Offsets (Jitter + Platform Motion)
          const disturbances = imageProcessorRef.current.computeMotionDisturbances(dt, distConfig);
          cameraRef.current.applyDisturbances(
            disturbances.jitterX,
            disturbances.jitterY,
            disturbances.platformX,
            disturbances.platformY
          );

          // 3. Project Target into Camera Viewport
          const primaryProj = cameraRef.current.worldToViewport(curTargetState.worldX, curTargetState.worldY, curTargetState.sizePx, curTargetState.worldZ);

          let secProj: { u: number; v: number; inside: boolean; size: number } | null = null;
          if (secTargetState) {
            secProj = cameraRef.current.worldToViewport(secTargetState.worldX, secTargetState.worldY, secTargetState.sizePx, secTargetState.worldZ);
          }

          // 4. Render Synthetic Optical Frame to Canvas
          const canvas = canvasRef.current;
          let detResult: DetectionResult;

          if (canvas) {
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            if (ctx) {
              imageProcessorRef.current.renderOpticalFrame(
                ctx,
                curTargetState.isActive ? primaryProj : null,
                secProj,
                distConfig,
                { x: disturbances.jitterX, y: disturbances.jitterY }
              );

              // Inject sensor pixel noise
              const imgData = ctx.getImageData(0, 0, 640, 480);
              imageProcessorRef.current.applyNoiseToImageData(imgData, distConfig);
              ctx.putImageData(imgData, 0, 0);

              // Ground truth is passed ONLY for post-detection error evaluation
              const gtViewport: [number, number] | null = primaryProj.inside
                ? [primaryProj.u, primaryProj.v]
                : null;

              // Genuine Computer Vision detection (No ground truth utilized)
              detResult = imageProcessorRef.current.detectBeaconFromImageData(imgData, gtViewport, 95);
            } else {
              detResult = {
                detected: false,
                bbox: [0, 0, 0, 0],
                centroidX: 0,
                centroidY: 0,
                confidence: 0,
                processingTimeMs: 1.0,
                cameraCenterX: 320,
                cameraCenterY: 240,
                horizontalError: 0,
                verticalError: 0,
                euclideanError: 0,
                centroidingError: null,
              };
            }
          } else {
            detResult = {
              detected: false,
              bbox: [0, 0, 0, 0],
              centroidX: 0,
              centroidY: 0,
              confidence: 0,
              processingTimeMs: 1.0,
              cameraCenterX: 320,
              cameraCenterY: 240,
              horizontalError: 0,
              verticalError: 0,
              euclideanError: 0,
              centroidingError: null,
            };
          }

          // 5. Update Kalman Tracker & Re-acquisition State Machine
          const trackState = trackingEngineRef.current.update(detResult, dt, distConfig);

          // 6. Compute Control Output (Baseline or LumaTrace Predictive)
          const activeCtrl =
            config.controllerType === 'baseline' ? baselineCtrlRef.current : predictiveCtrlRef.current;
          const { panRate, tiltRate, saturated } = activeCtrl.computeControl(cameraRef.current, trackState, dt);
          trackState.controlSaturated = saturated;

          // 7. Update Virtual Camera Gimbal Orientation
          cameraRef.current.update(dt, panRate, tiltRate);

          // 8. Record Metrics
          metricsEvaluatorRef.current.recordFrame(
            targetRef.current.time,
            detResult.detected,
            detResult.euclideanError,
            detResult.centroidingError,
            detResult.processingTimeMs,
            trackState.reacquisitionTimeS
          );

          // Update React states for active view
          setCameraState(cameraRef.current.getState());
          setTargetState(curTargetState);
          setDetection(detResult);
          setTracking(trackState);

          setErrorHistory((prev) => [...prev.slice(-150), detResult.euclideanError]);
          setGroundTruthHistory([...targetRef.current.groundTruthHistory]);

          // Compute FPS every 500ms
          if (now - lastFpsUpdate >= 500) {
            const calculatedFps = (frameCounter * 1000.0) / (now - lastFpsUpdate);
            setLiveFps(calculatedFps);
            setFpsHistory((prev) => [...prev.slice(-80), calculatedFps]);
            setMetrics(metricsEvaluatorRef.current.computeMetrics());
            frameCounter = 0;
            lastFpsUpdate = now;
          }
        }
      }

      animId = requestAnimationFrame(simulationLoop);
    };

    animId = requestAnimationFrame(simulationLoop);
    return () => cancelAnimationFrame(animId);
  }, [isRunning, config, distConfig]);

  return (
    <div className="min-h-screen bg-[#0A0B10] text-[#E0E0E0] flex antialiased selection:bg-cyan-500 selection:text-white">
      {/* Geometric Balance Sidebar Rail (80px wide) */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Geometric Balance Top Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          trackingState={tracking.stateLabel}
          riskLevel={tracking.riskLevel}
          fps={liveFps}
          panDeg={cameraState.panDeg}
          tiltDeg={cameraState.tiltDeg}
          latencyMs={detection.processingTimeMs}
          errorPx={detection.euclideanError}
        />

        {/* Main View Router */}
        <main className="flex-1 overflow-y-auto bg-[#0A0B10]">
        {activeTab === 'dashboard' && (
          <DashboardView
            isRunning={isRunning}
            onToggleRunning={() => setIsRunning(!isRunning)}
            onReset={handleReset}
            onInduceLoss={handleInduceLoss}
            onManualNudge={handleManualNudge}
            config={config}
            onUpdateConfig={handleUpdateConfig}
            cameraState={cameraState}
            targetState={targetState}
            detection={detection}
            tracking={tracking}
            groundTruthHistory={groundTruthHistory}
            fps={liveFps}
            canvasRef={canvasRef}
          />
        )}

        {activeTab === 'simulation' && (
          <LiveSimulationView
            isRunning={isRunning}
            onToggleRunning={() => setIsRunning(!isRunning)}
            onReset={handleReset}
            config={config}
            onUpdateConfig={handleUpdateConfig}
            distConfig={distConfig}
            onUpdateDistConfig={handleUpdateDistConfig}
            cameraState={cameraState}
            targetState={targetState}
            detection={detection}
            tracking={tracking}
            fps={liveFps}
            canvasRef={canvasRef}
            errorHistory={errorHistory}
          />
        )}

        {activeTab === 'benchmark' && <Mp4BenchmarkView />}

        {activeTab === 'scenarios' && <ScenarioLabView />}

        {activeTab === 'ab_test' && <AbComparisonView />}

        {activeTab === 'analytics' && (
          <AnalyticsView
            metrics={metrics}
            errorHistory={errorHistory}
            fpsHistory={fpsHistory}
            groundTruthHistory={groundTruthHistory}
          />
        )}

        {activeTab === 'demo' && (
          <SihDemoView
            onApplyPreset={handleApplyPreset}
            onReset={handleReset}
            onToggleRunning={(r) => setIsRunning(r)}
            canvasRef={canvasRef}
            currentError={detection.euclideanError}
            currentFps={liveFps}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsView metrics={metrics} errorHistory={errorHistory} />
        )}

        {activeTab === 'config' && (
          <ConfigView
            config={config}
            onUpdateConfig={handleUpdateConfig}
            onResetToDefault={() => setConfig(DEFAULT_CONFIG)}
          />
        )}

        {activeTab === 'architecture' && <ArchitectureView />}
        {activeTab === 'guide' && <GuideView setActiveTab={setActiveTab} />}
      </main>
    </div>
  </div>
  );
}
