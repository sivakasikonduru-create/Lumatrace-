import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/components/DashboardView.tsx', 'utf-8');

const explainPanel = `
            {/* AI Explainability & Risk Panel */}
            <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-purple-400" />
                  <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono">
                    LumaTrace Explainability
                  </h3>
                </div>
                {tracking.failureCause && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-400 border border-rose-800">
                    CAUSE: {tracking.failureCause}
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-gray-500 uppercase block mb-1">Controller Reason</span>
                  <div className="text-gray-300">{tracking.riskReason}</div>
                </div>
                <div>
                  <span className="text-[10px] text-gray-500 uppercase block mb-1">Predicted FOV Loss</span>
                  <div className={\`font-bold \${tracking.predictedFovLoss === 'HIGH' ? 'text-rose-400' : tracking.predictedFovLoss === 'MEDIUM' ? 'text-amber-400' : 'text-emerald-400'}\`}>
                    {tracking.predictedFovLoss}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-gray-500 uppercase block mb-1">Control Saturation</span>
                  <div className={\`font-bold \${tracking.controlSaturated ? 'text-rose-400' : 'text-emerald-400'}\`}>
                    {tracking.controlSaturated ? 'SATURATED (MAX RATE)' : 'NOMINAL'}
                  </div>
                </div>
              </div>
            </div>
`;

content = content.replace(
  "{/* System Events Panel (Geometric Balance) */}",
  explainPanel + "\n          {/* System Events Panel (Geometric Balance) */}"
);

writeFileSync('src/components/DashboardView.tsx', content);
