import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/components/ReportsView.tsx', 'utf-8');

const saturationBlock = `
        {/* LumaTrace Control Metrics */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 mb-2 border-b border-[#1F2937] pb-3">
            <ShieldCheck className="w-4 h-4 text-purple-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono">
              LumaTrace Control Validation
            </h3>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-[#0A0B10] p-3 rounded-md border border-[#1F2937]">
              <span className="text-[11px] font-mono text-gray-400 uppercase">Control Saturation Events</span>
              <span className={\`text-sm font-bold font-mono \${metrics.controlSaturationEvents === 0 ? 'text-emerald-400' : 'text-rose-400'}\`}>
                {metrics.controlSaturationEvents ?? 0}
              </span>
            </div>
            <div className="flex justify-between items-center bg-[#0A0B10] p-3 rounded-md border border-[#1F2937]">
              <span className="text-[11px] font-mono text-gray-400 uppercase">Centroiding Error (Sub-pixel)</span>
              <span className="text-sm font-bold font-mono text-cyan-400">
                {(metrics.averageCentroidingErrorPx ?? 0).toFixed(2)} px
              </span>
            </div>
          </div>
        </div>
`;

content = content.replace(
  "{/* Final Results & Compliance Table */}",
  saturationBlock + "\n        {/* Final Results & Compliance Table */}"
);

writeFileSync('src/components/ReportsView.tsx', content);
