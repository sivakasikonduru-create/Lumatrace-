"""Simulation Coordinator for Virtual FSOC Coarse Tracking Alignment."""
from typing import Dict, Any, List, Optional
from config.config import SimulationConfig
from camera.camera import VirtualCamera
from target.target import BeaconTarget
from detection.detector import BeaconDetector
from tracking.tracker import LumaTraceTracker
from control.controller import BaselineReactiveController, LumaTracePredictiveController
from disturbance.disturbances import DisturbanceConfig, DisturbanceEngine
from analytics.metrics import PerformanceEvaluator, PerformanceMetrics

class FsocSimulation:
    """End-to-end discrete-time virtual FSOC tracking simulator."""
    
    def __init__(self, config: Optional[SimulationConfig] = None, dist_config: Optional[DisturbanceConfig] = None):
        self.config = config or SimulationConfig()
        self.dist_config = dist_config or DisturbanceConfig()
        
        self.camera = VirtualCamera(self.config)
        self.target = BeaconTarget(self.config)
        self.detector = BeaconDetector(self.config.camera_width, self.config.camera_height)
        self.tracker = LumaTraceTracker(self.config.camera_width, self.config.camera_height)
        
        if self.config.controller_type == "predictive":
            self.controller = LumaTracePredictiveController(self.config)
        else:
            self.controller = BaselineReactiveController(self.config)
            
        self.disturbance_engine = DisturbanceEngine(self.dist_config)
        self.evaluator = PerformanceEvaluator()
        
        self.current_time = 0.0
        self.frame_count = 0
        self.telemetry_history: List[Dict[str, Any]] = []

    def reset(self):
        self.camera.reset()
        self.target.reset()
        self.current_time = 0.0
        self.frame_count = 0
        self.telemetry_history.clear()
        self.evaluator = PerformanceEvaluator()

    def step(self, dt: float) -> Dict[str, Any]:
        """Advances simulation by time step dt (e.g. 1/30 s for 30 Hz)."""
        self.current_time += dt
        self.frame_count += 1
        
        # 1. Update ground-truth moving target in 2000x2000 virtual scene
        gt_target_state = self.target.update(dt)
        
        # 2. Compute camera jitter & platform disturbances
        j_dx, j_dy, p_dx, p_dy = self.disturbance_engine.compute_motion_offsets(dt)
        
        # Effective beacon position on camera sensor with disturbances
        eff_world_x = gt_target_state.world_x + p_dx
        eff_world_y = gt_target_state.world_y + p_dy
        
        # 3. Project into camera viewport
        u, v, inside = self.camera.world_to_viewport(eff_world_x, eff_world_y)
        u += j_dx
        v += j_dy
        
        # Ground-truth viewport coordinate (evaluation ONLY)
        gt_viewport_x, gt_viewport_y, _ = self.camera.world_to_viewport(gt_target_state.world_x, gt_target_state.world_y)
        
        # 4. Synthesize camera frame pixel intensity array (low-res grid or bounding ROI for performance)
        # For simulation step, we simulate a frame with the beacon spot
        w, h = self.camera.resolution_w, self.camera.resolution_h
        frame_grid = self._render_synthetic_frame(w, h, u, v, gt_target_state.size_px if inside else None)
        
        # 5. Apply atmospheric & noise disturbances
        disturbed_frame = self.disturbance_engine.apply_disturbances_to_frame(frame_grid)
        
        # 6. Beacon detection & centroiding (NO ground truth passed for detection)
        detection = self.detector.process_frame(disturbed_frame, ground_truth_viewport=(gt_viewport_x, gt_viewport_y))
        
        # 7. Update tracker
        tracking_state = self.tracker.update(detection, dt)
        
        # 8. Controller closed-loop command -> camera pan/tilt
        pan_rate, tilt_rate = self.controller.compute_control(self.camera, tracking_state, dt)
        self.camera.command_velocity(pan_rate, tilt_rate, dt)
        
        # 9. Performance evaluation recording
        self.evaluator.record_frame(
            timestamp=self.current_time,
            detected=detection.detected,
            tracking_error_px=detection.euclidean_error,
            centroiding_error_px=detection.centroiding_error,
            processing_time_ms=detection.processing_time_ms,
            reacquisition_event_time=tracking_state.reacquisition_time_s
        )
        
        telemetry = {
            "frame": self.frame_count,
            "timestamp": round(self.current_time, 3),
            "detected": detection.detected,
            "tracking_error": round(detection.euclidean_error, 2),
            "centroiding_error": round(detection.centroiding_error, 2) if detection.centroiding_error else None,
            "confidence": round(detection.confidence, 3),
            "pan_deg": round(self.camera.pan_deg, 3),
            "tilt_deg": round(self.camera.tilt_deg, 3),
            "pan_rate": round(pan_rate, 2),
            "tilt_rate": round(tilt_rate, 2),
            "target_world_x": round(gt_target_state.world_x, 1),
            "target_world_y": round(gt_target_state.world_y, 1),
            "state": tracking_state.state_label,
            "risk": tracking_state.risk_level,
            "risk_reason": tracking_state.risk_reason
        }
        self.telemetry_history.append(telemetry)
        return telemetry

    def _render_synthetic_frame(self, width: int, height: int, beacon_x: float, beacon_y: float, beacon_size: Optional[int]) -> List[List[float]]:
        """Synthesizes optical frame. To maintain high speed in Python test suite, creates sample frame."""
        frame = [[10.0 for _ in range(min(120, width))] for _ in range(min(80, height))]
        scale_x = len(frame[0]) / float(width)
        scale_y = len(frame) / float(height)
        
        if beacon_size is not None and 0 <= beacon_x < width and 0 <= beacon_y < height:
            bx = int(beacon_x * scale_x)
            by = int(beacon_y * scale_y)
            half = max(1, int((beacon_size / 2.0) * scale_x))
            
            for dy in range(-half, half + 1):
                yy = by + dy
                if 0 <= yy < len(frame):
                    for dx in range(-half, half + 1):
                        xx = bx + dx
                        if 0 <= xx < len(frame[0]):
                            frame[yy][xx] = 230.0  # Bright beacon spot
        return frame

    def get_metrics(self) -> PerformanceMetrics:
        return self.evaluator.compute_metrics()
