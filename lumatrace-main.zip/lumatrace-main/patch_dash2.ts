import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/components/DashboardView.tsx', 'utf-8');

const droneUI = `
            {/* Drone 3D Status */}
            {config.simulationMode === 'drone_to_drone' && (
              <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                  <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono">
                    Drone-to-Drone Telemetry (3D)
                  </h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-[10px] text-gray-500 uppercase font-mono block mb-1">Drone A (Target)</span>
                    <div className="text-xs text-cyan-400 font-mono">
                      X: {targetState.worldX.toFixed(1)} <br/>
                      Y: {targetState.worldY.toFixed(1)} <br/>
                      Z: {targetState.worldZ?.toFixed(1) || 0}
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-500 uppercase font-mono block mb-1">Drone B (Camera)</span>
                    <div className="text-xs text-blue-400 font-mono">
                      X: {cameraState.worldX?.toFixed(1) || 0} <br/>
                      Y: {cameraState.worldY?.toFixed(1) || 0} <br/>
                      Z: {cameraState.worldZ?.toFixed(1) || 0}
                    </div>
                  </div>
                </div>
              </div>
            )}
`;

content = content.replace(
  "{/* Target Ground Truth State */}",
  droneUI + "\n            {/* Target Ground Truth State */}"
);

writeFileSync('src/components/DashboardView.tsx', content);
