import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/types/fsoc.ts', 'utf-8');

// Add controlSaturated to TrackingState
content = content.replace(
  "failureCause: string | null;",
  "failureCause: string | null;\n  controlSaturated: boolean;"
);

// Add it to PerformanceMetrics
content = content.replace(
  "sihCompliance: {",
  "controlSaturationEvents: number;\n  sihCompliance: {"
);

writeFileSync('src/types/fsoc.ts', content);
