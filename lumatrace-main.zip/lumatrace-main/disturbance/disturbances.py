"""Disturbances & Noise Engine strictly following SIH requirements."""
from dataclasses import dataclass
import random
import math
from typing import List, Tuple

@dataclass
class DisturbanceConfig:
    """Configuration for environmental and sensor disturbances."""
    # Noise types
    noise_type: str = "none"  # "none", "gaussian", "salt_pepper", "poisson"
    noise_intensity: float = 0.05  # 0.0 to 1.0
    gaussian_sigma: float = 12.0   # up to 20.0
    
    # Camera jitter (±20 pixels/frame max)
    jitter_enabled: bool = False
    jitter_amplitude_px: float = 8.0  # max 20.0
    
    # Atmospheric condition
    atmospheric_condition: str = "clear"  # "clear", "haze", "fog", "rain", "low_light"
    contrast_reduction: float = 0.0  # 0.0 to 0.8
    brightness_reduction: float = 0.0  # 0.0 to 0.8
    
    # Platform motion (±20 pixels/frame max)
    platform_motion_enabled: bool = False
    platform_motion_type: str = "linear"  # "linear", "circular", "random", "figure_8"
    platform_amplitude_px: float = 10.0  # max 20.0

class DisturbanceEngine:
    """Applies realistic optical, sensor, and platform disturbances before detection."""
    
    def __init__(self, config: DisturbanceConfig):
        self.config = config
        self.time = 0.0

    def compute_motion_offsets(self, dt: float) -> Tuple[float, float, float, float]:
        """Calculates (jitter_dx, jitter_dy, platform_dx, platform_dy) in pixels.
        Returns clamped offsets respecting SIH ±20 px bounds.
        """
        self.time += dt
        t = self.time
        
        # Camera Jitter (high-frequency vibration)
        j_dx = 0.0
        j_dy = 0.0
        if self.config.jitter_enabled:
            amp = min(20.0, self.config.jitter_amplitude_px)
            j_dx = (random.random() - 0.5) * 2.0 * amp
            j_dy = (random.random() - 0.5) * 2.0 * amp
            
        # Platform Motion (low-frequency vessel/vehicle drift)
        p_dx = 0.0
        p_dy = 0.0
        if self.config.platform_motion_enabled:
            p_amp = min(20.0, self.config.platform_amplitude_px)
            mode = self.config.platform_motion_type
            if mode == "linear":
                p_dx = p_amp * math.sin(t * 1.5)
                p_dy = p_amp * 0.5 * math.cos(t * 1.5)
            elif mode == "circular":
                p_dx = p_amp * math.cos(t * 2.0)
                p_dy = p_amp * math.sin(t * 2.0)
            elif mode == "figure_8":
                p_dx = p_amp * math.sin(t * 1.8)
                p_dy = (p_amp * 0.6) * math.sin(2 * t * 1.8)
            else:  # random
                p_dx = (random.random() - 0.5) * 2.0 * p_amp
                p_dy = (random.random() - 0.5) * 2.0 * p_amp
                
        return (j_dx, j_dy, p_dx, p_dy)

    def apply_disturbances_to_frame(self, frame: List[List[float]]) -> List[List[float]]:
        """Modifies 2D intensity frame with atmospheric attenuation and image noise."""
        h = len(frame)
        w = len(frame[0]) if h > 0 else 0
        if h == 0 or w == 0:
            return frame

        # Determine atmospheric attenuation parameters
        contrast_scale = 1.0 - self.config.contrast_reduction
        brightness_offset = -self.config.brightness_reduction * 100.0
        
        cond = self.config.atmospheric_condition
        fog_scatter = 0.0
        if cond == "haze":
            contrast_scale *= 0.75
            fog_scatter = 25.0
        elif cond == "fog":
            contrast_scale *= 0.45
            fog_scatter = 65.0
        elif cond == "rain":
            contrast_scale *= 0.60
            fog_scatter = 35.0
        elif cond == "low_light":
            contrast_scale *= 0.50
            brightness_offset -= 60.0

        out_frame: List[List[float]] = []
        noise_type = self.config.noise_type
        intensity = self.config.noise_intensity
        sigma = min(20.0, self.config.gaussian_sigma)

        for y in range(h):
            row = frame[y]
            new_row = [0.0] * w
            for x in range(w):
                val = row[x]
                # 1. Atmospheric modification
                val = (val * contrast_scale) + fog_scatter + brightness_offset
                
                # 2. Additive Image Noise
                if noise_type == "gaussian":
                    # Box-Muller approx or random.gauss
                    noise = random.gauss(0.0, sigma)
                    val += noise
                elif noise_type == "salt_pepper":
                    r = random.random()
                    if r < intensity * 0.5:
                        val = 0.0  # pepper
                    elif r < intensity:
                        val = 255.0  # salt
                elif noise_type == "poisson":
                    # Approx Poisson photon shot noise: variance proportional to signal
                    lam = max(1.0, val * 0.5)
                    noise = (random.random() - 0.5) * 2.0 * math.sqrt(lam) * (intensity * 4.0)
                    val += noise
                    
                # Clamp to 0..255
                new_row[x] = max(0.0, min(255.0, val))
            out_frame.append(new_row)
            
        return out_frame
