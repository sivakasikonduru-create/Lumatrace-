import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/core/ScenarioDefinitions.ts', 'utf-8');

const additionalScenarios = `  {
    id: 'd2d-13',
    name: 'D2D-13: Moving Obstacle / Partial Occlusion',
    description: 'Temporary partial LOS obstruction via moving physical obstacle.',
    category: 'stress',
    durationSeconds: 7,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'straight_line', targetSpeedPxS: 50 },
    disturbanceOverrides: { losObstructionEnabled: true, losObstructionSeverity: 'partial' }
  },
  {
    id: 'd2d-14',
    name: 'D2D-14: Complete Occlusion / Fog',
    description: 'Complete LOS block requiring autonomous Kalman predictive coasting.',
    category: 'stress',
    durationSeconds: 8,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'figure_8', targetSpeedPxS: 70 },
    disturbanceOverrides: { atmosphericCondition: 'fog', losObstructionEnabled: true, losObstructionSeverity: 'full' }
  },
  {
    id: 'd2d-15',
    name: 'D2D-15: Camera Rate Saturation',
    description: 'Target pushes camera past its angular rate limits.',
    category: 'stress',
    durationSeconds: 6,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'circular', targetSpeedPxS: 180, maxPanSpeedDegS: 1.5, maxTiltSpeedDegS: 1.5 },
    disturbanceOverrides: { atmosphericCondition: 'clear' }
  },
  {
    id: 'd2d-16',
    name: 'D2D-16: Combined Environmental Stress Test',
    description: 'Turbulence, partial occlusion, and extreme platform jitter.',
    category: 'stress',
    durationSeconds: 10,
    configOverrides: { simulationMode: 'drone_to_drone', targetMotionMode: 'random', targetSpeedPxS: 95 },
    disturbanceOverrides: { atmosphericCondition: 'turbulence', jitterEnabled: true, jitterAmplitudePx: 16, losObstructionEnabled: true, losObstructionSeverity: 'partial' }
  },`;

content = content.replace("];", "]," + additionalScenarios.substring(0, additionalScenarios.length - 1) + "\n];");
content = content.replace(/\],\s*\{\s*id:\s*'d2d-13'/m, ", { id: 'd2d-13'");

writeFileSync('src/core/ScenarioDefinitions.ts', content);
