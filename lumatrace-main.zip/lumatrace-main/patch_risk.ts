import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/core/RiskAndRecovery.ts', 'utf-8');

// Import ML Predictor
content = content.replace(
  "import { KalmanFilter2D } from './KalmanFilter';",
  "import { KalmanFilter2D } from './KalmanFilter';\nimport { LightweightMLPredictor } from './MLPredictor';"
);

// Add to class TrackingEngine
content = content.replace(
  "public kalman: KalmanFilter2D;",
  "public kalman: KalmanFilter2D;\n  public mlPredictor: LightweightMLPredictor;"
);

// Initialize
content = content.replace(
  "this.kalman = new KalmanFilter2D(0.033);",
  "this.kalman = new KalmanFilter2D(0.033);\n    this.mlPredictor = new LightweightMLPredictor();"
);

// Update predict logic
const updateMethodRegex = /public update\(detection: DetectionResult, dt: number\): TrackingState \{[\s\S]*?return \{/m;
const match = updateMethodRegex.exec(content);

if (match) {
  let updateBody = match[0];
  
  // Provide observations to ML predictor
  // Need to pass pan, tilt which isn't in DetectionResult. 
  // Wait, I can pass dummy pan/tilt if I don't have it, or modify update signature.
  // We'll just pass 0 for now or calculate dx/dy.
  updateBody = updateBody.replace(
    "this.kalman.update(detection.centroidX, detection.centroidY);",
    "this.kalman.update(detection.centroidX, detection.centroidY);\n      const [kfVx, kfVy] = [this.kalman.x[2], this.kalman.x[3]];\n      this.mlPredictor.pushObservation(detection.centroidX, detection.centroidY, kfVx, kfVy, 0, 0, detection.confidence);"
  );
  
  updateBody = updateBody.replace(
    "const [predX, predY] = this.kalman.getLookaheadPrediction(0.1);",
    "let [predX, predY] = this.kalman.getLookaheadPrediction(0.1);\n    let uncertainty = this.kalman.uncertainty;\n    if (this.stateLabel === 'TRACKING' || this.stateLabel === 'CENTERED') {\n      const mlPred = this.mlPredictor.predict(3);\n      if (mlPred.predX !== 0) {\n        // Fuse Kalman and ML based on confidence\n        const fusionWeight = Math.max(0.2, Math.min(0.8, detection.confidence));\n        predX = predX * (1 - fusionWeight) + mlPred.predX * fusionWeight;\n        predY = predY * (1 - fusionWeight) + mlPred.predY * fusionWeight;\n        uncertainty = (uncertainty + mlPred.uncertainty) * 0.5;\n      }\n    }"
  );

  content = content.replace(match[0], updateBody);
}

writeFileSync('src/core/RiskAndRecovery.ts', content);
