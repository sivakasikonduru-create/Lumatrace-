import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/core/ScenarioDefinitions.ts', 'utf-8');
content = content.replace("],\n  {\n    id: 'd2d-01'", ",\n  {\n    id: 'd2d-01'");
writeFileSync('src/core/ScenarioDefinitions.ts', content);
