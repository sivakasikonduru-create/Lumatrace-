"""Automated Performance Reporting and SIH Compliance Audit."""
import json
import csv
import io
from typing import List, Dict, Any
from analytics.metrics import PerformanceMetrics

class PerformanceReporter:
    """Generates verifiable JSON, CSV, and formatted markdown audit reports."""
    
    @staticmethod
    def to_json(metrics: PerformanceMetrics) -> str:
        """Serializes metrics to formatted JSON string."""
        return json.dumps(metrics.__dict__, indent=2)

    @staticmethod
    def to_csv(log_entries: List[Dict[str, Any]]) -> str:
        """Exports frame-by-frame telemetry log to CSV format."""
        if not log_entries:
            return "frame,timestamp,detected,tracking_error,centroiding_error,fps\n"
            
        output = io.StringIO()
        headers = list(log_entries[0].keys())
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()
        for entry in log_entries:
            writer.writerow(entry)
        return output.getvalue()

    @staticmethod
    def generate_compliance_markdown(metrics: PerformanceMetrics, scenario_name: str = "SIH Standard Run") -> str:
        """Generates clear audit summary with SIH target compliance."""
        lines = [
            f"# LumaTrace FSOC Coarse Alignment Performance Report",
            f"**Scenario:** {scenario_name}",
            f"**Duration:** {metrics.simulation_duration_s}s | **Total Frames:** {metrics.total_frames}",
            "",
            "## SIH Problem Statement 4 Compliance Matrix",
            "| Metric | SIH Target | Measured Value | Compliance Status |",
            "| :--- | :--- | :--- | :--- |"
        ]
        
        for k, v in metrics.sih_compliance.items():
            name = k.replace("_", " ").title()
            status_icon = "PASS" if v["status"] == "PASS" else "NEEDS IMPROVEMENT"
            lines.append(f"| {name} | {v['target']} | {v['measured']} | {status_icon} |")
            
        lines.extend([
            "",
            "## Tracking Accuracy & Stability",
            f"- **Average Tracking Error:** {metrics.average_tracking_error_px} px",
            f"- **RMSE:** {metrics.rmse_px} px",
            f"- **Max Tracking Error:** {metrics.max_tracking_error_px} px",
            f"- **Lock Retention Rate:** {metrics.lock_retention_rate} %",
            f"- **Target Loss Rate:** {metrics.target_loss_percentage} %",
            f"- **Average Centroiding Error:** {metrics.average_centroiding_error_px} px",
            "",
            "## Compute Performance",
            f"- **Average Processing Speed:** {metrics.avg_fps} FPS (Min: {metrics.min_fps} FPS)",
            f"- **Average Compute Latency:** {metrics.avg_processing_time_ms} ms/frame",
            ""
        ])
        
        return "\n".join(lines)
