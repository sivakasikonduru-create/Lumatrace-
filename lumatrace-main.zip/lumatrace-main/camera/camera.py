"""Virtual Camera Module for Mobile FSOC coarse alignment tracking."""
from dataclasses import dataclass
from typing import Tuple, Optional
from config.config import SimulationConfig

@dataclass
class CameraState:
    """State model for virtual camera."""
    pan_deg: float = 0.0
    tilt_deg: float = 0.0
    pan_velocity_deg_s: float = 0.0
    tilt_velocity_deg_s: float = 0.0
    viewport_center_x: float = 1000.0  # In screen space (2000x2000)
    viewport_center_y: float = 1000.0
    resolution_w: int = 640
    resolution_h: int = 480
    fov_h_deg: float = 4.0
    fov_v_deg: float = 3.0
    optical_center_x: float = 320.0
    optical_center_y: float = 240.0

class VirtualCamera:
    """Virtual camera viewport controller simulating a motorized gimbal PTZ head."""
    
    def __init__(self, config: Optional[SimulationConfig] = None):
        self.config = config or SimulationConfig()
        self.pan_deg = 0.0
        self.tilt_deg = 0.0
        self.pan_velocity = 0.0
        self.tilt_velocity = 0.0
        self.initial_pos = self.config.initial_camera_pos
        self.resolution_w = self.config.camera_width
        self.resolution_h = self.config.camera_height
        self.fov_h_deg = self.config.camera_fov_h_deg
        self.fov_v_deg = self.config.camera_fov_v_deg
        self.max_pan_speed = self.config.max_pan_speed_deg_s
        self.max_tilt_speed = self.config.max_tilt_speed_deg_s
        self.update_rate_hz = self.config.camera_update_rate_hz

    @property
    def px_per_deg_h(self) -> float:
        return self.resolution_w / self.fov_h_deg

    @property
    def px_per_deg_v(self) -> float:
        return self.resolution_h / self.fov_v_deg

    @property
    def viewport_center(self) -> Tuple[float, float]:
        """Calculates current viewport optical center in world 2000x2000 screen coordinates."""
        # Positive pan moves camera right (world center moves right)
        cx = self.initial_pos[0] + self.pan_deg * self.px_per_deg_h
        # Positive tilt moves camera down (world center moves down)
        cy = self.initial_pos[1] + self.tilt_deg * self.px_per_deg_v
        return (cx, cy)

    def world_to_viewport(self, world_x: float, world_y: float) -> Tuple[float, float, bool]:
        """Projects world coordinate into camera viewport coordinate space.
        Returns:
            (viewport_x, viewport_y, is_inside_fov)
        """
        cx, cy = self.viewport_center
        # Relative offset in world pixels
        dx = world_x - cx
        dy = world_y - cy
        
        # Camera optical center in pixels
        u = (self.resolution_w / 2.0) + dx
        v = (self.resolution_h / 2.0) + dy
        
        inside = (0 <= u <= self.resolution_w) and (0 <= v <= self.resolution_h)
        return (u, v, inside)

    def command_velocity(self, pan_rate_deg_s: float, tilt_rate_deg_s: float, dt: float):
        """Commands pan/tilt rates clamped to maximum SIH speeds (5 deg/s default)."""
        clamped_pan_rate = max(-self.max_pan_speed, min(self.max_pan_speed, pan_rate_deg_s))
        clamped_tilt_rate = max(-self.max_tilt_speed, min(self.max_tilt_speed, tilt_rate_deg_s))
        
        self.pan_velocity = clamped_pan_rate
        self.tilt_velocity = clamped_tilt_rate
        
        self.pan_deg += clamped_pan_rate * dt
        self.tilt_deg += clamped_tilt_rate * dt

    def manual_nudge(self, d_pan_deg: float, d_tilt_deg: float):
        """Manual jog/nudge for user control."""
        self.pan_deg += d_pan_deg
        self.tilt_deg += d_tilt_deg

    def reset(self):
        """Resets camera to screen center."""
        self.pan_deg = 0.0
        self.tilt_deg = 0.0
        self.pan_velocity = 0.0
        self.tilt_velocity = 0.0

    def get_state(self) -> CameraState:
        cx, cy = self.viewport_center
        return CameraState(
            pan_deg=self.pan_deg,
            tilt_deg=self.tilt_deg,
            pan_velocity_deg_s=self.pan_velocity,
            tilt_velocity_deg_s=self.tilt_velocity,
            viewport_center_x=cx,
            viewport_center_y=cy,
            resolution_w=self.resolution_w,
            resolution_h=self.resolution_h,
            fov_h_deg=self.fov_h_deg,
            fov_v_deg=self.fov_v_deg,
            optical_center_x=self.resolution_w / 2.0,
            optical_center_y=self.resolution_h / 2.0
        )
