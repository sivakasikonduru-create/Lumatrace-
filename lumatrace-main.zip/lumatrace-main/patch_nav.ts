import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/components/Navbar.tsx', 'utf-8');

content = content.replace(
  "import {\n  Activity,",
  "import {\n  Activity,\n  HelpCircle,"
);

content = content.replace(
  "| 'config'\n  | 'architecture';",
  "| 'config'\n  | 'architecture'\n  | 'guide';"
);

content = content.replace(
  "{ id: 'architecture', label: '6-Stage Architecture', shortLabel: 'Arch', icon: <Cpu className=\"w-5 h-5\" /> },",
  "{ id: 'architecture', label: '6-Stage Architecture', shortLabel: 'Arch', icon: <Cpu className=\"w-5 h-5\" /> },\n  { id: 'guide', label: 'User Guide & Walkthrough', shortLabel: 'Guide', icon: <HelpCircle className=\"w-5 h-5 text-emerald-400\" /> },"
);

writeFileSync('src/components/Navbar.tsx', content);
