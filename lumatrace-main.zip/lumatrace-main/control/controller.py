"""Tracking Controllers: Baseline Reactive vs LumaTrace Predictive."""
from typing import Tuple
from config.config import SimulationConfig
from camera.camera import VirtualCamera
from tracking.tracker import TrackingState

class BaselineReactiveController:
    """Standard closed-loop proportional reactive controller."""
    
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.kp_pan = 0.8
        self.kp_tilt = 0.8
        self.max_pan_speed = config.max_pan_speed_deg_s
        self.max_tilt_speed = config.max_tilt_speed_deg_s

    def compute_control(self, camera: VirtualCamera, tracking_state: TrackingState, dt: float) -> Tuple[float, float]:
        """Computes pan and tilt angular velocities (deg/s).
        Returns:
            (pan_rate_deg_s, tilt_rate_deg_s)
        """
        # If target lost, hold or zero out
        if tracking_state.state_label == "LOST":
            return (0.0, 0.0)
            
        # Current pixel offset from optical center
        dx = tracking_state.current_x - (camera.resolution_w / 2.0)
        dy = tracking_state.current_y - (camera.resolution_h / 2.0)
        
        # Convert pixel error to angular error (degrees)
        err_pan_deg = dx / camera.px_per_deg_h
        err_tilt_deg = dy / camera.px_per_deg_v
        
        # Proportional rate command
        pan_rate = self.kp_pan * err_pan_deg * 3.0
        tilt_rate = self.kp_tilt * err_tilt_deg * 3.0
        
        # Clamp to max speeds
        pan_rate = max(-self.max_pan_speed, min(self.max_pan_speed, pan_rate))
        tilt_rate = max(-self.max_tilt_speed, min(self.max_tilt_speed, tilt_rate))
        
        return (pan_rate, tilt_rate)

class LumaTracePredictiveController:
    """Kalman-assisted predictive controller with feedforward velocity compensation and autonomous re-acquisition."""
    
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.kp_pan = 1.0
        self.kp_tilt = 1.0
        self.k_ff = 0.8  # Velocity feedforward gain
        self.max_pan_speed = config.max_pan_speed_deg_s
        self.max_tilt_speed = config.max_tilt_speed_deg_s
        self.search_angle = 0.0

    def compute_control(self, camera: VirtualCamera, tracking_state: TrackingState, dt: float) -> Tuple[float, float]:
        # Handle autonomous search when lost
        if tracking_state.state_label in ("TARGET_LOST", "PREDICTIVE_SEARCH"):
            # Move along last known velocity trajectory to catch up
            pan_feedforward = (tracking_state.velocity_x / camera.px_per_deg_h) * 1.0
            tilt_feedforward = (tracking_state.velocity_y / camera.px_per_deg_v) * 1.0
            
            pan_rate = max(-self.max_pan_speed, min(self.max_pan_speed, pan_feedforward))
            tilt_rate = max(-self.max_tilt_speed, min(self.max_tilt_speed, tilt_feedforward))
            return (pan_rate, tilt_rate)
            
        elif tracking_state.state_label == "LOST":
            # Expanding spiral search pattern around last position
            self.search_angle += 3.0 * dt
            search_pan = self.max_pan_speed * 0.7 * (self.search_angle % 1.0 - 0.5) * 2.0
            search_tilt = self.max_tilt_speed * 0.7 * (self.search_angle * 0.5 % 1.0 - 0.5) * 2.0
            return (search_pan, search_tilt)

        # Predictive tracking: compute error relative to PREDICTED lookahead position
        dx = tracking_state.predicted_x - (camera.resolution_w / 2.0)
        dy = tracking_state.predicted_y - (camera.resolution_h / 2.0)
        
        err_pan_deg = dx / camera.px_per_deg_h
        err_tilt_deg = dy / camera.px_per_deg_v
        
        # Velocity feedforward in deg/s
        ff_pan_deg_s = (tracking_state.velocity_x / camera.px_per_deg_h) * self.k_ff
        ff_tilt_deg_s = (tracking_state.velocity_y / camera.px_per_deg_v) * self.k_ff
        
        pan_rate = (self.kp_pan * err_pan_deg * 3.2) + ff_pan_deg_s
        tilt_rate = (self.kp_tilt * err_tilt_deg * 3.2) + ff_tilt_deg_s
        
        # Strict SIH clamping
        pan_rate = max(-self.max_pan_speed, min(self.max_pan_speed, pan_rate))
        tilt_rate = max(-self.max_tilt_speed, min(self.max_tilt_speed, tilt_rate))
        
        return (pan_rate, tilt_rate)
