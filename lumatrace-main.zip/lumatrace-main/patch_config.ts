import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/components/ConfigView.tsx', 'utf-8');

const newSection = `
        {/* Section 3: Simulation Mode */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4 md:col-span-2">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-widest border-b border-[#1F2937] pb-3">
            Simulation Mode Selection
          </h3>
          <div className="flex gap-4">
            <button
              onClick={() => onUpdateConfig({ simulationMode: 'standard' })}
              className={\`flex-1 py-2 px-4 rounded text-xs font-bold uppercase transition \${config.simulationMode === 'standard' ? 'bg-cyan-600 text-white' : 'bg-[#1F2937] text-gray-400 hover:bg-[#283548]'}\`}
            >
              Standard 2D FSOC
            </button>
            <button
              onClick={() => onUpdateConfig({ simulationMode: 'drone_to_drone' })}
              className={\`flex-1 py-2 px-4 rounded text-xs font-bold uppercase transition \${config.simulationMode === 'drone_to_drone' ? 'bg-cyan-600 text-white' : 'bg-[#1F2937] text-gray-400 hover:bg-[#283548]'}\`}
            >
              Drone-to-Drone 3D FSOC
            </button>
          </div>
        </div>
`;

content = content.replace(
  "      {/* Parameter Cards Grid */}\n      <div className=\"grid grid-cols-1 md:grid-cols-2 gap-6\">",
  "      {/* Parameter Cards Grid */}\n      <div className=\"grid grid-cols-1 md:grid-cols-2 gap-6\">\n" + newSection
);

writeFileSync('src/components/ConfigView.tsx', content);
