import { readFileSync, writeFileSync } from 'fs';

let navbar = readFileSync('src/components/Navbar.tsx', 'utf-8');
navbar = navbar.replace(
  "{ id: 'guide', label: 'User Guide & Walkthrough', shortLabel: 'Guide', icon: <HelpCircle className=\"w-5 h-5 text-emerald-400\" /> },\n  { id: 'guide', label: 'User Guide & Walkthrough', shortLabel: 'Guide', icon: <HelpCircle className=\"w-5 h-5 text-emerald-400\" /> },",
  "{ id: 'guide', label: 'User Guide & Walkthrough', shortLabel: 'Guide', icon: <HelpCircle className=\"w-5 h-5 text-emerald-400\" /> },"
);
writeFileSync('src/components/Navbar.tsx', navbar);

let guide = readFileSync('src/components/GuideView.tsx', 'utf-8');
guide = guide.replace(
  "ArrowRight, Navigation",
  "ArrowRight, Navigation, Film"
);
writeFileSync('src/components/GuideView.tsx', guide);
