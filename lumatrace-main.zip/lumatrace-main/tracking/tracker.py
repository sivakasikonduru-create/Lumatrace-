"""LumaTrace Tracking Engine with Autonomous State Transitions and Re-acquisition."""
from dataclasses import dataclass
from typing import Optional, Tuple
from detection.detector import DetectionResult
from tracking.kalman import KalmanFilter2D

@dataclass
class TrackingState:
    """State model for tracking pipeline."""
    state_label: str  # SEARCHING, ACQUIRING, TRACKING, CENTERED, LOST, PREDICTIVE_SEARCH, RE_ACQUIRING, RE_ACQUIRED
    current_x: float
    current_y: float
    predicted_x: float
    predicted_y: float
    velocity_x: float
    velocity_y: float
    uncertainty: float
    confidence: float
    consecutive_hits: int
    consecutive_misses: int
    reacquisition_time_s: float
    risk_level: str  # SAFE, WARNING, HIGH_RISK, LOST
    risk_reason: str

class LumaTraceTracker:
    """Combines Kalman filtering, loss detection, predictive search, and tracking risk analysis."""
    
    def __init__(self, camera_w: int = 640, camera_h: int = 480):
        self.camera_w = camera_w
        self.camera_h = camera_h
        self.center_x = camera_w / 2.0
        self.center_y = camera_h / 2.0
        
        self.kalman = KalmanFilter2D(dt=0.033)
        self.state_label = "SEARCHING"
        self.consecutive_hits = 0
        self.consecutive_misses = 0
        self.loss_start_time = 0.0
        self.current_time = 0.0
        self.reacquisition_duration = 0.0
        
        self.last_valid_x = self.center_x
        self.last_valid_y = self.center_y
        self.last_valid_vx = 0.0
        self.last_valid_vy = 0.0

    def update(self, detection: DetectionResult, dt: float) -> TrackingState:
        self.current_time += dt
        
        # 1. State machine propagation
        if detection.detected:
            self.consecutive_hits += 1
            
            if self.consecutive_misses > 0:
                # Target was previously lost and is now re-acquired!
                self.reacquisition_duration = self.current_time - self.loss_start_time
                self.state_label = "RE_ACQUIRED"
                self.consecutive_misses = 0
            elif self.consecutive_hits >= 3:
                # If error is <= 10 pixels, consider CENTERED; otherwise TRACKING
                if detection.euclidean_error <= 10.0:
                    self.state_label = "CENTERED"
                else:
                    self.state_label = "TRACKING"
            else:
                self.state_label = "ACQUIRING"

            # Update Kalman filter
            self.kalman.predict(dt)
            self.kalman.update(detection.centroid_x, detection.centroid_y)
            
            self.last_valid_x = detection.centroid_x
            self.last_valid_y = detection.centroid_y
            self.last_valid_vx = self.kalman.x[2]
            self.last_valid_vy = self.kalman.x[3]
            
        else:
            # Target missed this frame
            self.consecutive_misses += 1
            self.consecutive_hits = 0
            
            if self.consecutive_misses == 1:
                self.loss_start_time = self.current_time
                self.state_label = "TARGET_LOST"
            elif self.consecutive_misses < 10:
                self.state_label = "PREDICTIVE_SEARCH"
            else:
                self.state_label = "LOST"
                
            # Extrapolate Kalman prediction without measurement
            self.kalman.predict(dt)

        # 2. Extract position, velocity, and lookahead prediction
        kf_x, kf_y, kf_vx, kf_vy = self.kalman.x
        pred_x, pred_y = self.kalman.get_lookahead_prediction(lookahead_s=0.1)  # 100ms lookahead
        
        # 3. Phase 9: Link-Risk / Tracking-Risk Analysis
        risk_level, risk_reason = self._assess_risk(detection, pred_x, pred_y, kf_vx, kf_vy)

        return TrackingState(
            state_label=self.state_label,
            current_x=kf_x if detection.detected else pred_x,
            current_y=kf_y if detection.detected else pred_y,
            predicted_x=pred_x,
            predicted_y=pred_y,
            velocity_x=kf_vx,
            velocity_y=kf_vy,
            uncertainty=self.kalman.uncertainty,
            confidence=detection.confidence if detection.detected else 0.0,
            consecutive_hits=self.consecutive_hits,
            consecutive_misses=self.consecutive_misses,
            reacquisition_time_s=self.reacquisition_duration if self.state_label == "RE_ACQUIRED" else 0.0,
            risk_level=risk_level,
            risk_reason=risk_reason
        )

    def _assess_risk(self, detection: DetectionResult, pred_x: float, pred_y: float, vx: float, vy: float) -> Tuple[str, str]:
        """Calculates tracking risk strictly from optical coarse alignment metrics."""
        if not detection.detected:
            return ("LOST", "Beacon optical loss detected; entering autonomous search")
            
        # Distance from FOV boundary
        margin_x = min(detection.centroid_x, self.camera_w - detection.centroid_x)
        margin_y = min(detection.centroid_y, self.camera_h - detection.centroid_y)
        min_margin = min(margin_x, margin_y)
        
        speed = (vx ** 2 + vy ** 2) ** 0.5
        
        if min_margin < 30.0:
            return ("HIGH_RISK", f"Beacon approaching FOV boundary (margin: {min_margin:.1f}px)")
        elif detection.confidence < 0.35:
            return ("HIGH_RISK", f"Detection confidence low ({detection.confidence*100:.1f}%) due to noise/attenuation")
        elif speed > 150.0:
            return ("WARNING", f"Target velocity ({speed:.1f}px/s) exceeds optimal reactive range")
        elif detection.euclidean_error > 80.0:
            return ("WARNING", f"Tracking error high ({detection.euclidean_error:.1f}px)")
        else:
            return ("SAFE", "Coarse alignment locked; tracking nominal")
