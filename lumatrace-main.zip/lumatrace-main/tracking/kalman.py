"""2D Kalman Filter for Beacon Motion Estimation and Lookahead Prediction."""
from typing import Tuple, Optional
import math

class KalmanFilter2D:
    """Standard Discrete Kalman Filter estimating 2D position and velocity [x, y, vx, vy]^T."""
    
    def __init__(self, dt: float = 0.033, process_noise: float = 15.0, measurement_noise: float = 2.0):
        self.dt = dt
        # State vector: [x, y, vx, vy]
        self.x = [0.0, 0.0, 0.0, 0.0]
        # State covariance matrix P (4x4 diagonal initial)
        self.P = [
            [100.0, 0.0, 0.0, 0.0],
            [0.0, 100.0, 0.0, 0.0],
            [0.0, 0.0, 100.0, 0.0],
            [0.0, 0.0, 0.0, 100.0]
        ]
        self.q = process_noise
        self.r = measurement_noise
        self.is_initialized = False

    def init(self, meas_x: float, meas_y: float):
        self.x = [meas_x, meas_y, 0.0, 0.0]
        self.P = [
            [self.r, 0.0, 0.0, 0.0],
            [0.0, self.r, 0.0, 0.0],
            [0.0, 0.0, 50.0, 0.0],
            [0.0, 0.0, 0.0, 50.0]
        ]
        self.is_initialized = True

    def predict(self, dt: Optional[float] = None) -> Tuple[float, float, float, float]:
        """Time propagation step x = F*x, P = F*P*F' + Q"""
        if not self.is_initialized:
            return (0.0, 0.0, 0.0, 0.0)
            
        step = dt if dt is not None else self.dt
        # State transition matrix F
        # [ 1  0  dt 0 ]
        # [ 0  1  0  dt]
        # [ 0  0  1  0 ]
        # [ 0  0  0  1 ]
        x, y, vx, vy = self.x
        x_pred = x + vx * step
        y_pred = y + vy * step
        self.x = [x_pred, y_pred, vx, vy]
        
        # Approximate discrete process noise covariance Q addition
        q_pos = self.q * (step ** 2)
        q_vel = self.q * step
        self.P[0][0] += q_pos
        self.P[1][1] += q_pos
        self.P[2][2] += q_vel
        self.P[3][3] += q_vel
        
        return (x_pred, y_pred, vx, vy)

    def update(self, meas_x: float, meas_y: float):
        """Measurement update step using innovation residual."""
        if not self.is_initialized:
            self.init(meas_x, meas_y)
            return

        # Residual y = z - H*x (H selects position x and y)
        res_x = meas_x - self.x[0]
        res_y = meas_y - self.x[1]
        
        # Innovation covariance S = H*P*H' + R
        s_x = self.P[0][0] + self.r
        s_y = self.P[1][1] + self.r
        
        # Kalman Gain K = P * H' * inv(S)
        k00 = self.P[0][0] / s_x
        k11 = self.P[1][1] / s_y
        k20 = self.P[2][0] / s_x
        k31 = self.P[3][1] / s_y
        
        # State update
        self.x[0] += k00 * res_x
        self.x[1] += k11 * res_y
        self.x[2] += k20 * res_x
        self.x[3] += k31 * res_y
        
        # Covariance update P = (I - K*H)*P
        self.P[0][0] *= (1.0 - k00)
        self.P[1][1] *= (1.0 - k11)
        self.P[2][2] *= 0.95
        self.P[3][3] *= 0.95

    def get_lookahead_prediction(self, lookahead_s: float) -> Tuple[float, float]:
        """Predicts position lookahead_s seconds into the future."""
        px = self.x[0] + self.x[2] * lookahead_s
        py = self.x[1] + self.x[3] * lookahead_s
        return (px, py)

    @property
    def uncertainty(self) -> float:
        """Trace of position covariance."""
        return math.sqrt(max(0.0, self.P[0][0] + self.P[1][1]))
