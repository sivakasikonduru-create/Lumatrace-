import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/components/ConfigView.tsx', 'utf-8');

const obstacleSection = `
        {/* Section 4: Line of Sight / Obstructions */}
        <div className="bg-[#0F1117] border border-[#1F2937] rounded-lg p-5 shadow-sm space-y-4 md:col-span-2">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-widest border-b border-[#1F2937] pb-3">
            LOS / Physical Obstructions
          </h3>
          <div className="flex gap-4">
            <button
              onClick={() => onUpdateConfig({ losObstructionEnabled: !config.losObstructionEnabled })}
              className={\`flex-1 py-2 px-4 rounded text-xs font-bold uppercase transition \${config.losObstructionEnabled ? 'bg-rose-600 text-white' : 'bg-[#1F2937] text-gray-400 hover:bg-[#283548]'}\`}
            >
              Moving Obstacles {config.losObstructionEnabled ? 'ON' : 'OFF'}
            </button>
            <select
              value={config.losObstructionSeverity || 'partial'}
              onChange={(e) => onUpdateConfig({ losObstructionSeverity: e.target.value as 'partial' | 'full' })}
              disabled={!config.losObstructionEnabled}
              className="flex-1 bg-[#0A0B10] border border-[#1F2937] rounded-md px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500 disabled:opacity-50"
            >
              <option value="partial">Partial Occlusion</option>
              <option value="full">Complete Obstruction</option>
            </select>
          </div>
        </div>
`;

content = content.replace(
  "      </div>\n    </div>\n  );\n};",
  "      </div>\n" + obstacleSection + "\n    </div>\n  );\n};"
);

writeFileSync('src/components/ConfigView.tsx', content);
