import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/App.tsx', 'utf-8');

if (!content.includes('import { GuideView }')) {
  content = content.replace(
    "import { ArchitectureView } from './components/ArchitectureView';",
    "import { ArchitectureView } from './components/ArchitectureView';\nimport { GuideView } from './components/GuideView';"
  );
}

if (!content.includes("activeTab === 'guide'")) {
  content = content.replace(
    "{activeTab === 'architecture' && <ArchitectureView />}",
    "{activeTab === 'architecture' && <ArchitectureView />}\n        {activeTab === 'guide' && <GuideView />}"
  );
}

writeFileSync('src/App.tsx', content);
