import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/core/ScenarioDefinitions.ts', 'utf-8');
content = content.replace(/\],\s*\{\s*id:\s*'d2d-01'/m, ", { id: 'd2d-01'");
writeFileSync('src/core/ScenarioDefinitions.ts', content);
