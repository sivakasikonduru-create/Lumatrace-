import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/components/GuideView.tsx', 'utf-8');

const additionalDocs = `
        {/* 8. ENGINEERING MODE */}
        <SectionHeader id="engineering" title="8. Advanced Engineering Mode" icon={<Cpu className="w-5 h-5 text-gray-400" />} />
        {openSections['engineering'] && (
          <div className="p-6 space-y-4 text-sm leading-relaxed border-b border-[#1F2937]">
            <h3 className="text-cyan-400 font-bold mb-2">Internal Architecture</h3>
            <ul className="list-disc pl-5 space-y-2">
              <li><strong>Coordinate Transforms:</strong> The target's World X/Y/Z is rotated by the camera's Pan/Tilt matrices before being projected via a pinhole model into the 2D pixel plane.</li>
              <li><strong>Centroiding:</strong> The optical sensor output is thresholded to find the brightest clusters, returning sub-pixel estimations.</li>
              <li><strong>Prediction & Uncertainty:</strong> A Kalman Filter estimates velocity. The ML predictor provides multi-horizon forecasts. When uncertainty is high, the system blends them dynamically.</li>
            </ul>
          </div>
        )}

        {/* 9. BUTTON REFERENCE */}
        <SectionHeader id="buttons" title="9. Comprehensive Button Reference" icon={<Info className="w-5 h-5 text-gray-400" />} />
        {openSections['buttons'] && (
          <div className="p-6 space-y-4 text-sm leading-relaxed border-b border-[#1F2937]">
            <table className="w-full text-left border-collapse bg-[#0A0B10] border border-[#1F2937] rounded text-xs">
              <thead>
                <tr className="border-b border-[#1F2937] text-gray-500">
                  <th className="p-2 font-mono">Page</th>
                  <th className="p-2 font-mono">Control</th>
                  <th className="p-2 font-mono">Function</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F2937]">
                <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-cyan-400">RUN SIMULATION</td><td className="p-2">Starts the 30Hz simulation loop.</td></tr>
                <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-gray-300">RESET</td><td className="p-2">Re-centers all coordinates to origin.</td></tr>
                <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-rose-400">INDUCE OPTICAL LOSS</td><td className="p-2">Forces a 1s complete LOS blockage.</td></tr>
                <tr><td className="p-2">Dashboard</td><td className="p-2 font-bold text-white">CONTROLLER TOGGLE</td><td className="p-2">Switches between Baseline (Reactive) and LumaTrace (Predictive).</td></tr>
                <tr><td className="p-2">Config</td><td className="p-2 font-bold text-white">MOVING OBSTACLES</td><td className="p-2">Toggles dynamic physical obstructions in the visual feed.</td></tr>
                <tr><td className="p-2">Config</td><td className="p-2 font-bold text-white">ATMOSPHERE DROPDOWN</td><td className="p-2">Applies scattering/noise (Clear, Haze, Fog, Rain).</td></tr>
              </tbody>
            </table>
          </div>
        )}
`;

content = content.replace(
  "      </div>\n    </div>",
  additionalDocs + "\n      </div>\n    </div>"
);

content = content.replace(
  "import { BookOpen, ChevronDown, ChevronRight, Play, Info, Target, AlertTriangle } from 'lucide-react';",
  "import { BookOpen, ChevronDown, ChevronRight, Play, Info, Target, AlertTriangle, Cpu, Sliders, FlaskConical, FileText } from 'lucide-react';"
);

writeFileSync('src/components/GuideView.tsx', content);
