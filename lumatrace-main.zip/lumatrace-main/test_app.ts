import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/components/DashboardView.tsx', 'utf-8');
content = content.replace("<Zap className", "<Target className");
writeFileSync('src/components/DashboardView.tsx', content);
