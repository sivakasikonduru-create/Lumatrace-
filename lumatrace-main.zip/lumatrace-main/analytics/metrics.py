"""Performance Analytics Engine strictly calculating SIH metrics."""
from dataclasses import dataclass
import math
from typing import List, Dict, Any, Optional

@dataclass
class PerformanceMetrics:
    """Consolidated performance evaluation metrics."""
    simulation_duration_s: float
    total_frames: int
    processing_fps: float
    min_fps: float
    avg_fps: float
    avg_processing_time_ms: float
    acquisition_time_s: float
    reacquisition_time_s: float
    average_tracking_error_px: float
    max_tracking_error_px: float
    rmse_px: float
    target_loss_percentage: float
    lock_retention_rate: float
    average_centroiding_error_px: float
    sih_compliance: Dict[str, Dict[str, Any]]

class PerformanceEvaluator:
    """Calculates ground-truth comparative metrics without fabricating data."""
    
    def __init__(self):
        self.tracking_errors: List[float] = []
        self.centroiding_errors: List[float] = []
        self.frame_times: List[float] = []
        self.detection_flags: List[bool] = []
        self.timestamps: List[float] = []
        self.first_acquisition_time: Optional[float] = None
        self.reacquisition_times: List[float] = []

    def record_frame(self, timestamp: float, detected: bool, tracking_error_px: float,
                     centroiding_error_px: Optional[float], processing_time_ms: float,
                     reacquisition_event_time: Optional[float] = None):
        self.timestamps.append(timestamp)
        self.detection_flags.append(detected)
        self.tracking_errors.append(tracking_error_px)
        self.frame_times.append(processing_time_ms)
        
        if centroiding_error_px is not None:
            self.centroiding_errors.append(centroiding_error_px)
            
        if detected and self.first_acquisition_time is None:
            self.first_acquisition_time = timestamp
            
        if reacquisition_event_time is not None and reacquisition_event_time > 0.0:
            self.reacquisition_times.append(reacquisition_event_time)

    def compute_metrics(self) -> PerformanceMetrics:
        total_frames = len(self.detection_flags)
        if total_frames == 0:
            return self._empty_metrics()

        duration = self.timestamps[-1] - self.timestamps[0] if len(self.timestamps) > 1 else 0.033
        
        # FPS calculation
        avg_proc_time = sum(self.frame_times) / total_frames if total_frames > 0 else 1.0
        fps_values = [1000.0 / max(0.1, t) for t in self.frame_times]
        avg_fps = sum(fps_values) / len(fps_values) if fps_values else 30.0
        min_fps = min(fps_values) if fps_values else 30.0
        processing_fps = total_frames / max(0.001, duration)

        # Tracking error stats
        avg_err = sum(self.tracking_errors) / total_frames if total_frames > 0 else 0.0
        max_err = max(self.tracking_errors) if self.tracking_errors else 0.0
        sq_err = sum(e ** 2 for e in self.tracking_errors) / total_frames if total_frames > 0 else 0.0
        rmse = math.sqrt(sq_err)

        # Target loss & Lock retention
        detected_count = sum(1 for d in self.detection_flags if d)
        lock_retention = (detected_count / total_frames) * 100.0
        target_loss_pct = 100.0 - lock_retention

        # Centroiding error
        avg_centroiding = sum(self.centroiding_errors) / len(self.centroiding_errors) if self.centroiding_errors else 0.0

        # Acquisition & Re-acquisition
        acq_time = self.first_acquisition_time if self.first_acquisition_time is not None else 999.0
        reacq_time = (sum(self.reacquisition_times) / len(self.reacquisition_times)) if self.reacquisition_times else 0.0

        # Strict SIH Compliance Evaluation
        compliance = {
            "acquisition_time": {
                "target": "<= 2.0 s",
                "measured": round(acq_time, 3),
                "status": "PASS" if acq_time <= 2.0 else "NEEDS IMPROVEMENT"
            },
            "tracking_error": {
                "target": "<= 10.0 px",
                "measured": round(avg_err, 2),
                "status": "PASS" if avg_err <= 10.0 else "NEEDS IMPROVEMENT"
            },
            "target_loss": {
                "target": "< 5.0 %",
                "measured": round(target_loss_pct, 2),
                "status": "PASS" if target_loss_pct < 5.0 else "NEEDS IMPROVEMENT"
            },
            "reacquisition_time": {
                "target": "<= 1.0 s",
                "measured": round(reacq_time, 3),
                "status": "PASS" if (reacq_time <= 1.0 or not self.reacquisition_times) else "NEEDS IMPROVEMENT"
            },
            "processing_speed": {
                "target": ">= 20.0 FPS",
                "measured": round(avg_fps, 1),
                "status": "PASS" if avg_fps >= 20.0 else "NEEDS IMPROVEMENT"
            }
        }

        return PerformanceMetrics(
            simulation_duration_s=round(duration, 2),
            total_frames=total_frames,
            processing_fps=round(processing_fps, 1),
            min_fps=round(min_fps, 1),
            avg_fps=round(avg_fps, 1),
            avg_processing_time_ms=round(avg_proc_time, 2),
            acquisition_time_s=round(acq_time, 3),
            reacquisition_time_s=round(reacq_time, 3),
            average_tracking_error_px=round(avg_err, 2),
            max_tracking_error_px=round(max_err, 2),
            rmse_px=round(rmse, 2),
            target_loss_percentage=round(target_loss_pct, 2),
            lock_retention_rate=round(lock_retention, 2),
            average_centroiding_error_px=round(avg_centroiding, 2),
            sih_compliance=compliance
        )

    def _empty_metrics(self) -> PerformanceMetrics:
        return PerformanceMetrics(
            simulation_duration_s=0.0, total_frames=0, processing_fps=0.0, min_fps=0.0, avg_fps=0.0,
            avg_processing_time_ms=0.0, acquisition_time_s=0.0, reacquisition_time_s=0.0,
            average_tracking_error_px=0.0, max_tracking_error_px=0.0, rmse_px=0.0,
            target_loss_percentage=0.0, lock_retention_rate=0.0, average_centroiding_error_px=0.0,
            sih_compliance={}
        )
