import { readFileSync, writeFileSync } from 'fs';

let content = readFileSync('src/App.tsx', 'utf-8');

content = content.replace(
  "failureCause: null,",
  "failureCause: null,\n    controlSaturated: false,"
);

content = content.replace(
  "const [panRate, tiltRate] = activeCtrl.computeControl(cameraRef.current, trackState, dt);",
  "const { panRate, tiltRate, saturated } = activeCtrl.computeControl(cameraRef.current, trackState, dt);\n          trackState.controlSaturated = saturated;"
);

content = content.replace(
  "metricsEvaluatorRef.current.recordFrame(timeNow, detResult.detected, err, centroidError, processTime, reacqTime);",
  "metricsEvaluatorRef.current.recordFrame(timeNow, detResult.detected, err, centroidError, processTime, reacqTime, saturated);"
);

writeFileSync('src/App.tsx', content);
