"""Configuration module for LumaTrace FSOC Virtual Camera Tracking System.
Defines all SIH-compliant default values and data models.
"""
from dataclasses import dataclass, field
from typing import Tuple, Optional

@dataclass
class SimulationConfig:
    """Configurable parameters strictly adhering to SIH Problem Statement 4."""
    # Virtual scene space
    screen_width: int = 2000
    screen_height: int = 2000
    
    # Camera specifications
    camera_width: int = 640
    camera_height: int = 480
    camera_fov_h_deg: float = 4.0
    camera_fov_v_deg: float = 3.0
    camera_update_rate_hz: float = 30.0
    max_pan_speed_deg_s: float = 5.0
    max_tilt_speed_deg_s: float = 5.0
    initial_camera_pos: Tuple[float, float] = (1000.0, 1000.0)
    
    # Target specifications
    target_count: int = 1
    target_size_px: int = 10  # 5-20 px configurable
    target_speed_px_s: float = 80.0
    target_initial_pos: Optional[Tuple[float, float]] = None  # None for random
    target_motion_mode: str = "straight_line"  # straight_line, circular, figure_8, random, spiral, sinusoidal
    
    # Controller specifications
    controller_update_rate_hz: float = 20.0  # >= 20 Hz
    controller_type: str = "predictive"  # baseline or predictive
    
    # Performance criteria (SIH Targets)
    target_acquisition_time_s: float = 2.0
    target_tracking_error_px: float = 10.0
    target_loss_percentage_max: float = 5.0
    target_reacquisition_time_s: float = 1.0
    target_processing_fps_min: float = 20.0

    @property
    def pixels_per_degree_h(self) -> float:
        return self.camera_width / self.camera_fov_h_deg

    @property
    def pixels_per_degree_v(self) -> float:
        return self.camera_height / self.camera_fov_v_deg
