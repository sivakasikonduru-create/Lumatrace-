import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/components/DashboardView.tsx', 'utf-8');

content = content.replace(
  "Tracking Error (SIH ≤10px)",
  "<span title=\"The Euclidean distance in pixels between the target centroid and the camera optical center. Measured strictly from the visual sensor feed.\">Tracking Error (SIH ≤10px)</span>"
);

content = content.replace(
  "Gimbal Pan / Tilt",
  "<span title=\"The physical orientation of the camera mount and the rate at which the motors are currently driving it.\">Gimbal Pan / Tilt</span>"
);

content = content.replace(
  "Tracking Status",
  "<span title=\"The current state of the AI tracking loop (e.g. SEARCHING, TRACKING, LOST, REACQUIRING).\">Tracking Status</span>"
);

content = content.replace(
  "Compute Pipeline",
  "<span title=\"Real-time processing latency and frame rate of the simulation loop.\">Compute Pipeline</span>"
);

writeFileSync('src/components/DashboardView.tsx', content);
