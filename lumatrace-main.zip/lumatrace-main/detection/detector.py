"""Computer Vision Beacon Detection and Centroiding Module."""
from dataclasses import dataclass
import time
import math
from typing import Tuple, Optional, List

@dataclass
class DetectionResult:
    """Output from computer-vision beacon detector."""
    detected: bool
    bbox: Tuple[int, int, int, int]  # (x, y, w, h)
    centroid_x: float
    centroid_y: float
    confidence: float
    processing_time_ms: float
    camera_center_x: float
    camera_center_y: float
    horizontal_error: float  # centroid_x - camera_center_x
    vertical_error: float    # centroid_y - camera_center_y
    euclidean_error: float   # sqrt(dx^2 + dy^2)
    centroiding_error: Optional[float] = None  # strictly for post-eval against ground truth

class BeaconDetector:
    """Computer-vision optical beacon detector using intensity thresholding and spatial moments."""
    
    def __init__(self, camera_width: int = 640, camera_height: int = 480, threshold: float = 128.0):
        self.camera_width = camera_width
        self.camera_height = camera_height
        self.threshold = threshold
        self.camera_center_x = camera_width / 2.0
        self.camera_center_y = camera_height / 2.0

    def process_frame(self, frame_pixels: List[List[float]], ground_truth_viewport: Optional[Tuple[float, float]] = None) -> DetectionResult:
        """Processes 2D grayscale/intensity frame array and finds beacon centroid via image moments.
        Does NOT use ground truth coordinates for detection.
        """
        start_time = time.perf_counter()
        
        m00 = 0.0
        m10 = 0.0
        m01 = 0.0
        
        min_x = self.camera_width
        max_x = 0
        min_y = self.camera_height
        max_y = 0
        
        h = len(frame_pixels)
        w = len(frame_pixels[0]) if h > 0 else 0
        
        count_bright = 0
        peak_intensity = 0.0
        
        for y in range(h):
            row = frame_pixels[y]
            for x in range(w):
                val = row[x]
                if val > self.threshold:
                    weight = val - self.threshold
                    m00 += weight
                    m10 += x * weight
                    m01 += y * weight
                    count_bright += 1
                    if val > peak_intensity:
                        peak_intensity = val
                    if x < min_x: min_x = x
                    if x > max_x: max_x = x
                    if y < min_y: min_y = y
                    if y > max_y: max_y = y

        proc_time_ms = (time.perf_counter() - start_time) * 1000.0

        # Beacon spot is typically 5-20 px wide (area ~25 to 400 px^2)
        if m00 > 0.0 and 4 <= count_bright <= 600:
            cx = m10 / m00
            cy = m01 / m00
            bbox = (min_x, min_y, max(1, max_x - min_x + 1), max(1, max_y - min_y + 1))
            
            # Confidence based on peak intensity, spot compactness, and contrast
            contrast_factor = min(1.0, (peak_intensity - self.threshold) / 100.0)
            area = (bbox[2] * bbox[3])
            fill_ratio = min(1.0, count_bright / max(1.0, area))
            confidence = max(0.1, min(1.0, 0.5 * contrast_factor + 0.5 * fill_ratio))
            
            dx = cx - self.camera_center_x
            dy = cy - self.camera_center_y
            euclidean = math.sqrt(dx * dx + dy * dy)
            
            # Centroiding error ONLY for evaluation if ground truth is passed
            centroiding_err = None
            if ground_truth_viewport is not None:
                gt_x, gt_y = ground_truth_viewport
                centroiding_err = math.sqrt((cx - gt_x) ** 2 + (cy - gt_y) ** 2)
                
            return DetectionResult(
                detected=True,
                bbox=bbox,
                centroid_x=cx,
                centroid_y=cy,
                confidence=confidence,
                processing_time_ms=proc_time_ms,
                camera_center_x=self.camera_center_x,
                camera_center_y=self.camera_center_y,
                horizontal_error=dx,
                vertical_error=dy,
                euclidean_error=euclidean,
                centroiding_error=centroiding_err
            )
        else:
            return DetectionResult(
                detected=False,
                bbox=(0, 0, 0, 0),
                centroid_x=0.0,
                centroid_y=0.0,
                confidence=0.0,
                processing_time_ms=proc_time_ms,
                camera_center_x=self.camera_center_x,
                camera_center_y=self.camera_center_y,
                horizontal_error=0.0,
                vertical_error=0.0,
                euclidean_error=0.0,
                centroiding_error=None
            )
