import { readFileSync, writeFileSync } from 'fs';
let content = readFileSync('src/App.tsx', 'utf-8');

content = content.replace(
  "{activeTab === 'guide' && <GuideView />}",
  "{activeTab === 'guide' && <GuideView setActiveTab={setActiveTab} />}"
);

writeFileSync('src/App.tsx', content);
